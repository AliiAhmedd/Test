#include "ClimateReading.h"

ClimateReading::ClimateReading() {}

void ClimateReading::setup() {
    Wire.begin();
    bme68x.begin(0x76, Wire);

    if (bme68x.checkStatus()) {
        if (bme68x.checkStatus() == BME68X_ERROR) {
            Serial.println("BME68X initialization error!");
        }
    }

    // Heater and duration profile
    uint16_t tempProf[3] = {100, 200, 320};
    uint16_t durProf[3] = {150, 150, 150};

    bme68x.setTPH();
    bme68x.setSeqSleep(BME68X_ODR_250_MS);
    bme68x.setHeaterProf(tempProf, durProf, 3);
    bme68x.setOpMode(BME68X_SEQUENTIAL_MODE);
}

ClimateReadings ClimateReading::read() {
    bme68xData data;
    ClimateReadings r = {0.0f, 0.0f, 0.0f};

    if (bme68x.fetchData()) {
        bme68x.getData(data);
        r.temperature = data.temperature - 4.49; // your calibration
        r.humidity = data.humidity;
        r.pressure = data.pressure;
    }

    return r;
}

