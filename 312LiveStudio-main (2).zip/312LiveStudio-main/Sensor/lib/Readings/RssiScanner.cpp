#include "RssiScanner.h"

RssiScanner::RssiScanner(int threshold) {
    rssiThreshold = threshold;
    WiFi.mode(WIFI_STA);
    WiFi.disconnect(); // ensure not connected
    delay(100);
}

String RssiScanner::macToString(uint8_t mac[6]) {
    char s[20];
    sprintf(s, "%02X:%02X:%02X:%02X:%02X:%02X",
            mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    return String(s);
}

String RssiScanner::encToString(uint8_t enc) {
    switch (enc) {
        case ENC_TYPE_NONE: return "NONE";
        case ENC_TYPE_TKIP: return "WPA";
        case ENC_TYPE_CCMP: return "WPA2";
        case ENC_TYPE_AUTO: return "AUTO";
    }
    return "UNKN";
}

int RssiScanner::scanNetworks(String ssidList[], int rssiList[], int maxNetworks) {
    int count = WiFi.scanNetworks();
    int nearbyCount = 0;

    for (int i = 0; i < count && nearbyCount < maxNetworks; i++) {
        int rssi = WiFi.RSSI(i);
        if (rssi > rssiThreshold) { // only include strong signals
            ssidList[nearbyCount] = WiFi.SSID(i);
            rssiList[nearbyCount] = rssi;
            nearbyCount++;
        }
    }
    return nearbyCount;
}

