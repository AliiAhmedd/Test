#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <bme68xLibrary.h>

struct ClimateReadings {
    float temperature;
    float humidity;
    float pressure;
};

class ClimateReading {
public:
    ClimateReading();
    void setup();
    ClimateReadings read();

private:
    Bme68x bme68x;
};

