#ifndef RSSISCANNER_H
#define RSSISCANNER_H

#include <WiFi.h>
#include <Arduino.h>

class RssiScanner {
private:
    int rssiThreshold; // minimum RSSI to consider “near”

public:
    RssiScanner(int threshold = -70);

    // Convert MAC to string
    static String macToString(uint8_t mac[6]);

    // Convert encryption type to string
    static String encToString(uint8_t enc);

    // Scan networks and return only “nearby” networks
    // ssidList and rssiList must have size >= maxNetworks
    int scanNetworks(String ssidList[], int rssiList[], int maxNetworks);
};

#endif // 

