#pragma once
#include "ClimateReading.h"
#include <Arduino.h>
#include <WiFi.h>

struct SensorData {
  float temperature;
  float humidity;
  float pressure;
  bool alarmTriggered;

  void print() const {
    Serial.print("Temperature: ");
    Serial.println(temperature);
    Serial.print("Humidity: ");
    Serial.println(humidity);
    Serial.print("Pressure: ");
    Serial.println(pressure);
    Serial.print("Alarm triggered: ");
    Serial.println(alarmTriggered ? "YES" : "NO");
  }
};

class ReadingsManager {
public:
  ReadingsManager();
  void setup();
  SensorData read(); // unified method to get all sensor info

private:
  ClimateReading climate;
  int getRSSI();         // helper to get Wi-Fi signal
  String getClosestAP(); // helper to detect strongest AP
};
