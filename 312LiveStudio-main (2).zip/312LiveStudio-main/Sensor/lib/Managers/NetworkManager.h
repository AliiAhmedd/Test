#pragma once

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include "ReadingsManager.h"

struct RouterInfo {
    String ssid;
    int rssi;
};

class NetworkManager {
public:
    NetworkManager();

    void setup(bool testing = false);

    // STAFF MODE
    RouterInfo scanClosestRouter();
    void sendStaffData(int staffID, const RouterInfo& router);

    // ROOM MODE
    void sendRoomData(int roomNumber, float temperature, float humidity, float pressure, bool alarm);

    String getSensorID() { return SENSOR_ID; }

private:
    String SENSOR_ID;
    String SSID = "BasestationAP";
    String PASSWORD = "12345678";
    const char* basestationIP = "192.168.42.1";

    // Display
    // Adafruit_SSD1306 display = Adafruit_SSD1306(128, 64, &Wire);
};

