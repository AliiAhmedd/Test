#include "ReadingsManager.h"

ReadingsManager::ReadingsManager() {}

void ReadingsManager::setup() {
    climate.setup();
}

SensorData ReadingsManager::read() {
    SensorData data;

    // 1️⃣ Get climate readings
    ClimateReadings cr = climate.read();
    data.temperature = cr.temperature;
    data.humidity = cr.humidity;
    data.pressure = cr.pressure;


    return data;
}

