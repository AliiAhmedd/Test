#include "MenuManager.h"

MenuManager::MenuManager() : display(128, 64, &Wire) {}

// Setup display and buttons
void MenuManager::setup() {
  pinMode(RED_BUTTON_PIN, INPUT);
  pinMode(BLACK_BUTTON_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  Serial.begin(115200);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;)
      ;
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  drawModeMenu();
}

// Main menu loop
void MenuManager::loop() {
  unsigned long now = millis();

  // Read buttons
  int currentRed = digitalRead(RED_BUTTON_PIN);
  int currentBlack = digitalRead(BLACK_BUTTON_PIN);

  if (!locked) {
    // Menu navigation when not locked
    if (currentRed == HIGH && !redPressed) {
      redPressed = true;
      blackPressed = false;
      lastDebounceTime = now;

      switch (state) {
      case MODE_SELECT:
        menuIndex = (menuIndex + 1) % 2;
        drawModeMenu();
        break;
      case STAFF_ID_SELECT:
        staffID = (staffID + 1) % 10;
        drawStaffSelect();
        break;
      case ROOM_NUMBER_SELECT:
        roomNumber = (roomNumber + 1) % 100;
        drawRoomSelect();
        break;
      }
    } else if (currentRed == LOW) {
      redPressed = false;
    }

    // BLACK BUTTON: Select / Lock
    if (currentBlack == HIGH && !blackPressed) {
      blackPressed = true;
      redPressed = false;
      lastDebounceTime = now;

      switch (state) {
      case MODE_SELECT:
        currentMode = menuItems[menuIndex];
        if (currentMode == "staffMode") {
          state = STAFF_ID_SELECT;
          drawStaffSelect();
        } else {
          state = ROOM_NUMBER_SELECT;
          drawRoomSelect();
        }
        break;
      case STAFF_ID_SELECT:
      case ROOM_NUMBER_SELECT:
        locked = true;
        Serial.print("Selection locked. ");
        Serial.print("StaffID: ");
        Serial.print(staffID);
        Serial.print(" | Room #: ");
        Serial.println(roomNumber);
        drawRoomReadings();
        break;
      }
    } else if (currentBlack == LOW) {
      blackPressed = false;
    }

  } else {
    // Only draw room readings if we are in roomMode
    if (currentMode == "roomMode") {
      drawRoomReadings();

      // RED button triggers alarm if not already active
      if (currentRed == HIGH && !redPressed && !alarmActive) {
        redPressed = true;
        alarmActive = true;
        alarmStartTime = now;
        alarmTone = 1000;
        Serial.println(">>> Alarm STARTED <<<");
      } else if (currentRed == LOW) {
        redPressed = false;
      }
    } else if (currentMode == "staffMode") {
      // Keep staff ID selection displayed after locking
      drawStaffSelect();
    }
  }

  if (alarmActive) {
    // Alternate tone for alert effect
    if (now - lastToneChange >= toneInterval) {
      alarmTone = (alarmTone == 1000) ? 500 : 1000;
      tone(BUZZER_PIN, alarmTone);
      lastToneChange = now;
    }

    // Stop alarm after duration
    if (now - alarmStartTime >= alarmDuration) {
      noTone(BUZZER_PIN);
      Serial.println(">>> Alarm STOPPED <<<");
      alarmActive = false;
    }
  }
}

// Button helpers
bool MenuManager::redButtonPressed() {
  if (digitalRead(RED_BUTTON_PIN) == HIGH && !redPressed) {
    redPressed = true;
    return true;
  } else if (digitalRead(RED_BUTTON_PIN) == LOW)
    redPressed = false;
  return false;
}

bool MenuManager::blackButtonPressed() {
  if (digitalRead(BLACK_BUTTON_PIN) == HIGH && !blackPressed) {
    blackPressed = true;
    return true;
  } else if (digitalRead(BLACK_BUTTON_PIN) == LOW)
    blackPressed = false;
  return false;
}

// Drawing screens
void MenuManager::drawModeMenu() {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.print("Current Mode: ");
  display.println(currentMode == "" ? "None" : currentMode);
  if (currentMode == "staffMode") {
    display.print("ID:");
    display.println(staffID);
  }
  if (currentMode == "roomMode") {
    display.print("#");
    display.println(roomNumber);
  }

  display.println("\nSelect Mode:");
  for (int i = 0; i < 2; i++) {
    display.print(i == menuIndex ? "> " : "  ");
    display.println(menuItems[i]);
  }
  display.display();
}

void MenuManager::drawStaffSelect() {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Staff ID Selection:");
  display.setTextSize(4);
  display.setCursor(50, 28);
  display.println(staffID);
  display.setTextSize(1);
  display.display();
}

void MenuManager::drawRoomSelect() {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Room Number Selection:");
  display.setTextSize(4);
  display.setCursor(50, 28);
  display.println(roomNumber);
  display.setTextSize(1);
  display.display();
}

void MenuManager::drawRoomReadings() {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.print("RoomMode #");
  display.println(roomNumber);
  // display.print("Temp: ");
  // display.print(latestReadings.temperature, 1);
  // display.println(" C");
  // display.print("Hum: ");
  // display.print(latestReadings.humidity, 1);
  // display.println(" %");
  // display.print("Pres: ");
  // display.print(latestReadings.pressure, 1);
  // display.println(" hPa");
  display.println("\nRed Btn: Alarm");
  display.display();
}
