#pragma once
#include "ReadingsManager.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Arduino.h>
#include <Wire.h>

#define RED_BUTTON_PIN 12
#define BLACK_BUTTON_PIN 13
#define BUZZER_PIN 7

class MenuManager {
public:
  MenuManager();

  void setup();
  void loop();

  // Getters
  String getMode() const { return currentMode; }
  int getStaffID() const { return staffID; }
  int getRoomNumber() const { return roomNumber; }
  bool getAlarmStatus() const { return alarmActive; }
  bool isLocked() const { return locked; }

private:
  // Menu drawing
  void drawModeMenu();
  void drawStaffSelect();
  void drawRoomSelect();
  void drawRoomReadings();

  // Button helpers
  bool redButtonPressed();
  bool blackButtonPressed();

  // Menu state
  enum MenuState {
    MODE_SELECT,
    STAFF_ID_SELECT,
    ROOM_NUMBER_SELECT
  } state = MODE_SELECT;

  String menuItems[2] = {"staffMode", "roomMode"};
  int menuIndex = 0;
  String currentMode = "";
  int staffID = 0;
  int roomNumber = 0;
  bool locked = false;

  unsigned long alarmStartTime = 0;
  unsigned long lastToneChange = 0;
  int alarmTone = 1000;
  const unsigned long alarmDuration = 20000; // 20 seconds
  const unsigned long toneInterval = 300;    // switch every 300 ms
  bool alarmActive = false;
  unsigned long lastDebounceTime = 0;      // Timestamp of the last button press
  const unsigned long debounceDelay = 150; // Minimum delay between presses (ms)

  // Button tracking
  bool redPressed = false;
  bool blackPressed = false;

  // Display
  Adafruit_SSD1306 display;

  // Readings
  ReadingsManager *readingsManager;
  ClimateReadings latestReadings;
};
