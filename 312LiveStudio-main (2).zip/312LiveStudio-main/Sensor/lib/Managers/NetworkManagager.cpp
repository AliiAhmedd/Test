#include "NetworkManager.h"

// Constructor
NetworkManager::NetworkManager() {}

// Setup WiFi (Serial only)
void NetworkManager::setup(bool internalTesting) {
    Serial.begin(115200);

    WiFi.mode(WIFI_STA);
    WiFi.begin(SSID.c_str(), PASSWORD.c_str());
    SENSOR_ID = WiFi.macAddress();

    if (!internalTesting) {
        Serial.print("Connecting to basestation");

        int attempts = 0;
        while (WiFi.status() != WL_CONNECTED && attempts < 40) {
            delay(500);
            Serial.print(".");
            attempts++;
        }

        if (WiFi.status() == WL_CONNECTED) {
            Serial.println("\nConnected!");
            Serial.print("IP: ");
            Serial.println(WiFi.localIP());
        } else {
            Serial.println("\nFAILED to connect!");
        }
    }
}

// Scan for closest SATB0 router
RouterInfo NetworkManager::scanClosestRouter() {
    RouterInfo best;
    best.ssid = "";
    best.rssi = -999;

    Serial.println("Scanning networks...");

    int n = WiFi.scanNetworks();

    for (int i = 0; i < n; i++) {
        String ssid = WiFi.SSID(i);
        int rssi = WiFi.RSSI(i);

        Serial.print(ssid);
        Serial.print(" : ");
        Serial.println(rssi);

        if (ssid.startsWith("SATB0") && rssi > best.rssi) {
            best.ssid = ssid;
            best.rssi = rssi;
        }
    }

    WiFi.scanDelete();
    return best;
}

// Send staff data
void NetworkManager::sendStaffData(int staffID, const RouterInfo &router) {

    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("NOT CONNECTED - staff send aborted");
        return;
    }

    HTTPClient http;
    String url = "http://" + String(basestationIP) + "/sensorData";

    http.begin(url);
    http.addHeader("Content-Type", "application/json");

    char lastChar = router.ssid.charAt(router.ssid.length() - 1);
    int routerNum = lastChar - '0';


    String json =
        "{"
        "\"id\":\"" + SENSOR_ID + "\","
        "\"mode\":\"staffMode\","
        "\"staffID\":" + String(staffID) + ","
        "\"closestRouter\":\"" + String(routerNum) + "\","
        "\"rssi\":" + String(router.rssi) +
        "}";

    int code = http.POST(json);

    Serial.print("Staff POST code: ");
    Serial.println(code);

    if (code > 0) {
        String payload = http.getString();
        Serial.print("Response body: ");
        Serial.println(payload);
    } else {
        Serial.println("POST failed!");
    }


    http.end();
}

// Send room data
void NetworkManager::sendRoomData(
    int roomNumber,
    float temperature,
    float humidity,
    float pressure,
    bool alarm
) {

    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("NOT CONNECTED - room send aborted");
        return;
    }

    Serial.println("Sending room data...");

    HTTPClient http;

    String url = "http://" + String(basestationIP) + "/sensorData";

    http.begin(url);
    http.addHeader("Content-Type", "application/json");

    Serial.println(alarm);

    String json =
        "{"
        "\"id\":\"" + SENSOR_ID + "\","
        "\"mode\":\"roomMode\","
        "\"roomID\":" + String(roomNumber) + ","
        "\"temperature\":" + String(temperature, 2) + ","
        "\"humidity\":" + String(humidity, 2) + ","
        "\"pressure\":" + String(pressure, 2) + ","
        "\"alarmTriggered\":" + String(alarm) +
        "}";

    int code = http.POST(json);

    Serial.print("Room POST code: ");
    Serial.println(code);

    if (code > 0) {
        String payload = http.getString();
        Serial.print("Response body: ");
        Serial.println(payload);
    } else {
        Serial.println("POST failed!");
    }

    http.end();
}

