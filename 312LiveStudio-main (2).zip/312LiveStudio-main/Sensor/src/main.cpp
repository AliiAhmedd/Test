#include "ClimateReading.h"
#include "MenuManager.h"
#include "NetworkManager.h"
#include "ReadingsManager.h"
#include <Arduino.h>

MenuManager menuManager;
NetworkManager networkManager;
ReadingsManager readingsManager;

bool internalTesting = false;
const unsigned long sendDelay = 3000; // 5 seconds
unsigned long lastSendTime = 0;

void setup() {
  Serial.begin(115200);

  networkManager.setup(internalTesting);
  menuManager.setup();
  readingsManager.setup();
}

void loop() {
  // Update the menu
  menuManager.loop();

  // Only send data every sendDelay milliseconds
  if (millis() - lastSendTime >= sendDelay) {
    lastSendTime = millis();

    String mode = menuManager.getMode();

    if (mode == "staffMode") {

      // Scan closest router
      RouterInfo router = networkManager.scanClosestRouter();

      // Send staff data
      networkManager.sendStaffData(menuManager.getStaffID(), router);

      Serial.println("Staff data sent!");
      Serial.println("Closest router: " + router.ssid +
                     ", RSSI: " + String(router.rssi));
    } else if (mode == "roomMode") {
      // Read climate sensor
      SensorData r = readingsManager.read();
      r.print();

      r.alarmTriggered = menuManager.getAlarmStatus();

      // Send room data
      networkManager.sendRoomData(menuManager.getRoomNumber(), r.temperature,
                                  r.humidity, r.pressure, r.alarmTriggered);
    }
  }
}
