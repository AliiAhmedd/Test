#include <HTTPClient.h>
#include <SensorManager.h>
#include <WebServer.h>
#include <WiFi.h>

const char *ssid = "BasestationAP";
const char *password = "12345678";
const char *frontendHost = "192.168.42.16";

bool OFFLINE = false;

WebServer server(80);
SensorManager sensorManager(30000);

void handleSensorEndpoint() {

  String jsonData = server.arg("plain");
  Serial.println("Received: " + jsonData);

  // Parse incoming JSON to determine mode
  DynamicJsonDocument doc(512);
  DeserializationError error = deserializeJson(doc, jsonData);
  if (error) {
    Serial.print("Failed to parse JSON: ");
    Serial.println(error.c_str());
    server.send(400, "text/plain", "Invalid JSON");
    return;
  }

  String sensorID = doc["id"];
  String mode = doc["mode"] | "unknown";
  bool alarm =
      doc["alarmTriggered"].as<int>() != 0; // default to false if missing

  // Update sensor info in manager
  sensorManager.handleSensorData(jsonData);
  sensorManager.printSensors();

  Serial.println(alarm == 0 ? "Alarm cleared" : "Alarm triggered");

  if (!OFFLINE) {

    HTTPClient http;
    String url = "";

    if (mode == "roomMode") {

      if (alarm) {
        Serial.println("Alarm triggered");
        url = "http://" + String(frontendHost) + ":3000/api/patientAlarm";
      } else {
        Serial.println("Temperature update");
        url = "http://" + String(frontendHost) + ":3000/api/roomTemperature";
      }

    } else if (mode == "staffMode") {

      url = "http://" + String(frontendHost) + ":3000/api/roomEntered";

    } else {
      Serial.println("Unknown mode, skipping forwarding");
      server.send(400, "text/plain", "Unknown mode");
      return;
    }

    http.begin(url);
    http.addHeader("Content-Type", "application/json");
    int responseCode = http.POST(jsonData);
    Serial.print("Forward Response: ");
    Serial.println(responseCode);
    http.end();
  }

  server.send(200, "text/plain", "OK");
}

void setup() {
  Serial.begin(115200);

  delay(3000);

  WiFi.softAP(ssid, password);
  Serial.println("Basestation AP started");
  Serial.print("AP IP: ");
  Serial.println(WiFi.softAPIP());

  server.on("/sensorData", HTTP_POST, handleSensorEndpoint);
  server.begin();
}

void loop() { server.handleClient(); }
