#ifndef SENSORMANAGER_H
#define SENSORMANAGER_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include <map>

// Room-mode sensor info
struct RoomSensorInfo {
  float temperature;
  float humidity;
  float pressure;
  int roomID;
  bool alarm;
  String location;
  unsigned long lastUpdate;
};

// Staff-mode sensor info
struct StaffSensorInfo {
  int staffID;
  String closestRouter;
  int rssi;
  unsigned long lastUpdate;
};

class SensorManager {
private:
  std::map<String, RoomSensorInfo> roomSensors;   // keyed by sensor ID
  std::map<String, StaffSensorInfo> staffSensors; // keyed by sensor ID
  unsigned long timeoutMs;

public:
  // Constructor: specify timeout in milliseconds (default 30s)
  SensorManager(unsigned long timeout = 30000) : timeoutMs(timeout) {}

  // Handle incoming JSON data from a sensor
  void handleSensorData(const String &jsonData) {
    DynamicJsonDocument doc(512);
    DeserializationError error = deserializeJson(doc, jsonData);
    if (error) {
      Serial.print("Failed to parse JSON: ");
      Serial.println(error.c_str());
      return;
    }

    String sensorID = doc["id"];
    String mode = doc["mode"] | "unknown";

    unsigned long now = millis();

    if (mode == "roomMode") {
      RoomSensorInfo info;
      info.roomID = doc["roomID"];
      info.temperature = doc["temperature"];
      info.humidity = doc["humidity"];
      info.pressure = doc["pressure"];
      info.location = doc["location"] | "unknown";
      info.alarm = doc["alarmTriggered"].as<int>() != 0;
      info.lastUpdate = now;

      roomSensors[sensorID] = info;
      Serial.print("Updated room sensor: ");
      Serial.println(sensorID);

    } else if (mode == "staffMode") {

      StaffSensorInfo info;
      info.staffID = doc["staffID"];
      info.closestRouter = doc["closestRouter"] | "unknown";
      info.rssi = doc["rssi"];
      info.lastUpdate = now;

      staffSensors[sensorID] = info;
      Serial.print("Updated staff sensor: ");
      Serial.println(sensorID);
    } else {
      Serial.println("Unknown mode in JSON");
    }
  }

  // Remove sensors that haven't updated within timeout
  void cleanupSensors() {
    unsigned long now = millis();

    // Room sensors
    for (auto it = roomSensors.begin(); it != roomSensors.end();) {
      if (now - it->second.lastUpdate > timeoutMs) {
        Serial.print("Room sensor timed out: ");
        Serial.println(it->first);
        it = roomSensors.erase(it);
      } else {
        ++it;
      }
    }

    // Staff sensors
    for (auto it = staffSensors.begin(); it != staffSensors.end();) {
      if (now - it->second.lastUpdate > timeoutMs) {
        Serial.print("Staff sensor timed out: ");
        Serial.println(it->first);
        it = staffSensors.erase(it);
      } else {
        ++it;
      }
    }
  }

  // Optional: print all sensors
  void printSensors() {
    Serial.println("---- Room Sensors ----");
    for (const auto &pair : roomSensors) {
      const RoomSensorInfo &info = pair.second;
      Serial.print("ID: ");
      Serial.println(pair.first);
      Serial.print(" Room #: ");
      Serial.println(info.roomID);
      Serial.print(" Temp: ");
      Serial.println(info.temperature);
      Serial.print(" Humidity: ");
      Serial.println(info.humidity);
      Serial.print(" Pressure: ");
      Serial.println(info.pressure);
      Serial.print(" Alarm: ");
      Serial.println(info.alarm);
      Serial.print(" Location: ");
      Serial.println(info.location);
      Serial.print(" Last Update: ");
      Serial.println(info.lastUpdate);
    }

    Serial.println("---- Staff Sensors ----");
    for (const auto &pair : staffSensors) {
      const StaffSensorInfo &info = pair.second;
      Serial.print("ID: ");
      Serial.println(pair.first);
      Serial.print(" Staff ID: ");
      Serial.println(info.staffID);
      Serial.print(" Closest Router: ");
      Serial.println(info.closestRouter);
      Serial.print(" RSSI: ");
      Serial.println(info.rssi);
      Serial.print(" Last Update: ");
      Serial.println(info.lastUpdate);
    }
  }

  // Access room sensor by ID
  const RoomSensorInfo *getRoomSensor(const String &sensorID) const {
    auto it = roomSensors.find(sensorID);
    if (it != roomSensors.end())
      return &it->second;
    return nullptr;
  }

  // Access staff sensor by ID
  const StaffSensorInfo *getStaffSensor(const String &sensorID) const {
    auto it = staffSensors.find(sensorID);
    if (it != staffSensors.end())
      return &it->second;
    return nullptr;
  }

  // Get number of active sensors
  size_t roomSensorCount() const { return roomSensors.size(); }
  size_t staffSensorCount() const { return staffSensors.size(); }
};

#endif // SENSORMANAGER_H
