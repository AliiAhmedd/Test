import { AuthProvider } from "@/contexts/AuthContext";
import BranchProvider from "@/contexts/BranchContext";
import { EmergencyProvider } from "@/contexts/EmergencyContext";
import { RoomProvider } from "@/contexts/RoomContext";
import SocketProvider from "@/contexts/SocketContext";
import { VisitorProvider } from "@/contexts/VisitorContext";
import { Stack } from "expo-router";


export default function RootLayout() {
  // #region agent log
  //fetch('http://127.0.0.1:7242/ingest/3f906ee8-3102-4eb1-a279-d22560295310',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'app/_layout.tsx:14',message:'RootLayout render providers',data:{authProviderType:typeof AuthProvider,branchProviderType:typeof BranchProvider,roomProviderType:typeof RoomProvider,visitorProviderType:typeof VisitorProvider,stackType:typeof Stack,stackScreenType:typeof Stack?.Screen},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H3'})}).catch(()=>{});
  // #endregion agent log
  /* const [dbReady, setDbReady] = useState(false);

  useEffect(() => {
    async function setupDatabase() {
      try {
        await initializeDatabase();
        setDbReady(true);
        console.log('Database initialized');
      } catch (error) {
        console.error('Database initialization failed:', error);
      }
    }
    setupDatabase();
  }, []);

  if (!dbReady) {
    return null; // Show nothing while database initializes
  } */

  return (
    <SocketProvider>
      <AuthProvider>
        <BranchProvider>
          <EmergencyProvider>
            <RoomProvider>
              <VisitorProvider>
                <Stack screenOptions={{ headerShown: false }}>
                  <Stack.Screen name="index" />
                  <Stack.Screen name="(auth)/signin" />
                  <Stack.Screen name="(admin)" />
                  <Stack.Screen name="(staff)" />
                  <Stack.Screen name="(tabs)" />
                </Stack>
              </VisitorProvider>
            </RoomProvider>
          </EmergencyProvider>
        </BranchProvider>
      </AuthProvider>
    </SocketProvider>
  );
}
