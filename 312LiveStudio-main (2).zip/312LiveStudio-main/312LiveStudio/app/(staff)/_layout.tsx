import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Redirect } from 'expo-router';

export default function StaffLayout() {
  const { isAuthenticated, role } = useAuth();

  if (!isAuthenticated) {
    return <Redirect href="/(auth)/signin" />;
  }

  if (role !== 'reception' && role !== 'monitor') {
    return <Redirect href="/(auth)/signin" />;
  }

  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ focused, size, color }) => {
          let iconName: keyof typeof Ionicons.glyphMap;
          switch (route.name) {
            case 'reception':
              iconName = focused ? 'clipboard' : 'clipboard-outline';
              break;
            case 'monitor':
              iconName = focused ? 'eye' : 'eye-outline';
              break;
            case 'emergency':
              iconName = focused ? 'alert' : 'alert-circle-outline';
              break;
            default:
              iconName = 'ellipse-outline';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      {role === 'reception' ? (
        <Tabs.Screen
          name="reception"
          options={{
            title: 'Reception',
          }}
        />
      ) : (
        <Tabs.Screen
          name="monitor"
          options={{
            title: 'Monitor',
          }}
        />
      )}
      <Tabs.Screen
        name="emergency"
        options={{
          title: 'Emergency',
        }}
      />
    </Tabs>
  );
}
