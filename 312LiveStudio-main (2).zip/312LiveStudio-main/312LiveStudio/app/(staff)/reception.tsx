import { useAuth } from "@/contexts/AuthContext";
import { useBranch } from "@/contexts/BranchContext";
import { useRooms } from "@/contexts/RoomContext";
import { useVisitors } from "@/contexts/VisitorContext";
import axios from "axios";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

//const SERVER_URL = "http://127.0.0.1:3000";
const SERVER_URL = "http://172.20.10.2:3000";

export default function Reception() {
  const { checkIn, checkOut, activeVisitors } = useVisitors();
  const { signOut, role } = useAuth();
  const { rooms, getRoomById } = useRooms();
  const { activeBranch } = useBranch();
  const [visitorName, setVisitorName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [roomId, setRoomId] = useState("");
  const [selectedVisitorId, setSelectedVisitorId] = useState<string | null>(
    null,
  );
  const [roomDropdownVisible, setRoomDropdownVisible] = useState(false);

  // Get available rooms (not at max capacity)
  const getAvailableRooms = () => {
    return rooms.filter((room) => {
      const roomVisitors = activeVisitors.filter(
        (v) => v.roomId === room.id || v.roomId === room.name,
      );
      return roomVisitors.length < room.maxCapacity;
    });
  };

  const availableRooms = getAvailableRooms();
  const occupiedRooms = new Set(activeVisitors.map((v) => v.roomId));

  const handleCheckIn = async () => {
    console.log("Attempting to checkin visitor:", visitorName, phoneNumber, roomId);
    if (!visitorName.toString().trim() || !phoneNumber.toString().trim() || !roomId.toString().trim()) {
      Alert.alert('Error', 'Please enter visitor name, phone number, and select a room');
      return;
    }

    const selectedRoom = getRoomById(roomId);
    if (!selectedRoom) {
      Alert.alert("Error", "Invalid room selected");
      return;
    }

    // Check if room is at max capacity
    const roomVisitors = activeVisitors.filter(
      (v) => v.roomId === selectedRoom.id || v.roomId === selectedRoom.name,
    );
    if (roomVisitors.length >= selectedRoom.maxCapacity) {
      Alert.alert(
        "Room Full",
        `Room ${selectedRoom.name} is at maximum capacity (${selectedRoom.maxCapacity}). Please wait until someone checks out.`,
      );
      return;
    }

    try {
      await checkIn(visitorName.trim(), phoneNumber.trim(), selectedRoom.id);
      Alert.alert("Success", "Visitor checked in successfully");
      setVisitorName("");
      setPhoneNumber("");
      setRoomId("");
    } catch (error) {
      Alert.alert("Error", "Failed to check in visitor");
    }
  };

  const selectRoom = (room: { id: string; name: string }) => {
    setRoomId(room.id);
    setRoomDropdownVisible(false);
  };

  const handleCheckOut = async () => {
    if (!selectedVisitorId) {
      Alert.alert("Error", "Please select a visitor to check out");
      return;
    }

    try {
      await checkOut(selectedVisitorId);
      Alert.alert("Success", "Visitor checked out successfully");
      setSelectedVisitorId(null);
    } catch (error) {
      Alert.alert("Error", "Failed to check out visitor");
    }
  };

  /* if (role !== 'reception') {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.permissionContainer}>
          <Text style={styles.permissionText}>
            You do not have permission to view this data. Please contact the administrator.
          </Text>
        </View>
      </SafeAreaView>
    );
  } */

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Reception</Text>
            <Text style={styles.subtitle}>{activeBranch}</Text>
          </View>
          <Pressable onPress={signOut} style={styles.signOutButton}>
            <Text style={styles.signOutText}>Sign Out</Text>
          </Pressable>
        </View>

        {/* Check In Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Check In Visitor</Text>
          <TextInput
            style={styles.input}
            placeholder="Visitor Name"
            value={visitorName}
            onChangeText={setVisitorName}
          />
          <TextInput
            style={styles.input}
            placeholder="Phone Number"
            value={phoneNumber}
            onChangeText={setPhoneNumber}
            keyboardType="phone-pad"
          />
          <Pressable
            style={styles.dropdownButton}
            onPress={() => setRoomDropdownVisible(true)}
          >
            <Text
              style={roomId ? styles.dropdownText : styles.dropdownPlaceholder}
            >
              {roomId ? getRoomById(roomId)?.name || roomId : "Select Room"}
            </Text>
            <Text style={styles.dropdownArrow}>▼</Text>
          </Pressable>
          <Pressable style={styles.checkInButton} onPress={handleCheckIn}>
            <Text style={styles.buttonText}>Check In</Text>
          </Pressable>
          <Pressable
            style={styles.saveToServerButton}
            onPress={async () => {
              try {
                console.log("Saving visitors to server");
                console.log("Active Branch:", activeBranch);
                console.log("Active Visitors:", activeVisitors.length);

                // Send current visitor state to backend
                const response = await axios.post(
                  `${SERVER_URL}/api/visitors/sync`,
                  {
                    visitors: activeVisitors.map((v) => ({
                      name: v.name,
                      phoneNumber: v.phoneNumber,
                      roomId: v.roomId,
                    })),
                  },
                );

                Alert.alert(
                  "Success",
                  `${response.data.synced} visitors saved to database for ${activeBranch}`,
                );
              } catch (error) {
                console.error("Sync error:", error);
                Alert.alert("Error", "Failed to save visitors to server");
              }
            }}
          >
            <Text style={styles.saveToServerButtonText}>
              Save Visitors to Server
            </Text>
          </Pressable>
        </View>

        {/* Room Dropdown Modal */}
        <Modal
          visible={roomDropdownVisible}
          transparent={true}
          animationType="slide"
          onRequestClose={() => setRoomDropdownVisible(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Select Room</Text>
              <FlatList
                data={availableRooms}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => {
                  const roomVisitors = activeVisitors.filter(
                    (v) => v.roomId === item.id || v.roomId === item.name,
                  );
                  const isFull = roomVisitors.length >= item.maxCapacity;
                  return (
                    <Pressable
                      style={[
                        styles.roomOption,
                        isFull && styles.roomOptionDisabled,
                      ]}
                      onPress={() => !isFull && selectRoom(item)}
                      disabled={isFull}
                    >
                      <Text style={styles.roomOptionText}>
                        {item.name} ({roomVisitors.length}/{item.maxCapacity})
                      </Text>
                      {isFull && <Text style={styles.fullText}>Full</Text>}
                    </Pressable>
                  );
                }}
              />
              <Pressable
                style={styles.closeButton}
                onPress={() => setRoomDropdownVisible(false)}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </Pressable>
            </View>
          </View>
        </Modal>

        {/* Check Out Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Check Out Visitor</Text>
          {activeVisitors.length > 0 ? (
            <>
              <ScrollView style={styles.visitorList}>
                {activeVisitors.map((visitor) => (
                  <Pressable
                    key={visitor.id}
                    style={[
                      styles.visitorItem,
                      selectedVisitorId === visitor.id &&
                        styles.visitorItemSelected,
                    ]}
                    onPress={() => setSelectedVisitorId(visitor.id)}
                  >
                    <View>
                      <Text style={styles.visitorName}>{visitor.name}</Text>
                      <Text style={styles.visitorPhone}>
                        {visitor.phoneNumber}
                      </Text>
                      <Text style={styles.visitorRoom}>
                        Room {visitor.roomId}
                      </Text>
                      <Text style={styles.visitorTime}>
                        Since {visitor.checkInTime.toLocaleTimeString()}
                      </Text>
                    </View>
                  </Pressable>
                ))}
              </ScrollView>
              <Pressable
                style={[
                  styles.checkOutButton,
                  !selectedVisitorId && styles.buttonDisabled,
                ]}
                onPress={handleCheckOut}
                disabled={!selectedVisitorId}
              >
                <Text style={styles.buttonText}>Check Out</Text>
              </Pressable>
            </>
          ) : (
            <Text style={styles.emptyText}>No active visitors</Text>
          )}
        </View>

        {/* Room Availability */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Room Availability</Text>
          <View style={styles.roomStats}>
            <View style={styles.roomStat}>
              <Text style={styles.roomStatValue}>{occupiedRooms.size}</Text>
              <Text style={styles.roomStatLabel}>Occupied</Text>
            </View>
            <View style={styles.roomStat}>
              <Text style={styles.roomStatValue}>{availableRooms.length}</Text>
              <Text style={styles.roomStatLabel}>Available</Text>
            </View>
            <View style={styles.roomStat}>
              <Text style={styles.roomStatValue}>{rooms.length}</Text>
              <Text style={styles.roomStatLabel}>Total Rooms</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  subtitle: {
    fontSize: 12,
    color: "#666",
    marginTop: 4,
  },
  signOutButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: "#d32f2f",
    borderRadius: 6,
  },
  signOutText: {
    color: "#fff",
    fontWeight: "600",
  },
  section: {
    backgroundColor: "#fff",
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 12,
    backgroundColor: "#f9f9f9",
  },
  checkInButton: {
    backgroundColor: "#4caf50",
    borderRadius: 8,
    padding: 16,
    alignItems: "center",
    marginTop: 8,
  },
  saveToServerButton: {
    backgroundColor: "#4caf50",
    borderRadius: 8,
    padding: 16,
    alignItems: "center",
    marginTop: 8,
  },
  saveToServerButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  checkOutButton: {
    backgroundColor: "#ff9800",
    borderRadius: 8,
    padding: 16,
    alignItems: "center",
    marginTop: 12,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  visitorList: {
    maxHeight: 200,
    marginBottom: 12,
  },
  visitorItem: {
    padding: 12,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: "#f9f9f9",
  },
  visitorItemSelected: {
    borderColor: "#2069f1",
    backgroundColor: "#e3f2fd",
  },
  visitorName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
    marginBottom: 4,
  },
  visitorPhone: {
    fontSize: 14,
    color: "#666",
    marginBottom: 4,
  },
  visitorRoom: {
    fontSize: 14,
    color: "#666",
    marginBottom: 2,
  },
  visitorTime: {
    fontSize: 12,
    color: "#999",
  },
  dropdownButton: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    backgroundColor: "#f9f9f9",
  },
  dropdownText: {
    fontSize: 16,
    color: "#333",
  },
  dropdownPlaceholder: {
    fontSize: 16,
    color: "#999",
  },
  dropdownArrow: {
    fontSize: 12,
    color: "#666",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 20,
    width: "90%",
    maxWidth: 400,
    maxHeight: "80%",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 16,
  },
  roomOption: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  roomOptionDisabled: {
    opacity: 0.5,
  },
  roomOptionText: {
    fontSize: 16,
    color: "#333",
  },
  fullText: {
    fontSize: 12,
    color: "#d32f2f",
    marginTop: 4,
  },
  closeButton: {
    marginTop: 16,
    padding: 12,
    backgroundColor: "#2069f1",
    borderRadius: 8,
    alignItems: "center",
  },
  closeButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  emptyText: {
    fontSize: 14,
    color: "#999",
    textAlign: "center",
    padding: 20,
    fontStyle: "italic",
  },
  roomStats: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  roomStat: {
    alignItems: "center",
  },
  roomStatValue: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#2069f1",
    marginBottom: 8,
  },
  roomStatLabel: {
    fontSize: 14,
    color: "#666",
  },
  permissionContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  permissionText: {
    fontSize: 16,
    color: "#d32f2f",
    textAlign: "center",
  },
});
