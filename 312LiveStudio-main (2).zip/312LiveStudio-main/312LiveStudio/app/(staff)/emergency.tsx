import React, { useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEmergency, CORE_CODES, MEDICAL_CODES, SECURITY_CODES } from '@/contexts/EmergencyContext';
import { useRooms } from '@/contexts/RoomContext';
import { useBranch } from '@/contexts/BranchContext';

type EmergencyRoom = { id: string; name: string };

export default function StaffEmergency() {
  const { addEvent } = useEmergency();
  const { rooms } = useRooms();
  const { activeBranch } = useBranch();
  const [selectedRoom, setSelectedRoom] = useState<EmergencyRoom | null>(null);

  const roomOptions = useMemo(
    () => rooms.map((room) => ({ id: room.id, name: room.name })),
    [rooms]
  );

  const triggerMedical = (code: string, meaning: string, description: string) => {
    if (!selectedRoom) {
      Alert.alert('Select Room', 'Please select a room before activating this code.');
      return;
    }
    addEvent({
      code,
      meaning,
      description,
      category: 'medical',
      scope: 'branch',
      branchName: activeBranch,
      roomId: selectedRoom.name,
    });
    Alert.alert('Activated', `This alarm is activated: ${code} (${selectedRoom.name})`);
  };

  const triggerGlobal = (
    code: string,
    meaning: string,
    description: string,
    category: 'core' | 'security'
  ) => {
    addEvent({
      code,
      meaning,
      description,
      category,
      scope: 'global',
    });
    Alert.alert('Activated', `This alarm is activated: ${code} (all branches)`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>Emergency</Text>
          <Text style={styles.subtitle}>{activeBranch}</Text>
        </View>

        <View style={styles.section}
        >
          <Text style={styles.sectionTitle}>Medical & Patient Safety Codes</Text>
          <Text style={styles.helperText}>Select room for branch-only activation</Text>
          <View style={styles.roomList}>
            {roomOptions.length > 0 ? (
              roomOptions.map((room) => (
                <Pressable
                  key={room.id}
                  style={[
                    styles.roomOption,
                    selectedRoom?.id === room.id && styles.roomOptionSelected,
                  ]}
                  onPress={() => setSelectedRoom(room)}
                >
                  <Text
                    style={[
                      styles.roomOptionText,
                      selectedRoom?.id === room.id && styles.roomOptionTextSelected,
                    ]}
                  >
                    {room.name}
                  </Text>
                </Pressable>
              ))
            ) : (
              <Text style={styles.emptyText}>No rooms configured for this branch</Text>
            )}
          </View>

          {MEDICAL_CODES.map((item) => (
            <Pressable
              key={item.code}
              style={styles.emergencyButton}
              onPress={() => triggerMedical(item.code, item.meaning, item.description)}
            >
              <Text style={styles.emergencyCode}>{item.code}</Text>
              <Text style={styles.emergencyMeaning}>{item.meaning}</Text>
              <Text style={styles.emergencyDescription}>{item.description}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Core Emergency Codes</Text>
          {CORE_CODES.map((item) => (
            <Pressable
              key={item.code}
              style={[styles.emergencyButton, styles.coreButton]}
              onPress={() => triggerGlobal(item.code, item.meaning, item.description, 'core')}
            >
              <Text style={styles.emergencyCode}>{item.code}</Text>
              <Text style={styles.emergencyMeaning}>{item.meaning}</Text>
              <Text style={styles.emergencyDescription}>{item.description}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Security & Infrastructure Codes</Text>
          {SECURITY_CODES.map((item) => (
            <Pressable
              key={item.code}
              style={[styles.emergencyButton, styles.securityButton]}
              onPress={() => triggerGlobal(item.code, item.meaning, item.description, 'security')}
            >
              <Text style={styles.emergencyCode}>{item.code}</Text>
              <Text style={styles.emergencyMeaning}>{item.meaning}</Text>
              <Text style={styles.emergencyDescription}>{item.description}</Text>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  subtitle: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  section: {
    backgroundColor: '#fff',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  helperText: {
    fontSize: 12,
    color: '#666',
    marginBottom: 12,
  },
  roomList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  roomOption: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  roomOptionSelected: {
    backgroundColor: '#2069f1',
    borderColor: '#2069f1',
  },
  roomOptionText: {
    fontSize: 12,
    color: '#333',
  },
  roomOptionTextSelected: {
    color: '#fff',
    fontWeight: '600',
  },
  emergencyButton: {
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
    backgroundColor: '#fff7f7',
  },
  coreButton: {
    backgroundColor: '#fff1f0',
  },
  securityButton: {
    backgroundColor: '#fff7e6',
  },
  emergencyCode: {
    fontSize: 16,
    fontWeight: '700',
    color: '#d32f2f',
    marginBottom: 4,
  },
  emergencyMeaning: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  emergencyDescription: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  emptyText: {
    fontSize: 12,
    color: '#999',
    marginBottom: 8,
  },
});
