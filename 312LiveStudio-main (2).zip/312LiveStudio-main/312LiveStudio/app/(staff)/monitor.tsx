import GridMap from "@/components/GridMap";
import { useAuth } from "@/contexts/AuthContext";
import { useBranch } from "@/contexts/BranchContext";
import { useEmergency } from "@/contexts/EmergencyContext";
import { useRooms } from "@/contexts/RoomContext";
import { useSocket } from "@/contexts/SocketContext";
import { useVisitors } from "@/contexts/VisitorContext";
import React, { useEffect, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
export default function Monitor() {
  const { activeVisitors, getVisitorsByRoom } = useVisitors();
  const { signOut, role } = useAuth();
  const { rooms, getRoomById, mapDetails } = useRooms();
  const [staffRooms, setStaffRooms] = useState<
    Record<number, { roomID: number; roomName: string }>
  >({});

  const { activeBranch } = useBranch();
  const { getBranchEvents, getGlobalEvents } = useEmergency();
  const [roomTemperatures, setRoomTemperatures] = useState<
    Record<string, number | null>
  >({});
  const { liveAlerts } = useSocket();

  const SERVER_URL = "http://192.168.42.16:3000";

  const occupiedRooms = new Set(activeVisitors.map((v) => v.roomId));
  const branchAlerts = getBranchEvents(activeBranch);
  const globalAlerts = getGlobalEvents();
  const { staffLocations } = useSocket();

  useEffect(() => {
    let isCancelled = false;
    const pollTemperatures = async () => {
      try {
        const entries = await Promise.all(
          rooms.map(async (room) => {
            try {
              const response = await fetch(
                `${SERVER_URL}/api/roomTemperature/${room.id}`,
              );
              const data = await response.json();
              console.log(data);
              return [
                room.id,
                typeof data.temperature === "number" ? data.temperature : null,
              ];
            } catch (error) {
              return [room.id, null];
            }
          }),
        );
        if (!isCancelled) {
          setRoomTemperatures(Object.fromEntries(entries));
        }
      } catch (error) {
        // swallow fetch errors to avoid breaking the UI
      }
    };

    if (rooms.length > 0) {
      pollTemperatures();
      const intervalId = setInterval(pollTemperatures, 5000);
      return () => {
        isCancelled = true;
        clearInterval(intervalId);
      };
    }
  }, [rooms]);

  // Poll Staff Monitoring
  useEffect(() => {
    let isCancelled = false;
    const pollStaffRooms = async () => {
      try {
        // replace this array with your actual staff IDs to monitor
        const staffIDs = [104];
        const entries = await Promise.all(
          staffIDs.map(async (staffID) => {
            try {
              const response = await fetch(
                `${SERVER_URL}/api/roomEntered/${staffID}`,
              );
              const data = await response.json();
              console.log(data);
              const roomName =
                getRoomById(data.currentRoomID)?.name || "Unknown";
              return [staffID, { roomID: data.currentRoomID, roomName }];
            } catch {
              return [staffID, { roomID: 0, roomName: "Unknown" }];
            }
          }),
        );
        if (!isCancelled) setStaffRooms(Object.fromEntries(entries));
      } catch (error) {
        console.error("Failed to fetch staff rooms:", error);
      }
    };

    pollStaffRooms();
    const intervalId = setInterval(pollStaffRooms, 5000);

    return () => {
      isCancelled = true;
      clearInterval(intervalId);
    };
  }, [rooms]);

  /*   if (role !== 'monitor') {
      return (
        <SafeAreaView style={styles.container}>
          <View style={styles.permissionContainer}>
            <Text style={styles.permissionText}>
              You do not have permission to view this data. Please contact the administrator.
            </Text>
          </View>
        </SafeAreaView>
      );
    }  */
  console.log(getRoomById(41));

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Monitor</Text>
            <Text style={styles.subtitle}>{activeBranch}</Text>
          </View>
          <Pressable onPress={signOut} style={styles.signOutButton}>
            <Text style={styles.signOutText}>Sign Out</Text>
          </Pressable>
        </View>

        {/* Read-only Map */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Hospital Map</Text>
          {mapDetails.rows > 0 && mapDetails.columns > 0 ? (
            <View style={styles.mapContainer}>
              <GridMap
                rows={mapDetails.rows}
                cols={mapDetails.columns}
                cellSize={32}
                saved={new Set(rooms.flatMap((room) => room.cells))}
                selected={new Set()}
                onCellPress={() => {}}
              />
            </View>
          ) : (
            <Text style={styles.emptyText}>
              No map configured for this branch
            </Text>
          )}
        </View>

        {/* Live Alerts */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Live Alerts</Text>
          {branchAlerts.length === 0 &&
          globalAlerts.length === 0 &&
          liveAlerts.length === 0 ? (
            <Text style={styles.emptyText}>No active alerts</Text>
          ) : (
            <>
              {liveAlerts.length > 0 && (
                <View style={styles.alertGroup}>
                  <Text style={styles.alertGroupTitle}>Patient Alerts</Text>
                  {liveAlerts.map((alert) => (
                    <View key={alert.id} style={styles.alertCard}>
                      <Text style={styles.alertCode}>{alert.code}</Text>
                      <Text style={styles.alertMeaning}>{alert.meaning}</Text>
                      <Text style={styles.alertDescription}>
                        {alert.description}
                      </Text>
                      <Text style={styles.alertMeta}>
                        Room: {alert.roomId || "N/A"} •{" "}
                        {new Date(alert.timestamp).toLocaleString()}
                      </Text>
                    </View>
                  ))}
                </View>
              )}
              {branchAlerts.length > 0 && (
                <View style={styles.alertGroup}>
                  <Text style={styles.alertGroupTitle}>Branch Alerts</Text>
                  {branchAlerts.map((alert) => (
                    <View key={alert.id} style={styles.alertCard}>
                      <Text style={styles.alertCode}>{alert.code}</Text>
                      <Text style={styles.alertMeaning}>{alert.meaning}</Text>
                      <Text style={styles.alertDescription}>
                        {alert.description}
                      </Text>
                      <Text style={styles.alertMeta}>
                        Room: {alert.roomId || "N/A"} •{" "}
                        {new Date(alert.timestamp).toLocaleString()}
                      </Text>
                    </View>
                  ))}
                </View>
              )}
              {globalAlerts.length > 0 && (
                <View style={styles.alertGroup}>
                  <Text style={styles.alertGroupTitle}>Global Alerts</Text>
                  {globalAlerts.map((alert) => (
                    <View key={alert.id} style={styles.alertCard}>
                      <Text style={styles.alertCode}>{alert.code}</Text>
                      <Text style={styles.alertMeaning}>{alert.meaning}</Text>
                      <Text style={styles.alertDescription}>
                        {alert.description}
                      </Text>
                      <Text style={styles.alertMeta}>
                        {new Date(alert.timestamp).toLocaleString()}
                      </Text>
                    </View>
                  ))}
                </View>
              )}
            </>
          )}
        </View>

        {/* Room Status Grid */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Room Status</Text>
          <View style={styles.roomGrid}>
            {rooms.map((room) => {
              const roomVisitors = getVisitorsByRoom(room.id);
              const isOccupied = roomVisitors.length > 0;
              const isFull = roomVisitors.length >= room.maxCapacity;
              const currentTemp = roomTemperatures[room.id];

              return (
                <View
                  key={room.id}
                  style={[
                    styles.roomCard,
                    isFull
                      ? styles.roomFull
                      : isOccupied
                        ? styles.roomOccupied
                        : styles.roomAvailable,
                  ]}
                >
                  <Text style={styles.roomId}>{room.name}</Text>
                  <Text
                    style={[
                      styles.roomStatus,
                      isFull
                        ? styles.statusFull
                        : isOccupied
                          ? styles.statusOccupied
                          : styles.statusAvailable,
                    ]}
                  >
                    {isFull ? "Full" : isOccupied ? "Occupied" : "Available"}
                  </Text>
                  <Text style={styles.roomCapacity}>
                    {roomVisitors.length}/{room.maxCapacity}
                  </Text>
                  {roomVisitors.length > 0 && (
                    <View style={styles.visitorsList}>
                      {roomVisitors.map((visitor) => (
                        <Text key={visitor.id} style={styles.visitorName}>
                          {visitor.name}
                        </Text>
                      ))}
                    </View>
                  )}
                </View>
              );
            })}
          </View>
        </View>

        {/* Current Visitors List */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Current Visitors</Text>
          {activeVisitors.length > 0 ? (
            activeVisitors.map((visitor) => {
              const room = getRoomById(visitor.roomId);
              return (
                <View key={visitor.id} style={styles.visitorCard}>
                  <Text style={styles.visitorName}>{visitor.name}</Text>
                  <Text style={styles.visitorPhone}>{visitor.phoneNumber}</Text>
                  <Text style={styles.visitorRoom}>
                    Room {room?.name || visitor.roomId}
                  </Text>
                  <Text style={styles.visitorTime}>
                    Checked in: {visitor.checkInTime.toLocaleString()}
                  </Text>
                </View>
              );
            })
          ) : (
            <Text style={styles.emptyText}>No active visitors</Text>
          )}
        </View>
        {/* Staff Monitoring Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Staff Monitoring</Text>
          {Object.keys(staffLocations).length === 0 ? (
            <Text style={styles.emptyText}>No staff data available</Text>
          ) : (
            <View style={styles.tempGrid}>
              {Object.values(staffLocations).map((info) => (
                <View key={info.staffID} style={styles.tempCard}>
                  <Text style={styles.roomId}>Staff ID: {info.staffID}</Text>
                  <Text style={styles.roomTemperature}>
                    Room: {getRoomById(info.roomID)?.name} ({info.roomID})
                  </Text>
                </View>
              ))}
            </View>
          )}
        </View>

        {/* Temperature Monitoring Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Temperature Monitoring</Text>
          <View style={styles.tempGrid}>
            {rooms.length === 0 ? (
              <Text style={styles.emptyText}>No rooms available</Text>
            ) : (
              rooms.map((room) => {
                const temp = roomTemperatures[room.id];
                return (
                  <View key={room.id} style={styles.tempCard}>
                    <Text style={styles.roomId}>{room.name}</Text>
                    <Text style={styles.roomTemperature}>
                      {temp !== undefined && temp !== null
                        ? `${temp.toFixed(1)}°C`
                        : "—"}
                    </Text>
                  </View>
                );
              })
            )}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  subtitle: {
    fontSize: 12,
    color: "#666",
    marginTop: 4,
  },
  visitorsList: {
    width: "100%",
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: "#e0e0e0",
  },
  signOutButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: "#d32f2f",
    borderRadius: 6,
  },
  signOutText: {
    color: "#fff",
    fontWeight: "600",
  },
  section: {
    backgroundColor: "#fff",
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 16,
  },
  mapContainer: {
    alignItems: "center",
  },
  alertGroup: {
    marginBottom: 12,
  },
  alertGroupTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#333",
    marginBottom: 8,
  },
  alertCard: {
    borderWidth: 1,
    borderColor: "#f0f0f0",
    borderRadius: 8,
    padding: 10,
    marginBottom: 8,
    backgroundColor: "#fff7f7",
  },
  alertCode: {
    fontSize: 14,
    fontWeight: "700",
    color: "#d32f2f",
  },
  alertMeaning: {
    fontSize: 12,
    fontWeight: "600",
    color: "#333",
    marginTop: 4,
  },
  alertDescription: {
    fontSize: 12,
    color: "#666",
    marginTop: 4,
  },
  alertMeta: {
    fontSize: 11,
    color: "#999",
    marginTop: 6,
  },
  roomGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  roomCard: {
    width: "30%",
    minWidth: 100,
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    borderWidth: 2,
  },
  roomAvailable: {
    backgroundColor: "#e8f5e9",
    borderColor: "#4caf50",
  },
  roomOccupied: {
    backgroundColor: "#fff3e0",
    borderColor: "#ff9800",
  },
  roomFull: {
    backgroundColor: "#ffebee",
    borderColor: "#f44336",
  },
  roomId: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
    marginBottom: 4,
  },
  roomStatus: {
    fontSize: 12,
    fontWeight: "600",
    marginBottom: 4,
  },
  roomTemperature: {
    fontSize: 12,
    color: "#333",
    marginBottom: 4,
  },
  statusAvailable: {
    color: "#4caf50",
  },
  statusOccupied: {
    color: "#ff9800",
  },
  statusFull: {
    color: "#f44336",
  },
  roomCapacity: {
    fontSize: 12,
    color: "#666",
    marginTop: 4,
  },
  visitorCard: {
    padding: 12,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: "#f9f9f9",
  },
  visitorName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
    marginBottom: 4,
  },
  visitorPhone: {
    fontSize: 14,
    color: "#666",
    marginBottom: 4,
  },
  visitorRoom: {
    fontSize: 14,
    color: "#666",
    marginBottom: 2,
  },
  visitorTime: {
    fontSize: 12,
    color: "#999",
  },
  emptyText: {
    fontSize: 14,
    color: "#999",
    textAlign: "center",
    padding: 20,
    fontStyle: "italic",
  },
  tempPlaceholder: {
    padding: 24,
    backgroundColor: "#f5f5f5",
    borderRadius: 8,
    alignItems: "center",
  },
  tempText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#666",
    marginBottom: 8,
  },
  tempSubtext: {
    fontSize: 12,
    color: "#999",
    textAlign: "center",
  },
  permissionContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  permissionText: {
    fontSize: 16,
    color: "#d32f2f",
    textAlign: "center",
  },
  tempGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
    justifyContent: "space-between",
  },

  tempCard: {
    width: "48%", // two cards per row
    padding: 16,
    borderRadius: 12,
    backgroundColor: "#e3f2fd",
    alignItems: "center",
    marginBottom: 12,
  },
});
