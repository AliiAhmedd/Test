import {View,Text} from 'react-native';

export default function Settings() {
    return(
        <View>
            <Text>Settings Screen</Text>
        </View>
    )
}