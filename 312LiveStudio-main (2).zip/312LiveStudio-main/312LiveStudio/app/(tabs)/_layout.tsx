import { HapticTab } from '@/components/haptic-tab';
import { Ionicons } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import React from 'react';

export default function TabLayout(){
    return(
        <Tabs
        screenOptions={({ route }) => ({
            headerShown:false,
            //tabBarButton:HapticTab,
            tabBarIcon:({focused,size,color})=>{
            let iconName : keyof typeof Ionicons.glyphMap;
            switch (route.name) {
            case "settings":
              iconName = focused ? "hammer" : "hammer-outline";
              break;
            case "register":
              iconName = focused ? "log-in" : "log-in-outline";
              break;
            case "index":
              iconName = focused ? "map" : "map-outline";
              break;
            default:
              iconName = "ellipse-outline";
            }

            return <Ionicons name={iconName} size={size} color={color} aria-label={route.name}/>;
            }
            })}>
            <Tabs.Screen
            name='index'
            options={{
                title: 'Map'
            }}
            />

            <Tabs.Screen
                name="register"
                options={{
                    title:"Register"
                }}
                />
            <Tabs.Screen
                name='settings'
                options={{
                    title:"Settings"
                }}
                />
        </Tabs>
    )
}