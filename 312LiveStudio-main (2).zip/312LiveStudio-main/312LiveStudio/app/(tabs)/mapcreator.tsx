import React, { useCallback, useState } from "react";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import GridMap from "../../components/GridMap";
import Ionicons from "@expo/vector-icons/build/Ionicons";

export default function mapCreator() {
  const [rows, setRows] = useState("");
  const [cols, setCols] = useState("");
  const [roomName,setRoomName] = useState("");
  const [maxOccupancy,setMaxOccupancy] = useState("");
  const [showForm,setShowForm] = useState(false);
  const [selected,setSelected] = useState<Set<number>>(new Set());
  const [saved,setSaved] = useState<Set<number>>(new Set());
  const cellSize=16;
  const handleCellPress = useCallback((index:number)=>{
    console.log("Saved Cells:", Array.from(saved));
    console.log("Cell pressed:", index);
    setSelected((prev) => {
      const next = new Set(prev);
      if(saved.has(index)) {
        console.log("Cell is saved, cannot select:", index);
        return next; 
      }
      if(next.has(index) ) next.delete(index); // deselect
      else next.add(index);
      console.log("Selected cells:", Array.from(next));
      //next(index).style.backgroundColor = "#2069f1";
      return next;
      
    });
  },[saved]);
  const clearSelection = ()=>{
    console.log("Clearing selection");
    setSelected(new Set());
  }
  const saveRoom = ()=>{
    console.log("Saving Room");
    console.log("Room Name:", roomName);
    console.log("Max Occupancy:", maxOccupancy);
    console.log("Selected Cells:", Array.from(selected));
    setSaved(prev => new Set([...prev, ...selected]));
    
    // clear form.
    setRoomName("");
    setMaxOccupancy("");
    setSelected(new Set());
    setShowForm(false);
    
  }
  const checkVals = ()=>{
    console.log("Saved Cells:", Array.from(saved));
    console.log("Room Name:", roomName);
    console.log("Max Occupancy:", maxOccupancy);
    console.log("Selected Cells:", Array.from(selected));
  }
  return (
    <SafeAreaView
      style={styles.page}
    >
      <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Map Creator</Text>
        <Text style={styles.subtitle}>
            Pick a map size, select cells for a room, then save it.
        </Text>
      </View>
      {/*Instructions*/}
      <View style={styles.card}>
          <Text style={styles.cardTitle}>How it works</Text>
          <View style={styles.steps}>
            <Text style={styles.stepText}>1. Select the map size</Text>
            <Text style={styles.stepText}>
              2. Select squares for the room, then press "Add Room"
            </Text>
            <Text style={styles.stepText}>
              3. Fill in details and press "Save Room"
            </Text>
          </View>
        </View>
        {/*Map Size Entry*/}
      <View style={styles.card}>
          <Text style={styles.cardTitle}>Map Size</Text>

          <View style={styles.inputRow}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Rows</Text>
              <TextInput
                accessible={true}
                accessibilityLabel="Rows Input"
                style={styles.input}
                value={rows}
                onChangeText={(rows) => setRows(rows)}
                keyboardType="numeric"
                placeholder="e.g. 10"
                placeholderTextColor="#9ca3af"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Columns</Text>
              <TextInput
                accessible={true}
                accessibilityLabel="Columns Input"
                style={styles.input}
                value={cols}
                onChangeText={(cols) => setCols(cols)}
                keyboardType="numeric"
                inputMode="numeric"
                placeholder="e.g. 12"
                placeholderTextColor="#9ca3af"
              />
            </View>
          </View>
        </View>
      {/* <Text>Map</Text>
      <TextInput 
        accessible={true}
        accessibilityLabel="Rows Input"
        //style = {styles.input}
        value={rows}
        onChangeText={(rows) => setRows(rows)}
        keyboardType="numeric"
        placeholder="Rows:"
      />
      <TextInput 
        accessible={true}
        accessibilityLabel="Columns Input"
        //style = {styles.input}
        value={cols}
        onChangeText={(cols) => setCols(cols)}
        keyboardType="numeric"
        inputMode="numeric"
        placeholder="Columns:"
      /> */}

      {/*add validation -> before submitting*/}
      <View style={styles.gridWrap}>
        <GridMap
          rows = {parseInt(rows) || 0}
          cols = {parseInt(cols) || 0}
          cellSize= {48}
          selected = {selected}
          saved = {saved}
          onCellPress = {handleCellPress}
        />
      </View>

      <View style={styles.actionsRow}>
        <Pressable
          style={styles.primaryBtn}
          onPress={()=>setShowForm(true)}
        >
          <Text style={styles.primaryBtnText}>
            Add Room
          </Text>
        </Pressable>      
      <Pressable
        style={styles.ghostBtn}
        onPress={clearSelection}
        >
          <Text style={styles.ghostBtnText}>
            Clear Selection
          </Text>
        </Pressable>
      </View>
      {showForm && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Room Details</Text>
          <View style={styles.formGroup}>
          <Text style={styles.inputLabel}>Room Name:
            <TextInput
                value={roomName}
                accessible={true}
                accessibilityLabel="Room Name Input"
                onChangeText={(roomName)=>setRoomName(roomName)}
                placeholder='e.g. Ward A'
                style={styles.input}
            ></TextInput>
        </Text>
        </View>
        <View style={styles.formGroup}>
        <Text style={styles.inputLabel}> Max Occupancy:
            <TextInput
                value={maxOccupancy}
                accessible={true}
                accessibilityLabel="Room Max Occupancy Input"
                onChangeText={(maxOccupancy)=>setMaxOccupancy(maxOccupancy)}
                placeholder='e.g. 4'
                keyboardType="numeric"
                style={styles.input}
            ></TextInput>
        </Text>
        </View>
        <Pressable
          style={styles.primaryBtn}
          onPress={saveRoom}
        >
          <Text style={styles.primaryBtnText}>
            Save Room
          </Text>
        </Pressable>
        
        </View>)}

        <Pressable
          onPress={checkVals}
        >
          <Text>
            Check Values
          </Text>
        </Pressable>
      <View style={styles.keyContainer}>
      <View style={styles.keyItem}>
        <View style={[styles.keyBox, styles.selected]}>
          <Ionicons name="triangle"/>
        </View>
        <Text style={styles.label}> Selected</Text>
      </View>
        <View></View>
      <View style={styles.keyItem}>
        <View style={[styles.keyBox, styles.saved]} />
        <Text style={styles.label}>Saved</Text>
      </View>
    </View>
    </View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  clearBtn:{
    color:'red'
  },
  keyContainer: {
    flexDirection: "row",
    gap: 16,
    marginVertical: 8,
    alignItems: "center",
  },
  keyItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  keyBox: {
    width: 14,
    height: 14,
    borderRadius: 3,
  },
  selected: {
    backgroundColor: "#2069f1",
  },
  saved: {
    backgroundColor: "#52ec5f",
  },
  label: {
    fontSize: 12,
  },
  page: {
    flex: 1,
    backgroundColor: "#f3f4f6",
  },
  container: {
    flex: 1,
    padding: 16,
    gap: 12,
  },

  header: {
    paddingHorizontal: 4,
    gap: 6,
  },
  title: {
    fontSize: 24,
    fontWeight: "800",
    color: "#111827",
  },
  subtitle: {
    fontSize: 13,
    color: "#6b7280",
    lineHeight: 18,
  },

  card: {
    backgroundColor: "#ffffff",
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
    gap: 10,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: "#111827",
  },

  steps: {
    gap: 6,
  },
  stepText: {
    fontSize: 13,
    color: "#374151",
    lineHeight: 18,
  },

  inputRow: {
    flexDirection: "row",
    gap: 10,
  },
  inputGroup: {
    flex: 1,
    gap: 6,
  },
  inputLabel: {
    fontSize: 12,
    color: "#6b7280",
    fontWeight: "700",
  },
  input: {
    height: 44,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: "#f9fafb",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.10)",
    color: "#111827",
    fontSize: 14,
  },

  cardHeaderRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 10,
  },

  gridWrap: {
    padding: 10,
    borderRadius: 14,
    backgroundColor: "#f9fafb",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    alignSelf: "flex-start",
  },

  actionsRow: {
    flexDirection: "row",
    gap: 10,
  },
  primaryBtn: {
    flex: 1,
    height: 46,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#111827",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.12)",
  },
  primaryBtnText: {
    color: "#ffffff",
    fontWeight: "800",
    fontSize: 14,
  },

  ghostBtn: {
    flex: 1,
    height: 46,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.10)",
  },
  ghostBtnText: {
    color: "#111827",
    fontWeight: "800",
    fontSize: 14,
  },

  formGroup: {
    gap: 6,
  },

  debugBtn: {
    alignSelf: "center",
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  debugBtnText: {
    color: "#6b7280",
    fontSize: 12,
    textDecorationLine: "underline",
  },
  keyLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#111827",
  },
})
