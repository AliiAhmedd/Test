import { useAuth } from '@/contexts/AuthContext';
import { Redirect } from 'expo-router';
import { ActivityIndicator, View } from 'react-native';

export default function Index() {
  const { isAuthenticated, role, isLoading } = useAuth();

  // Show loading while checking auth
  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  if (!isAuthenticated) {
    return <Redirect href="/(auth)/signin" />;
  }

  // Redirect based on role
  if (role === 'admin') {
    return <Redirect href="/(admin)/dashboard" />;
  }

  if (role === 'reception') {
    return <Redirect href="/(staff)/reception" />;
  }

  if (role === 'monitor') {
    return <Redirect href="/(staff)/monitor" />;
  }

  return <Redirect href="/(auth)/signin" />;
}