import ConfirmModal from '@/components/ConfirmModal';
import GridMap from '@/components/GridMap';
import HelpModal from '@/components/HelpModal';
import { useBranch } from '@/contexts/BranchContext';
import { useRooms } from '@/contexts/RoomContext';
import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

/* const SERVER_URL =
  Platform.OS === "web"
    ? "http://localhost:3000"
    : "http://192.168.0.42:3000"; // machine IP */
//const SERVER_URL = "http://127.0.0.1:3000";
const SERVER_URL = "http://172.20.10.2:3000";
export default function MapCreator() {
  const { rooms, addRoom, removeRoom, updateRoomCapacity, saveMap } = useRooms();
  const { branches, activeBranch, addBranch, setActiveBranch } = useBranch();
  const [rows] = useState('5');
  const [cols] = useState('5');
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [roomName, setRoomName] = useState('');
  const [maxCapacity, setMaxCapacity] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [branchModalVisible, setBranchModalVisible] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  const [showHelp, setShowHelp] = useState(false);
  const [successPopup, setSuccessPopup] = useState(false);
  const [ShowError,setShowError] = useState(false);
  const [errorMsg,setErrorMsg] = useState('');

  const popupError = (message:string)=>{
    setErrorMsg(message);
    setShowError(true);
  }
    const [confirm, setConfirm] = useState<{
    roomId: string;
    roomName: string;
  } | null>(null);
  type Room = {
    id: string;
    name: string;
    maxCapacity: number;
    cells: number[];
  };
  type MapLayout = {
    rows: number;
    columns: number;
    rooms: Room[]; // arr of rooms
  };
  const [saved, setSaved] = useState<Set<number>>(rooms ? new Set(rooms.flatMap((room)=>room.cells)):new Set());
  useEffect(() => {
    console.log('Rooms updated:', rooms);
    setSaved(new Set(rooms.flatMap((room) => room.cells)));
  }, [rooms]);
  const handleRemoveRoom = (roomId: string, roomName: string) => {
    setConfirm({ roomId, roomName });
  };
  const doRemove = async () => {
    if (!confirm) return;
    setRemoving(true);
    try {
      await removeRoom(confirm.roomId);
      
    } finally {
      setRemoving(false);
      setConfirm(null);
    }
  };
  useEffect(()=>{
    setSaved(new Set(rooms.flatMap((room)=>room.cells)));
  },[rooms])
  const handleCellPress = useCallback((index: number) => {
    console.log('Saved Cells:', Array.from(saved));
    console.log('Cell pressed:', index);
    setSelected((prev) => {
      const next = new Set(prev);
      if (saved.has(index)) {
        console.log('Cell is saved, cannot select:', index);
        return next;
      }
      if (next.has(index)) next.delete(index); // deselect
      else next.add(index);
      console.log('Selected cells:', Array.from(next));
      //next(index).style.backgroundColor = "#2069f1";
      return next;
    });
  }, [saved]);

  useEffect(() => {
    setSelected(new Set());
    setSaved(new Set());
  }, [activeBranch]);

  const saveRoom = () => {
    console.log('Saving Room');
    console.log('Room Name:', roomName);
    console.log('Max Occupancy:', maxCapacity);
    console.log('Selected Cells:', Array.from(selected));
    setSaved((prev) => new Set([...prev, ...selected]));

    // clear form.
    setRoomName('');
    setMaxCapacity('');
    setSelected(new Set());
    setShowAddForm(false);
  };
  const clearSelection = () => {
    setSelected(new Set());
  };
  const [showErrorOnRoom, setShowErrorOnRoom] = useState(false);
  const handleAddRoom = async () => {
    if (!roomName.trim()) {
      console.log("Displaying modal for empty room name");
      setShowErrorOnRoom(true);

      //Alert.alert('Error', 'Please enter a room name');
      popupError('Please enter a room name');
      return;
    }

    const capacity = parseInt(maxCapacity);
    if (isNaN(capacity) || capacity < 1) {
      //Alert.alert('Error', 'Please enter a valid capacity (minimum 1)');
      popupError('Please enter a valid capacity (minimum 1)');
      return;
    }

    // Check if room name already exists
    if (rooms.some((r) => r.name.toLowerCase() === roomName.trim().toLowerCase())) {
      //Alert.alert('Error', 'A room with this name already exists');
      popupError('A room with this name already exists');
      return;
    }

    try {
      await addRoom(roomName.trim(), capacity, Array.from(selected));
      setSaved((prev) => new Set([...prev, ...selected]));
      setSelected(new Set());
      setSuccessPopup(true);
      //Alert.alert('Success', 'Room added successfully');
      setRoomName('');
      setMaxCapacity('');
      setShowAddForm(false);
    } catch (error) {
      //Alert.alert('Error', 'Failed to add room');
      popupError('Failed to add room');
    }
  };
/* 
  const handleRemoveRoom = (roomId: string, roomName: string) => {
    console.log('Removing Room:', roomId, roomName);
    
    Alert.alert('Remove Room', `Are you sure you want to remove ${roomName}?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          try {
            await removeRoom(roomId);
            Alert.alert('Success', 'Room removed successfully');
          } catch (error) {
            Alert.alert('Error', 'Failed to remove room');
            console.log('Error Removing Room: ', error);
          }
        },
      },
    ]);
  }; */
  const [removing,setRemoving] = useState<boolean>(false);
  const [editingRoomId, setEditingRoomId] = useState<string | null>(null);
  const [editCapacity, setEditCapacity] = useState('');

  const handleUpdateCapacity = (roomId: string, currentCapacity: number) => {
    setEditingRoomId(roomId);
    setEditCapacity(currentCapacity ? currentCapacity.toString() : '');
  };

  const saveCapacityUpdate = async () => {
    if (!editingRoomId) return;

    const capacity = parseInt(editCapacity);
    if (isNaN(capacity) || capacity < 1) {
      //Alert.alert('Error', 'Please enter a valid capacity (minimum 1)');
      popupError('Please enter a valid capacity (minimum 1)');
      return;
    }

    try {
      await updateRoomCapacity(editingRoomId, capacity);
      Alert.alert('Success', 'Room capacity updated');
      console.log('Updated Room Capacity:', editingRoomId, capacity);
      setEditingRoomId(null);
      setEditCapacity('');
    } catch (error) {
      Alert.alert('Error', 'Failed to update capacity');
    }
  };

  const handleAddBranch = async () => {
    const result = await addBranch(newBranchName);
    if (!result.success) {
      //Alert.alert('Error', result.error || 'Failed to add branch');
      popupError(result.error || 'Failed to add branch');
      return;
    }
    await setActiveBranch(newBranchName.trim());
    setNewBranchName('');
    Alert.alert('Success', 'Branch added');
  };

  const refreshRooms = async () => {
    try {
      setSaved(new Set(rooms.flatMap((room) => room.cells)));
    } catch (error) {
      popupError('Failed to refresh rooms');
      console.error('Error refreshing rooms:', error);
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <HelpModal
        visible={showHelp} 
        onClose={() => setShowHelp(false)} 
        title="Instructions" 
        lines={["Select the map size","Select squares for the room, then press \"Add Room\"","Fill in details and press \"Save Room\""]}>
      </HelpModal>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Pressable onPress={() => setShowHelp(true)}>
            <Ionicons name="help" style={{ fontSize: 24 }} />
          </Pressable>
          <Text style={styles.title}>Map Creator</Text>
          <Pressable style={styles.addButton} onPress={() => setShowAddForm(!showAddForm)}>
            <Text style={styles.addButtonText}>{showAddForm ? 'Cancel' : 'Add Room'}</Text>
          </Pressable>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Active Branch</Text>
          <Pressable style={styles.branchSelector} onPress={() => setBranchModalVisible(true)}>
            <Text style={styles.branchSelectorText}>{activeBranch}</Text>
            <Text style={styles.branchSelectorArrow}>▼</Text>
          </Pressable>
        </View>

        {/* Add Room Form */}
        {showAddForm && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Add New Room</Text>
            <TextInput
              style={styles.input}
              placeholder="Room Name (e.g., Room 7)"
              value={roomName}
              onChangeText={setRoomName}
            />
            <TextInput
              style={styles.input}
              placeholder="Max Capacity"
              value={maxCapacity}
              onChangeText={setMaxCapacity}
              keyboardType="numeric"
            />
            <Pressable style={styles.saveButton} onPress={handleAddRoom}>
              <Text style={styles.saveButtonText}>Save Room</Text>
            </Pressable>
          </View>
        )}

        {/* Grid Map Creator */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Visual Map Creator</Text>
          <Text style={styles.helperText}>Grid size is fixed at 5 x 5.</Text>
          <Pressable
          onPress={()=>{
            refreshRooms();
          }}>
            <Text style={styles.helperText}><Ionicons name ="refresh-circle-outline"></Ionicons> Refresh Rooms</Text>
          </Pressable>
          <View style={styles.inputRow}>
            <TextInput
              style={styles.gridInput}
              placeholder="Rows"
              value={rows}
              editable={false}
            />
            <TextInput
              style={styles.gridInput}
              placeholder="Columns"
              value={cols}
              editable={false}
            />
          </View>
          {parseInt(rows) > 0 && parseInt(cols) > 0 && (
            <View style={styles.mapContainer}>
              <GridMap
                rows={parseInt(rows) || 0}
                cols={parseInt(cols) || 0}
                cellSize={48}
                saved={saved}
                selected={selected}
                onCellPress={handleCellPress}
              />
              <Pressable style={styles.clearButton} onPress={clearSelection}>
                <Text style={styles.clearButtonText}>Clear Selection</Text>
              </Pressable>
            </View>
          )}
            <View style={styles.keyContainer}>
              <View style={styles.keyItem}>
                <View style={[styles.keyBox, styles.selected]} />
                <Ionicons  name="triangle"/>
                <Text style={styles.label}>Selected</Text>
              </View>
          
              <View style={styles.keyItem}>
                <View style={[styles.keyBox, styles.saved]} />
                <Ionicons  name="square"/>
                <Text style={styles.label}>Saved</Text>
              </View>
            </View>
        </View>
        <View>
          {showErrorOnRoom &&(

          
            <ConfirmModal
              visible={true}
              title="Error"
              message="Please enter a room name"
              confirmText="OK"
              onConfirm={() => {setShowErrorOnRoom(false);}}
              onCancel={()=>{setShowErrorOnRoom(false);}}
          ></ConfirmModal>
          )}
          {successPopup && (
            <ConfirmModal
              visible={true}
              title='Success'
              message='Saved successfully!'
              confirmText="OK"
              onConfirm={() => {setSuccessPopup(false);}}
              onCancel={()=>{setSuccessPopup(false);}}
          ></ConfirmModal>
          )}
          {ShowError && (
            <ConfirmModal
              visible={true}
              title='Error'
              message={errorMsg}
              confirmText="OK"
              onConfirm={() => {setShowError(false); setErrorMsg('');}}
              onCancel={()=>{setShowError(false); setErrorMsg('');}}
          ></ConfirmModal>
          )}
          <Pressable
            style={styles.saveButton}
            onPress={async () => {
              console.log("Server URL: ",SERVER_URL);
              console.log('Saving Map Layout to Server');
              console.log('Rows:', rows, 'Cols:', cols);
              const mapLayout: MapLayout = {
                rows: 5,
                columns: 5,
                rooms: rooms.map((room) => {
                  console.log('Room:', room.name, 'Cells:', room.cells, 'Max Capacity:', room.maxCapacity);
                  return {
                    id:room.id,
                    name: room.name,
                    maxCapacity: room.maxCapacity,
                    cells: room.cells,
                  };
                }),
              };
              await saveMap(mapLayout);
              Alert.alert('Success', `Map saved for ${activeBranch}`);
              setSuccessPopup(true);
            }}
          >
            <Text style={styles.saveButtonText}>Save Map Layout to Server</Text>
          </Pressable>
        </View>
        {/* Room List */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Current Rooms</Text>
          {rooms.length > 0 ? (
            rooms.map((room) => (
              <View key={room.id} style={styles.roomItem}>
                <View style={styles.roomInfo}>
                  <Text style={styles.roomItemName}>{room.name}</Text>
                  {editingRoomId === room.id ? (
                    <View style={styles.editForm}>
                      <TextInput
                        style={styles.capacityInput}
                        placeholder="New Capacity"
                        value={editCapacity}
                        onChangeText={setEditCapacity}
                        keyboardType="numeric"
                      />
                      <Pressable style={styles.saveCapacityButton} onPress={saveCapacityUpdate}>
                        <Text style={styles.saveCapacityText}>Save</Text>
                      </Pressable>
                      <Pressable
                        style={styles.cancelButton}
                        onPress={() => {
                          setEditingRoomId(null);
                          setEditCapacity('');
                        }}
                      >
                        <Text style={styles.cancelText}>Cancel</Text>
                      </Pressable>
                    </View>
                  ) : (
                    <Text style={styles.roomItemCapacity}>Max Capacity: {room.maxCapacity}</Text>
                  )}
                </View>
                {editingRoomId !== room.id && (
                  <View style={styles.roomActions}>
                    <Pressable
                      style={styles.editButton}
                      onPress={() => handleUpdateCapacity(room.id, room.maxCapacity)}
                    >
                      <Text style={styles.editButtonText}>Edit Capacity</Text>
                    </Pressable>
                    <Pressable
                      style={styles.removeButton}
                      onPress={() => handleRemoveRoom(room.id, room.name)}
                    >
                      <ConfirmModal
                        visible={!!confirm}
                        title="Remove Room"
                        message={confirm ? `Are you sure you want to remove ${confirm.roomName}?`:""}
                        confirmText="Remove"
                        cancelText="Cancel"
                        destructive={true}
                        onConfirm={doRemove}
                        onCancel ={()=> setConfirm(null)}
                      ></ConfirmModal>
                      <Text style={styles.removeButtonText}>Remove</Text>
                    </Pressable>
                  </View>
                )}
              </View>
            ))
          ) : (
            <Text style={styles.emptyText}>No rooms created yet</Text>
          )}
        </View>
      </ScrollView>

      <Modal
        visible={branchModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setBranchModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select Branch</Text>
            <ScrollView style={styles.branchList}>
              {branches.map((branch) => (
                <Pressable
                  key={branch}
                  style={styles.branchOption}
                  onPress={async () => {
                    await setActiveBranch(branch);
                    setBranchModalVisible(false);
                  }}
                >
                  <Text style={styles.branchOptionText}>{branch}</Text>
                </Pressable>
              ))}
            </ScrollView>
            <View style={styles.addBranchSection}>
              <TextInput
                style={styles.input}
                placeholder="New Branch Name"
                value={newBranchName}
                onChangeText={setNewBranchName}
              />
              <Pressable style={styles.saveButton} onPress={handleAddBranch}>
                <Text style={styles.saveButtonText}>Add Branch</Text>
              </Pressable>
            </View>
            <Pressable style={styles.closeButton} onPress={() => setBranchModalVisible(false)}>
              <Text style={styles.closeButtonText}>Close</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flex: 1,
  },
  keyContainer: {
    flexDirection: 'row',
    gap: 16,
    marginVertical: 8,
    alignItems: 'center',
  },
  keyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  keyBox: {
    width: 14,
    height: 14,
    borderRadius: 3,
  },
  selected: {
    backgroundColor: '#2069f1',
  },
  saved: {
    backgroundColor: '#52ec5f',
  },
  label: {
    fontSize: 12,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  addButton: {
    backgroundColor: '#2069f1',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  section: {
    backgroundColor: '#fff',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  helperText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 12,
    backgroundColor: '#f9f9f9',
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  gridInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
  },
  mapContainer: {
    alignItems: 'center',
    marginTop: 16,
  },
  saveButton: {
    backgroundColor: '#4caf50',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  clearButton: {
    marginTop: 16,
    padding: 12,
    backgroundColor: '#ff9800',
    borderRadius: 8,
    alignItems: 'center',
  },
  clearButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  branchSelector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    backgroundColor: '#f9f9f9',
  },
  branchSelectorText: {
    fontSize: 16,
    color: '#333',
  },
  branchSelectorArrow: {
    fontSize: 12,
    color: '#666',
  },
  branchList: {
    maxHeight: 220,
  },
  branchOption: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  branchOptionText: {
    fontSize: 16,
    color: '#333',
  },
  addBranchSection: {
    marginTop: 16,
  },
  roomItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    marginBottom: 12,
    backgroundColor: '#f9f9f9',
  },
  roomInfo: {
    flex: 1,
  },
  roomItemName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  roomItemCapacity: {
    fontSize: 14,
    color: '#666',
  },
  roomActions: {
    flexDirection: 'row',
    gap: 8,
  },
  editButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#2069f1',
    borderRadius: 6,
  },
  editButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  removeButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#d32f2f',
    borderRadius: 6,
  },
  removeButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    padding: 20,
    fontStyle: 'italic',
  },
  editForm: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  capacityInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 6,
    padding: 8,
    fontSize: 14,
    backgroundColor: '#fff',
  },
  saveCapacityButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#4caf50',
    borderRadius: 6,
  },
  saveCapacityText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  cancelButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#999',
    borderRadius: 6,
  },
  cancelText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    width: '90%',
    maxWidth: 420,
    maxHeight: '85%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  closeButton: {
    marginTop: 16,
    padding: 12,
    backgroundColor: '#2069f1',
    borderRadius: 8,
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
