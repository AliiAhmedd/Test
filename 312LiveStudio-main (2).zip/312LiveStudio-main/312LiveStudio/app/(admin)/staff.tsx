import { useBranch } from "@/contexts/BranchContext";
import { USERS } from "@/data/users";
import { User } from "@/types/user";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";
import React, { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const SERVER_URL = "http://172.20.10.2:3000";
//const SERVER_URL = "http://127.0.0.1:3000";
type StaffMember = User & { branchName?: string | null };
type StaffRole = "reception" | "monitor";

export default function StaffManagement() {
  const baseStaff = useMemo(() => USERS.filter((u) => u.role !== "admin"), []);
  const [staff, setStaff] = useState<StaffMember[]>(baseStaff);
  const [modalVisible, setModalVisible] = useState(false);
  const [newStaffEmail, setNewStaffEmail] = useState("");
  const [newStaffName, setNewStaffName] = useState("");
  const [newStaffRole, setNewStaffRole] = useState<StaffRole>("reception");
  const [assignModalVisible, setAssignModalVisible] = useState(false);
  const [roleModalVisible, setRoleModalVisible] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const { branches } = useBranch();

  useEffect(() => {
    loadStaffAssignments();
  }, []);

  const loadStaffAssignments = async () => {
    try {
      const response = await axios.get(`${SERVER_URL}/api/staff`);
      const backendStaff: { email?: string; branchName?: string | null }[] =
        response.data || [];
      const merged = baseStaff.map((member) => {
        const match = backendStaff.find(
          (s) =>
            s.email && s.email.toLowerCase() === member.email.toLowerCase(),
        );
        return { ...member, branchName: match?.branchName || null };
      });
      setStaff(merged);
    } catch (error) {
      console.error("Failed to load staff assignments", error);
    }
  };

  const handleAddStaff = () => {
    if (!newStaffEmail.trim() || !newStaffName.trim()) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }

    if (!newStaffEmail.toLowerCase().startsWith("staff.")) {
      Alert.alert("Error", 'Staff email must start with "staff."');
      return;
    }

    if (
      staff.some(
        (s: User) => s.email.toLowerCase() === newStaffEmail.toLowerCase(),
      )
    ) {
      Alert.alert("Error", "Staff member with this email already exists");
      return;
    }

    const newStaff: StaffMember = {
      id: `staff-${Date.now()}`,
      email: newStaffEmail.trim(),
      password: "passwords123",
      role: newStaffRole,
      name: newStaffName.trim(),
      branchName: null,
    };

    setStaff([...staff, newStaff]);
    setNewStaffEmail("");
    setNewStaffName("");
    setNewStaffRole("reception");
    setModalVisible(false);
    Alert.alert("Success", "Staff member added successfully");
  };
  const addStaffSensor= async ()=>{
    const newStaffSensor = {
      name: newStaffName.trim(),
      currentRoomID:null
    };
    try {
      await axios.post(`${SERVER_URL}/api/addStaffSensor`, newStaffSensor),
        {
          
        }
    } catch (error) {
      
    }

  }

  const handleRemoveStaff = (staffId: string, staffName: string) => {
    Alert.alert(
      "Remove Staff",
      `Are you sure you want to remove ${staffName}?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: () => {
            setStaff(staff.filter((s: User) => s.id !== staffId));
            Alert.alert("Success", "Staff member removed");
          },
        },
      ],
    );
  };

  const openAssignModal = (member: StaffMember) => {
    setSelectedStaff(member);
    setAssignModalVisible(true);
  };

  const openRoleModal = (member: StaffMember) => {
    setSelectedStaff(member);
    setRoleModalVisible(true);
  };

  const assignBranch = (branchName: string) => {
    if (!selectedStaff) return;
    setStaff((prev) =>
      prev.map((member) =>
        member.id === selectedStaff.id ? { ...member, branchName } : member,
      ),
    );
    setAssignModalVisible(false);
    setSelectedStaff(null);
    Alert.alert("Success", `Assigned to ${branchName}`);
  };

  const assignRole = (role: StaffRole) => {
    if (!selectedStaff) return;
    setStaff((prev) =>
      prev.map((member) =>
        member.id === selectedStaff.id ? { ...member, role } : member,
      ),
    );
    setRoleModalVisible(false);
    setSelectedStaff(null);
    Alert.alert("Success", `Role set to ${role}`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>Human Resources</Text>
          <Pressable
            style={styles.addButton}
            onPress={() => setModalVisible(true)}
          >
            <Ionicons name="add" size={24} color="#fff" />
            <Text style={styles.addButtonText}>Add Staff</Text>
          </Pressable>
        </View>

        <View style={styles.staffList}>
          {staff.length > 0 ? (
            staff.map((member: StaffMember) => (
              <View key={member.id} style={styles.staffCard}>
                <View style={styles.staffInfo}>
                  <Text style={styles.staffName}>
                    {member.name || member.email}
                  </Text>
                  <Text style={styles.staffEmail}>{member.email}</Text>
                  <Text style={styles.staffRole}>{member.role}</Text>
                  <Text style={styles.staffBranch}>
                    {member.branchName || "Unassigned"}
                  </Text>
                </View>
                <View style={styles.staffActions}>
                  <Pressable
                    style={styles.assignButton}
                    onPress={() => openAssignModal(member)}
                  >
                    <Text style={styles.assignButtonText}>Assign Branch</Text>
                  </Pressable>
                  <Pressable
                    style={styles.roleButton}
                    onPress={() => openRoleModal(member)}
                  >
                    <Text style={styles.roleButtonText}>Assign Role</Text>
                  </Pressable>
                  <Pressable
                    style={styles.removeButton}
                    onPress={() =>
                      handleRemoveStaff(member.id, member.name || member.email)
                    }
                  >
                    <Ionicons name="trash-outline" size={20} color="#d32f2f" />
                  </Pressable>
                </View>
              </View>
            ))
          ) : (
            <Text style={styles.emptyText}>No staff members</Text>
          )}
        </View>
      </ScrollView>

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add New Staff</Text>

            <TextInput
              style={styles.input}
              placeholder="Staff Name"
              value={newStaffName}
              onChangeText={setNewStaffName}
            />

            <TextInput
              style={styles.input}
              placeholder="Email (staff.*@lancs.uk)"
              value={newStaffEmail}
              onChangeText={setNewStaffEmail}
              autoCapitalize="none"
              keyboardType="email-address"
            />

            <View style={styles.rolePicker}>
              <Pressable
                style={[
                  styles.roleOption,
                  newStaffRole === "reception" && styles.roleOptionActive,
                ]}
                onPress={() => setNewStaffRole("reception")}
              >
                <Text
                  style={[
                    styles.roleOptionText,
                    newStaffRole === "reception" && styles.roleOptionTextActive,
                  ]}
                >
                  Reception
                </Text>
              </Pressable>
              <Pressable
                style={[
                  styles.roleOption,
                  newStaffRole === "monitor" && styles.roleOptionActive,
                ]}
                onPress={() => setNewStaffRole("monitor")}
              >
                <Text
                  style={[
                    styles.roleOptionText,
                    newStaffRole === "monitor" && styles.roleOptionTextActive,
                  ]}
                >
                  Monitor
                </Text>
              </Pressable>
            </View>

            <View style={styles.modalButtons}>
              <Pressable
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => {
                  setModalVisible(false);
                  setNewStaffEmail("");
                  setNewStaffName("");
                }}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </Pressable>
              <Pressable
                style={[styles.modalButton, styles.addButton]}
                onPress={handleAddStaff}
              >
                <Text style={styles.addButtonText}>Add</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={assignModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setAssignModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Assign Branch</Text>
            <ScrollView style={styles.branchList}>
              {branches.map((branch) => (
                <Pressable
                  key={branch}
                  style={styles.branchOption}
                  onPress={() => assignBranch(branch)}
                >
                  <Text style={styles.branchOptionText}>{branch}</Text>
                </Pressable>
              ))}
            </ScrollView>
            <Pressable
              style={styles.modalCloseButton}
              onPress={() => setAssignModalVisible(false)}
            >
              <Text style={styles.modalCloseButtonText}>Close</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal
        visible={roleModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setRoleModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Assign Role</Text>
            <Pressable
              style={styles.roleOption}
              onPress={() => assignRole("reception")}
            >
              <Text style={styles.roleOptionText}>Reception</Text>
            </Pressable>
            <Pressable
              style={styles.roleOption}
              onPress={() => assignRole("monitor")}
            >
              <Text style={styles.roleOptionText}>Monitor</Text>
            </Pressable>
            <Pressable
              style={styles.modalCloseButton}
              onPress={() => setRoleModalVisible(false)}
            >
              <Text style={styles.modalCloseButtonText}>Close</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#2069f1",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 8,
  },
  addButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
  staffList: {
    padding: 16,
  },
  staffCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  staffInfo: {
    flex: 1,
  },
  staffName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
    marginBottom: 4,
  },
  staffEmail: {
    fontSize: 14,
    color: "#666",
  },
  staffRole: {
    fontSize: 12,
    color: "#333",
    marginTop: 6,
    textTransform: "capitalize",
  },
  staffBranch: {
    fontSize: 12,
    color: "#2069f1",
    marginTop: 6,
  },
  staffActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  assignButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: "#4caf50",
    borderRadius: 6,
  },
  assignButtonText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
  },
  roleButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: "#ff9800",
    borderRadius: 6,
  },
  roleButtonText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
  },
  removeButton: {
    padding: 8,
  },
  emptyText: {
    fontSize: 14,
    color: "#999",
    textAlign: "center",
    padding: 40,
    fontStyle: "italic",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 24,
    width: "90%",
    maxWidth: 400,
    maxHeight: "80%",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
    backgroundColor: "#f9f9f9",
  },
  modalButtons: {
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 12,
    marginTop: 8,
  },
  modalButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  cancelButton: {
    backgroundColor: "#f5f5f5",
  },
  cancelButtonText: {
    color: "#666",
    fontWeight: "600",
  },
  rolePicker: {
    flexDirection: "row",
    gap: 8,
    marginBottom: 8,
  },
  roleOption: {
    flex: 1,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    alignItems: "center",
  },
  roleOptionActive: {
    backgroundColor: "#2069f1",
    borderColor: "#2069f1",
  },
  roleOptionText: {
    fontSize: 14,
    color: "#333",
  },
  roleOptionTextActive: {
    color: "#fff",
    fontWeight: "600",
  },
  branchList: {
    maxHeight: 220,
  },
  branchOption: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  branchOptionText: {
    fontSize: 16,
    color: "#333",
  },
  modalCloseButton: {
    marginTop: 16,
    padding: 12,
    backgroundColor: "#2069f1",
    borderRadius: 8,
    alignItems: "center",
  },
  modalCloseButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
});
