import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Redirect } from 'expo-router';

export default function AdminLayout() {
  const { isAuthenticated, role } = useAuth();

  if (!isAuthenticated || role !== 'admin') {
    return <Redirect href="/(auth)/signin" />;
  }

  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ focused, size, color }) => {
          let iconName: keyof typeof Ionicons.glyphMap;
          switch (route.name) {
            case 'dashboard':
              iconName = focused ? 'grid' : 'grid-outline';
              break;
            case 'staff':
              iconName = focused ? 'people' : 'people-outline';
              break;
            case 'logs':
              iconName = focused ? 'list' : 'list-outline';
              break;
            case 'map':
              iconName = focused ? 'map' : 'map-outline';
              break;
            case 'mapcreator':
              iconName = focused ? 'create' : 'create-outline';
              break;
            case 'emergency':
              iconName = focused ? 'alert' : 'alert-circle-outline';
              break;
            default:
              iconName = 'ellipse-outline';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tabs.Screen
        name="dashboard"
        options={{
          title: 'Dashboard',
        }}
      />
      <Tabs.Screen
        name="staff"
        options={{
          title: 'HR Human Resources',
        }}
      />
      <Tabs.Screen
        name="logs"
        options={{
          title: 'Logs',
        }}
      />
      <Tabs.Screen
        name="map"
        options={{
          title: 'Map',
        }}
      />
      <Tabs.Screen
        name="mapcreator"
        options={{
          title: 'Map Creator',
        }}
      />
      <Tabs.Screen
        name="emergency"
        options={{
          title: 'Emergency',
        }}
      />
    </Tabs>
  );
}
