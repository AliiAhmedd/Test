import React from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEmergency, CORE_CODES, MEDICAL_CODES, SECURITY_CODES } from '@/contexts/EmergencyContext';
import { useBranch } from '@/contexts/BranchContext';

export default function AdminEmergency() {
  const { addEvent, events } = useEmergency();
  const { activeBranch } = useBranch();

  const triggerGlobal = (
    code: string,
    meaning: string,
    description: string,
    category: 'core' | 'security'
  ) => {
    addEvent({
      code,
      meaning,
      description,
      category,
      scope: 'global',
    });
    Alert.alert('Activated', `This alarm is activated: ${code} (all branches)`);
  };

  const triggerBranch = (code: string, meaning: string, description: string) => {
    addEvent({
      code,
      meaning,
      description,
      category: 'medical',
      scope: 'branch',
      branchName: activeBranch,
    });
    Alert.alert('Activated', `This alarm is activated: ${code} (${activeBranch})`);
  };

  const liveAlerts = events.slice(0, 5);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>Emergency</Text>
          <Text style={styles.subtitle}>{activeBranch}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Live Alerts</Text>
          {liveAlerts.length === 0 ? (
            <Text style={styles.emptyText}>No active alerts</Text>
          ) : (
            liveAlerts.map((alert) => (
              <View key={alert.id} style={styles.alertCard}>
                <Text style={styles.alertCode}>{alert.code}</Text>
                <Text style={styles.alertMeaning}>{alert.meaning}</Text>
                <Text style={styles.alertDescription}>{alert.description}</Text>
                <Text style={styles.alertMeta}>
                  {alert.scope === 'branch' ? `Branch: ${alert.branchName}` : 'All branches'}
                  {alert.roomId ? ` • Room: ${alert.roomId}` : ''} •{' '}
                  {new Date(alert.timestamp).toLocaleString()}
                </Text>
              </View>
            ))
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Alert History</Text>
          {events.length === 0 ? (
            <Text style={styles.emptyText}>No alerts recorded</Text>
          ) : (
            events.map((alert) => (
              <View key={alert.id} style={styles.historyCard}>
                <Text style={styles.historyCode}>{alert.code}</Text>
                <Text style={styles.historyMeta}>
                  {alert.scope === 'branch' ? `Branch: ${alert.branchName}` : 'All branches'}
                  {alert.roomId ? ` • Room: ${alert.roomId}` : ''} •{' '}
                  {new Date(alert.timestamp).toLocaleString()}
                </Text>
              </View>
            ))
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Medical & Patient Safety Codes</Text>
          {MEDICAL_CODES.map((item) => (
            <Pressable
              key={item.code}
              style={styles.emergencyButton}
              onPress={() => triggerBranch(item.code, item.meaning, item.description)}
            >
              <Text style={styles.emergencyCode}>{item.code}</Text>
              <Text style={styles.emergencyMeaning}>{item.meaning}</Text>
              <Text style={styles.emergencyDescription}>{item.description}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Core Emergency Codes</Text>
          {CORE_CODES.map((item) => (
            <Pressable
              key={item.code}
              style={[styles.emergencyButton, styles.coreButton]}
              onPress={() => triggerGlobal(item.code, item.meaning, item.description, 'core')}
            >
              <Text style={styles.emergencyCode}>{item.code}</Text>
              <Text style={styles.emergencyMeaning}>{item.meaning}</Text>
              <Text style={styles.emergencyDescription}>{item.description}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Security & Infrastructure Codes</Text>
          {SECURITY_CODES.map((item) => (
            <Pressable
              key={item.code}
              style={[styles.emergencyButton, styles.securityButton]}
              onPress={() => triggerGlobal(item.code, item.meaning, item.description, 'security')}
            >
              <Text style={styles.emergencyCode}>{item.code}</Text>
              <Text style={styles.emergencyMeaning}>{item.meaning}</Text>
              <Text style={styles.emergencyDescription}>{item.description}</Text>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  subtitle: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  section: {
    backgroundColor: '#fff',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  emergencyButton: {
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
    backgroundColor: '#fff7f7',
  },
  coreButton: {
    backgroundColor: '#fff1f0',
  },
  securityButton: {
    backgroundColor: '#fff7e6',
  },
  emergencyCode: {
    fontSize: 16,
    fontWeight: '700',
    color: '#d32f2f',
    marginBottom: 4,
  },
  emergencyMeaning: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  emergencyDescription: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  emptyText: {
    fontSize: 12,
    color: '#999',
  },
  alertCard: {
    borderWidth: 1,
    borderColor: '#f0f0f0',
    borderRadius: 8,
    padding: 10,
    marginBottom: 8,
    backgroundColor: '#fff7f7',
  },
  alertCode: {
    fontSize: 14,
    fontWeight: '700',
    color: '#d32f2f',
  },
  alertMeaning: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
    marginTop: 4,
  },
  alertDescription: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  alertMeta: {
    fontSize: 11,
    color: '#999',
    marginTop: 6,
  },
  historyCard: {
    borderWidth: 1,
    borderColor: '#f0f0f0',
    borderRadius: 8,
    padding: 10,
    marginBottom: 8,
    backgroundColor: '#f5f5f5',
  },
  historyCode: {
    fontSize: 13,
    fontWeight: '700',
    color: '#333',
  },
  historyMeta: {
    fontSize: 11,
    color: '#666',
    marginTop: 6,
  },
});
