import GridMap from "@/components/GridMap";
import HelpModal from "@/components/HelpModal";
import { useBranch } from "@/contexts/BranchContext";
import { useRooms } from "@/contexts/RoomContext";
import { useVisitors } from "@/contexts/VisitorContext";
import Ionicons from "@expo/vector-icons/build/Ionicons";
import React, { useEffect, useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function Map() {
  const { rooms } = useRooms();
  const { activeVisitors, getVisitorsByRoom } = useVisitors();
  const [filteredRooms, setFilteredRooms] = useState(rooms);
  const { activeBranch } = useBranch();
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [roomTemperatures, setRoomTemperatures] = useState<
    Record<string, number | null>
  >({});

  const SERVER_URL = "http://192.168.42.16:3000";
  // const SERVER_URL = "http://127.0.0.1:3000";
  const [temperatureHistory, setTemperatureHistory] = useState<
    Array<{ roomID: number; roomName: string; readings: Array<{ temperature: number; createdAt: string | null; logID: number }> }>
  >([]);
  const [averageBranchTemp, setAverageBranchTemp] = useState<number | null>(null);
  const [temperatureLoading, setTemperatureLoading] = useState(false);
  const [temperatureError, setTemperatureError] = useState<string | null>(null);
  useEffect(() => {
    setFilteredRooms(rooms);
  }, [rooms]);
  const [modalVisible, setModalVisible] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  useEffect(() => {
    let isCancelled = false;
    const pollTemperatures = async () => {
      try {
        const entries = await Promise.all(
          rooms.map(async (room) => {
            console.log(room.id);
            try {
              const response = await fetch(
                `${SERVER_URL}/api/roomTemperature/${room.id}`,
              );
              const data = await response.json();
              console.log(data);
              console.log(data.temperature);
              return [room.id, data.temperature];
            } catch (error) {
              return [room.id, null];
            }
          }),
        );
        if (!isCancelled) {
          setRoomTemperatures(Object.fromEntries(entries));
        }
      } catch (error) {
        // swallow fetch errors to avoid breaking the UI
      }
    };

    if (rooms.length > 0) {
      pollTemperatures();
      const intervalId = setInterval(pollTemperatures, 5000);
      return () => {
        isCancelled = true;
        clearInterval(intervalId);
      };
    }
  }, [rooms]);

  useEffect(() => {
    let isCancelled = false;
    const loadTemperatureHistory = async () => {
      setTemperatureLoading(true);
      setTemperatureError(null);
      try {
        const response = await fetch(
          `${SERVER_URL}/api/temperature/history?branchName=${encodeURIComponent(
            activeBranch,
          )}&limit=20`,
        );
        const data = await response.json();
        if (!isCancelled) {
          setTemperatureHistory(data.rooms || []);
          setAverageBranchTemp(
            data.averageTemperature !== null && data.averageTemperature !== undefined
              ? Number(data.averageTemperature)
              : null,
          );
        }
      } catch (error) {
        if (!isCancelled) {
          setTemperatureError("Failed to load temperature history.");
        }
      } finally {
        if (!isCancelled) {
          setTemperatureLoading(false);
        }
      }
    };

    loadTemperatureHistory();
    const intervalId = setInterval(loadTemperatureHistory, 10000);
    return () => {
      isCancelled = true;
      clearInterval(intervalId);
    };
  }, [activeBranch]);

  const formatTemperature = (value: number | null) => {
    if (value === null || Number.isNaN(value)) return "—";
    return `${value.toFixed(1)}°C`;
  };

  const computePoints = (values: number[], width: number, height: number) => {
    const padding = 6;
    if (values.length === 0) return [];
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min || 1;
    return values.map((value, index) => {
      const x =
        values.length === 1
          ? width / 2
          : padding + (index / (values.length - 1)) * (width - padding * 2);
      const y =
        height - padding - ((value - min) / range) * (height - padding * 2);
      return { x, y };
    });
  };

  const LineChart = ({
    data,
    width = 260,
    height = 90,
    color = "#2069f1",
  }: {
    data: number[];
    width?: number;
    height?: number;
    color?: string;
  }) => {
    const points = computePoints(data, width, height);
    return (
      <View style={[styles.lineChart, { width, height }]}>
        {points.map((point, index) => {
          if (index === 0) return null;
          const prev = points[index - 1];
          const dx = point.x - prev.x;
          const dy = point.y - prev.y;
          const length = Math.sqrt(dx * dx + dy * dy);
          const angle = Math.atan2(dy, dx) + "rad";
          return (
            <View
              key={`line-${index}`}
              style={[
                styles.lineSegment,
                {
                  width: length,
                  transform: [{ translateX: prev.x }, { translateY: prev.y }, { rotateZ: angle }],
                  backgroundColor: color,
                },
              ]}
            />
          );
        })}
        {points.map((point, index) => (
          <View
            key={`point-${index}`}
            style={[
              styles.linePoint,
              {
                backgroundColor: color,
                left: point.x - 3,
                top: point.y - 3,
              },
            ]}
          />
        ))}
      </View>
    );
  };

  useEffect(() => {
    if (!showHeatmap) return;
    const heatmapRows = 5;
    const heatmapCols = 5;
    const totalCells = heatmapRows * heatmapCols;
    const heatmapSummary = {
      nonRoom: 0,
      empty: 0,
      lessHalf: 0,
      half: 0,
      moreHalf: 0,
      full: 0,
    };

    for (let index = 0; index < totalCells; index += 1) {
      const room = rooms.find((r) => r.cells.includes(index));
      if (!room) {
        heatmapSummary.nonRoom += 1;
        continue;
      }
      const visitors = getVisitorsByRoom(room.id).length;
      const ratio = room.maxCapacity ? visitors / room.maxCapacity : 0;
      if (visitors === 0) heatmapSummary.empty += 1;
      else if (ratio < 0.5) heatmapSummary.lessHalf += 1;
      else if (ratio === 0.5) heatmapSummary.half += 1;
      else if (ratio < 1) heatmapSummary.moreHalf += 1;
      else heatmapSummary.full += 1;
    }

    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/2048ce62-32fd-4474-b911-49bf71d2a9e3',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'map.tsx:heatmapSummary',message:'Heatmap summary',data:{totalCells,roomsCount:rooms.length,summary:heatmapSummary},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H1'})}).catch(()=>{});
    // #endregion agent log
  }, [showHeatmap, rooms, getVisitorsByRoom]);

  const getHeatmapColor = (roomId?: string) => {
    if (!roomId) return "#3b82f6";
    const room = rooms.find((r) => r.id === roomId);
    if (!room) return "#3b82f6";
    const visitors = getVisitorsByRoom(room.id).length;
    if (visitors === 0) return "#4caf50";
    const ratio = room.maxCapacity ? visitors / room.maxCapacity : 0;
    if (ratio < 0.5) return "#facc15";
    if (ratio === 0.5) return "#fb923c";
    if (ratio < 1) return "#ef4444";
    return "#7f1d1d";
  };

  const heatmapCellColors = useMemo(() => {
    if (!showHeatmap) return undefined;
    const colors: Record<number, string> = {};
    const totalCells = 25;
    for (let index = 0; index < totalCells; index += 1) {
      const room = rooms.find((r) => r.cells.includes(index));
      colors[index] = getHeatmapColor(room?.id);
    }
    // #region agent log
    fetch('http://127.0.0.1:7243/ingest/2048ce62-32fd-4474-b911-49bf71d2a9e3',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'map.tsx:heatmapColors',message:'Heatmap colors computed',data:{cells:Object.keys(colors).length,showHeatmap},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H2'})}).catch(()=>{});
    // #endregion agent log
    return colors;
  }, [showHeatmap, rooms, getVisitorsByRoom]);

  return (
    <SafeAreaView style={styles.container}>
      <HelpModal
        visible={showHelp}
        onClose={() => setShowHelp(false)}
        title="Instructions"
        lines={[
          "To Filter: Press the room you want to view",
          'To show all select empty cell or press the "Reset Filter" button',
        ]}
      ></HelpModal>
      {/* <Modal visible={showHelp}
        onRequestClose={()=> setShowHelp(false)}
        animationType="slide"
        transparent={true}
        >
          <View>
            <Text>Instructions</Text>
            <Text>1. To Filter: Press the room you want to view</Text>
            <Text>2. To show all select empty cell or press the "Reset Filter" button</Text>
            <Pressable onPress={() => setShowHelp(false)}>
              <Text>Close</Text>
            </Pressable>
          </View>
        </Modal> */}
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <View style={styles.headerActions}>
            <Pressable onPress={() => setShowHelp(true)}>
              <Ionicons name="help" style={{ fontSize: 24 }} />
            </Pressable>
            <Pressable
              style={[
                styles.heatmapToggle,
                showHeatmap ? styles.heatmapToggleActive : null,
              ]}
              onPress={() => {
                setShowHeatmap((prev) => !prev);
                // #region agent log
                fetch('http://127.0.0.1:7243/ingest/2048ce62-32fd-4474-b911-49bf71d2a9e3',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'map.tsx:toggleHeatmap',message:'Heatmap toggled',data:{next:!showHeatmap},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H3'})}).catch(()=>{});
                // #endregion agent log
              }}
            >
              <Text style={styles.heatmapToggleText}>
                {showHeatmap ? "Standard Map" : "Heat Map"}
              </Text>
            </Pressable>
          </View>
          <Text style={styles.title}>Room Map</Text>
          <Text style={styles.subtitle}>{activeBranch}</Text>
        </View>

        <View style={styles.mapContainer}>
          <GridMap
            rows={5}
            cols={5}
            cellSize={48}
            saved={showHeatmap ? new Set() : new Set(rooms.flatMap((room) => room.cells))}
            //saved={new Set([0,1, 2,5, 6,7])}
            selected={new Set()}
            cellColors={heatmapCellColors}
            onCellPress={(index: number) => {
              if (showHeatmap) return;
              if (rooms.some((room) => room.cells.includes(index))) {
                const room = rooms.find((room) => room.cells.includes(index));
                setFilteredRooms(room ? [room] : []);
              } else {
                setFilteredRooms(rooms);
              }
            }}
          />
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Room Overview</Text>
          <Pressable onPress={() => setFilteredRooms(rooms)}>
            <Text>
              <Ionicons name="refresh-circle-outline" style={styles.title} />{" "}
              Reset Filter
            </Text>
          </Pressable>
          <View style={styles.roomGrid}>
            {filteredRooms.map((room) => {
              const roomVisitors = getVisitorsByRoom(room.id);
              const isOccupied = roomVisitors.length > 0;
              const isFull = roomVisitors.length >= room.maxCapacity;
              const currentTemp = roomTemperatures[room.id];

              return (
                <View
                  key={room.id}
                  style={[
                    styles.roomCard,
                    isFull
                      ? styles.roomFull
                      : isOccupied
                        ? styles.roomOccupied
                        : styles.roomAvailable,
                  ]}
                >
                  <Text style={styles.roomName}>{room.name}</Text>
                  <Text style={styles.roomCapacity}>
                    {roomVisitors.length}/{room.maxCapacity}
                  </Text>
                  <Text
                    style={[
                      styles.roomStatus,
                      isFull
                        ? styles.statusFull
                        : isOccupied
                          ? styles.statusOccupied
                          : styles.statusAvailable,
                    ]}
                  >
                    {isFull ? "Full" : isOccupied ? "Occupied" : "Available"}
                  </Text>
                  <Text style={styles.roomTemperature}>
                    Temp:{" "}
                    {currentTemp !== undefined && currentTemp !== null
                      ? `${currentTemp.toFixed(1)}°C`
                      : "—"}
                  </Text>
                  {roomVisitors.length > 0 && (
                    <View style={styles.visitorsList}>
                      {roomVisitors.map((visitor) => (
                        <Text key={visitor.id} style={styles.visitorName}>
                          {visitor.name}
                        </Text>
                      ))}
                    </View>
                  )}
                </View>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Statistics</Text>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{rooms.length}</Text>
              <Text style={styles.statLabel}>Total Rooms</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>
                {
                  rooms.filter((r) => {
                    const visitors = getVisitorsByRoom(r.id);
                    return visitors.length > 0;
                  }).length
                }
              </Text>
              <Text style={styles.statLabel}>Occupied</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>
                {
                  rooms.filter((r) => {
                    const visitors = getVisitorsByRoom(r.id);
                    return visitors.length < r.maxCapacity;
                  }).length
                }
              </Text>
              <Text style={styles.statLabel}>Available</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Temperature Trends</Text>
          <Text style={styles.subtitle}>
            Average Branch Temperature: {formatTemperature(averageBranchTemp)}
          </Text>
          <Text style={styles.helperText}>
            Requires Pico temperature sensors to populate live readings.
          </Text>
          {temperatureLoading ? (
            <Text style={styles.emptyText}>Loading temperature history...</Text>
          ) : temperatureError ? (
            <Text style={styles.errorText}>{temperatureError}</Text>
          ) : temperatureHistory.length > 0 ? (
            temperatureHistory.map((room) => {
              const values = room.readings.map((reading) => reading.temperature);
              return (
                <View key={room.roomID} style={styles.tempCard}>
                  <Text style={styles.tempRoomName}>{room.roomName}</Text>
                  <LineChart data={values} />
                  <View style={styles.tempMetaRow}>
                    <Text style={styles.tempMeta}>
                      Latest: {formatTemperature(values[values.length - 1] ?? null)}
                    </Text>
                    <Text style={styles.tempMeta}>
                      Points: {values.length}
                    </Text>
                  </View>
                </View>
              );
            })
          ) : (
            <Text style={styles.emptyText}>No temperature history yet.</Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
  },
  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  heatmapToggle: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    backgroundColor: "#eef2ff",
  },
  heatmapToggleActive: {
    backgroundColor: "#c7d2fe",
  },
  heatmapToggleText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#1d4ed8",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  subtitle: {
    fontSize: 12,
    color: "#666",
    marginTop: 4,
  },
  section: {
    backgroundColor: "#fff",
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 16,
  },
  roomGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  mapContainer: {
    alignItems: "center",
    marginTop: 16,
  },
  roomCard: {
    width: "30%",
    minWidth: 120,
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: "center",
  },
  roomAvailable: {
    backgroundColor: "#e8f5e9",
    borderColor: "#4caf50",
  },
  roomOccupied: {
    backgroundColor: "#fff3e0",
    borderColor: "#ff9800",
  },
  roomFull: {
    backgroundColor: "#ffebee",
    borderColor: "#f44336",
  },
  roomName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
    marginBottom: 8,
  },
  roomCapacity: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#2069f1",
    marginBottom: 4,
  },
  roomStatus: {
    fontSize: 12,
    fontWeight: "600",
    marginBottom: 8,
  },
  roomTemperature: {
    fontSize: 12,
    color: "#333",
    marginBottom: 4,
  },
  statusAvailable: {
    color: "#4caf50",
  },
  statusOccupied: {
    color: "#ff9800",
  },
  statusFull: {
    color: "#f44336",
  },
  visitorsList: {
    width: "100%",
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: "#e0e0e0",
  },
  visitorName: {
    fontSize: 11,
    color: "#666",
    marginBottom: 4,
    textAlign: "center",
  },
  statsRow: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  lineChart: {
    position: "relative",
    marginTop: 8,
    marginBottom: 8,
    backgroundColor: "#f9fafb",
    borderRadius: 8,
  },
  lineSegment: {
    position: "absolute",
    height: 2,
    left: 0,
    top: 0,
  },
  linePoint: {
    position: "absolute",
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  tempCard: {
    backgroundColor: "#f9fafb",
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  tempRoomName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
  },
  tempMetaRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 6,
  },
  tempMeta: {
    fontSize: 12,
    color: "#666",
  },
  errorText: {
    fontSize: 12,
    color: "#d32f2f",
    marginTop: 8,
  },
  statItem: {
    alignItems: "center",
  },
  statValue: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#2069f1",
    marginBottom: 8,
  },
  statLabel: {
    fontSize: 14,
    color: "#666",
  },
});
