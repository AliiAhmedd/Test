import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useVisitors } from '@/contexts/VisitorContext';
import { useBranch } from '@/contexts/BranchContext';

export default function VisitorLogs() {
  const { visitorLogs, activeVisitors, clearLogs } = useVisitors();
  const { activeBranch } = useBranch();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRoom, setFilterRoom] = useState('');

  // Combine active visitors (as logs) with completed logs
  const allLogs = [
    ...activeVisitors.map((v: any) => ({
      id: v.id,
      visitorName: v.name,
      phoneNumber: v.phoneNumber,
      roomId: v.roomId,
      checkInTime: v.checkInTime,
      checkOutTime: null as Date | null,
      duration: undefined as number | undefined,
    })),
    ...visitorLogs,
  ];
  //console.log("All Logs:", allLogs);
  // Filter logs
  const filteredLogs = allLogs.filter((log) => {
    const matchesSearch =
      log.visitorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.roomId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRoom = !filterRoom || log.roomId === filterRoom;
    console.log("Filtering log:", log, "Matches Search:", matchesSearch, "Matches Room:", matchesRoom);
    return matchesSearch && matchesRoom;
  });

  // Get unique rooms for filter
  const uniqueRooms = Array.from(
    new Set([...activeVisitors.map((v: any) => v.roomId), ...visitorLogs.map((l: any) => l.roomId)])
  ).sort();

  const formatDuration = (minutes?: number) => {
    if (!minutes) return 'N/A';
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>Visitor Logs</Text>
          <Text style={styles.subtitle}>{activeBranch}</Text>
        </View>

        <View style={styles.filters}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search by name or room..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          <TextInput
            style={styles.filterInput}
            placeholder="Filter by room ID..."
            value={filterRoom}
            onChangeText={setFilterRoom}
          />
        </View>
        <View>
          <Pressable
          onPress={()=>clearLogs()}
          >
            <Text>
              Clear Logs
            </Text>
          </Pressable> 

        </View>

        <View style={styles.logsList}>
          {filteredLogs.length > 0 ? (
            filteredLogs.map((log) => (
              <View key={log.id} style={styles.logCard}>
                <View style={styles.logHeader}>
                  <Text style={styles.visitorName}>{log.visitorName}</Text>
                  <View
                    style={[
                      styles.statusBadge,
                      log.checkOutTime ? styles.statusCompleted : styles.statusActive,
                    ]}
                  >
                    <Text style={styles.statusText}>
                      {log.checkOutTime ? 'Checked Out' : 'Active'}
                    </Text>
                  </View>
                </View>

                <View style={styles.logDetails}>
                  <View style={styles.logRow}>
                    <Text style={styles.logLabel}>Phone:</Text>
                    <Text style={styles.logValue}>{log.phoneNumber}</Text>
                  </View>

                  <View style={styles.logRow}>
                    <Text style={styles.logLabel}>Room:</Text>
                    <Text style={styles.logValue}>{log.roomId}</Text>
                  </View>

                  <View style={styles.logRow}>
                    <Text style={styles.logLabel}>Check-in:</Text>
                    <Text style={styles.logValue}>
                      {log.checkInTime.toLocaleString()}
                    </Text>
                  </View>

                  {log.checkOutTime && (
                    <View style={styles.logRow}>
                      <Text style={styles.logLabel}>Check-out:</Text>
                      <Text style={styles.logValue}>
                        {log.checkOutTime.toLocaleString()}
                      </Text>
                    </View>
                  )}

                  {log.duration !== undefined && (
                    <View style={styles.logRow}>
                      <Text style={styles.logLabel}>Duration:</Text>
                      <Text style={styles.logValue}>{formatDuration(log.duration)}</Text>
                    </View>
                  )}
                </View>
              </View>
            ))
          ) : (
            <Text style={styles.emptyText}>No logs found</Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  subtitle: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  filters: {
    padding: 16,
    gap: 12,
  },
  searchInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  filterInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  logsList: {
    padding: 16,
  },
  logCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  logHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  visitorName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusActive: {
    backgroundColor: '#4caf50',
  },
  statusCompleted: {
    backgroundColor: '#999',
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  logDetails: {
    gap: 8,
  },
  logRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  logLabel: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  logValue: {
    fontSize: 14,
    color: '#333',
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    padding: 40,
    fontStyle: 'italic',
  },
});
