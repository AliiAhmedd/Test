import { useAuth } from '@/contexts/AuthContext';
import { useBranch } from '@/contexts/BranchContext';
import { useRooms } from '@/contexts/RoomContext';
import { useVisitors } from '@/contexts/VisitorContext';
import React, { useEffect, useState } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const SERVER_URL =
  Platform.OS === 'web' ? 'http://localhost:3000' : 'http://172.20.10.2:3000';

type PeakHour = { hour: string; count: number };
type DurationByRoom = {
  roomID: number | null;
  roomName: string | null;
  avgMinutes: number;
  visits: number;
};
type RoomTotal = { roomID: number | null; roomName: string | null; visits: number };
type OccupancyBreach = {
  roomID: number;
  roomName: string;
  currentOccupancy: number;
  maxOccupancy: number;
  occupancyPercent: number;
};
type TemperatureBreach = { roomID: number; roomName: string; temperature: number };
type BarDatum = { label: string; value: number };

function MiniBarChart({
  data,
  barColor = '#2069f1',
}: {
  data: BarDatum[];
  barColor?: string;
}) {
  const max = Math.max(...data.map((item) => item.value), 1);

  return (
    <View style={styles.chartContainer}>
      {data.map((item) => {
        const widthPercent = Math.round((item.value / max) * 100);
        return (
          <View key={item.label} style={styles.chartRow}>
            <Text style={styles.chartLabel}>{item.label}</Text>
            <View style={styles.chartBarTrack}>
              <View
                style={[
                  styles.chartBarFill,
                  { width: `${widthPercent}%`, backgroundColor: barColor },
                ]}
              />
            </View>
            <Text style={styles.chartValue}>{item.value}</Text>
          </View>
        );
      })}
    </View>
  );
}

export default function AdminDashboard() {
  const { user, signOut } = useAuth();
  const { activeVisitors, visitorLogs } = useVisitors();
  const { rooms } = useRooms();
  const { activeBranch } = useBranch();
  const [visitorVolume, setVisitorVolume] = useState<Array<{ day: string; count: number }>>([]);
  const [peakHour, setPeakHour] = useState<PeakHour | null>(null);
  const [durationStats, setDurationStats] = useState<{
    overallAvgMinutes: number | null;
    byRoom: DurationByRoom[];
  }>({ overallAvgMinutes: null, byRoom: [] });
  const [occupancyTrends, setOccupancyTrends] = useState<{
    roomTotals: RoomTotal[];
  }>({ roomTotals: [] });
  const [thresholds, setThresholds] = useState({
    occupancyPercent: 85,
    maxTemperature: 26,
  });
  const [occupancyInput, setOccupancyInput] = useState('85');
  const [temperatureInput, setTemperatureInput] = useState('26');
  const [thresholdBreaches, setThresholdBreaches] = useState<{
    occupancy: OccupancyBreach[];
    temperature: TemperatureBreach[];
  }>({ occupancy: [], temperature: [] });
  const [analyticsLoading, setAnalyticsLoading] = useState(true);
  const [analyticsError, setAnalyticsError] = useState<string | null>(null);
  const [savingThresholds, setSavingThresholds] = useState(false);
  const [thresholdError, setThresholdError] = useState<string | null>(null);
  const totalRooms = rooms.length;
  const activeRooms = new Set(activeVisitors.map((v) => v.roomId)).size;
  const totalStaff = 5; // From user data
  const analyticsDays = 14;
  const volumeChartData = visitorVolume.map((item) => ({
    label: item.day.slice(5),
    value: item.count,
  }));
  const occupancyChartData = occupancyTrends.roomTotals.slice(0, 5).map((room) => ({
    label: room.roomName || `Room ${room.roomID ?? 'Unknown'}`,
    value: room.visits,
  }));
  const formatMinutes = (minutes: number | null) => {
    if (minutes === null || Number.isNaN(minutes)) return 'N/A';
    if (minutes < 60) return `${Math.round(minutes)}m`;
    const hours = Math.floor(minutes / 60);
    const remaining = Math.round(minutes % 60);
    return `${hours}h ${remaining}m`;
  };

  useEffect(() => {
    const loadAnalytics = async () => {
      setAnalyticsLoading(true);
      setAnalyticsError(null);
      try {
        const [volumeRes, durationRes, occupancyRes] = await Promise.all([
          fetch(`${SERVER_URL}/api/analytics/visitors?days=${analyticsDays}`),
          fetch(`${SERVER_URL}/api/analytics/visit-durations?days=${analyticsDays}`),
          fetch(`${SERVER_URL}/api/analytics/occupancy-trends?days=${analyticsDays}`),
        ]);
        const volumeData = await volumeRes.json();
        const durationData = await durationRes.json();
        const occupancyData = await occupancyRes.json();

        setVisitorVolume(volumeData.dailyCounts || []);
        setPeakHour(volumeData.peakHour || null);
        setDurationStats({
          overallAvgMinutes: durationData.overallAvgMinutes ?? null,
          byRoom: durationData.byRoom || [],
        });
        setOccupancyTrends({
          roomTotals: occupancyData.roomTotals || [],
        });
      } catch (error) {
        console.error('Error loading analytics:', error);
        setAnalyticsError('Failed to load analytics data.');
      } finally {
        setAnalyticsLoading(false);
      }
    };

    const loadThresholds = async () => {
      setThresholdError(null);
      try {
        const res = await fetch(`${SERVER_URL}/api/settings/thresholds`);
        const data = await res.json();
        const nextThresholds = data.thresholds || thresholds;
        setThresholds(nextThresholds);
        setOccupancyInput(String(nextThresholds.occupancyPercent));
        setTemperatureInput(String(nextThresholds.maxTemperature));
        setThresholdBreaches({
          occupancy: data.occupancyBreaches || [],
          temperature: data.temperatureBreaches || [],
        });
      } catch (error) {
        console.error('Error loading thresholds:', error);
        setThresholdError('Failed to load thresholds.');
      }
    };

    loadAnalytics();
    loadThresholds();
  }, [activeBranch]);

  const saveThresholds = async () => {
    const occupancy = Number(occupancyInput);
    const maxTemperature = Number(temperatureInput);
    if (
      Number.isNaN(occupancy) ||
      Number.isNaN(maxTemperature) ||
      occupancy <= 0 ||
      occupancy > 100
    ) {
      setThresholdError('Use valid numbers (occupancy 1-100).');
      return;
    }

    setSavingThresholds(true);
    setThresholdError(null);
    try {
      const res = await fetch(`${SERVER_URL}/api/settings/thresholds`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ occupancyPercent: occupancy, maxTemperature }),
      });
      const data = await res.json();
      setThresholds(data.thresholds);
      setThresholdBreaches({
        occupancy: data.occupancyBreaches || [],
        temperature: data.temperatureBreaches || [],
      });
    } catch (error) {
      console.error('Error saving thresholds:', error);
      setThresholdError('Failed to save thresholds.');
    } finally {
      setSavingThresholds(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <View>
            <Text style={styles.welcomeText}>Welcome, {user?.name || user?.email}</Text>
            <Text style={styles.roleText}>Administrator</Text>
            <Text style={styles.branchText}>{activeBranch}</Text>
          </View>
          <Pressable onPress={signOut} style={styles.signOutButton}>
            <Text style={styles.signOutText}>Sign Out</Text>
          </Pressable>
        </View>

        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{activeVisitors.length}</Text>
            <Text style={styles.statLabel}>Active Visitors</Text>
          </View>

          <View style={styles.statCard}>
            <Text style={styles.statValue}>{activeRooms}</Text>
            <Text style={styles.statLabel}>Occupied Rooms</Text>
          </View>

          <View style={styles.statCard}>
            <Text style={styles.statValue}>{totalStaff}</Text>
            <Text style={styles.statLabel}>Staff Members</Text>
          </View>

          <View style={styles.statCard}>
            <Text style={styles.statValue}>{visitorLogs.length}</Text>
            <Text style={styles.statLabel}>Total Logs</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          {visitorLogs.slice(0, 5).length > 0 ? (
            visitorLogs.slice(0, 5).map((log) => (
              <View key={log.id} style={styles.activityItem}>
                <Text style={styles.activityText}>
                  <Text style={styles.activityName}>{log.visitorName}</Text> checked{' '}
                  {log.checkOutTime ? 'out' : 'in'} of Room {log.roomId}
                </Text>
                <Text style={styles.activityTime}>{log.checkInTime.toLocaleString()}</Text>
              </View>
            ))
          ) : (
            <Text style={styles.emptyText}>No recent activity</Text>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Currently Active Visitors</Text>
          {activeVisitors.length > 0 ? (
            activeVisitors.map((visitor) => (
              <View key={visitor.id} style={styles.visitorItem}>
                <Text style={styles.visitorName}>{visitor.name}</Text>
                <Text style={styles.visitorPhone}>{visitor.phoneNumber}</Text>
                <Text style={styles.visitorRoom}>Room {visitor.roomId}</Text>
                <Text style={styles.visitorTime}>Since {visitor.checkInTime.toLocaleTimeString()}</Text>
              </View>
            ))
          ) : (
            <Text style={styles.emptyText}>No active visitors</Text>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            Historical Analytics (Last {analyticsDays} Days)
          </Text>
          {analyticsLoading ? (
            <Text style={styles.emptyText}>Loading analytics...</Text>
          ) : analyticsError ? (
            <Text style={styles.errorText}>{analyticsError}</Text>
          ) : (
            <>
              <View style={styles.analyticsBlock}>
                <Text style={styles.analyticsTitle}>Visitor Volume</Text>
                {volumeChartData.length > 0 ? (
                  <MiniBarChart data={volumeChartData} />
                ) : (
                  <Text style={styles.emptyText}>No visitor volume data yet</Text>
                )}
                {peakHour ? (
                  <Text style={styles.analyticsMeta}>
                    Peak hour: {peakHour.hour}:00 ({peakHour.count} visits)
                  </Text>
                ) : null}
              </View>

              <View style={styles.analyticsBlock}>
                <Text style={styles.analyticsTitle}>Average Visit Duration</Text>
                <Text style={styles.analyticsMeta}>
                  Overall average: {formatMinutes(durationStats.overallAvgMinutes)}
                </Text>
                {durationStats.byRoom.length > 0 ? (
                  durationStats.byRoom.slice(0, 5).map((room) => (
                    <View
                      key={`${room.roomID ?? 'room'}-${room.roomName ?? 'unknown'}`}
                      style={styles.analyticsRow}
                    >
                      <Text style={styles.analyticsLabel}>
                        {room.roomName || `Room ${room.roomID ?? 'Unknown'}`}
                      </Text>
                      <Text style={styles.analyticsValue}>
                        {formatMinutes(room.avgMinutes)}
                      </Text>
                    </View>
                  ))
                ) : (
                  <Text style={styles.emptyText}>No duration data yet</Text>
                )}
              </View>

              <View style={styles.analyticsBlock}>
                <Text style={styles.analyticsTitle}>Occupancy Trends</Text>
                {occupancyChartData.length > 0 ? (
                  <MiniBarChart data={occupancyChartData} barColor="#4caf50" />
                ) : (
                  <Text style={styles.emptyText}>No occupancy trend data yet</Text>
                )}
              </View>

            </>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Threshold Settings</Text>
          {thresholdBreaches.occupancy.length === 0 &&
          thresholdBreaches.temperature.length === 0 ? (
            <Text style={styles.emptyText}>No threshold alerts at the moment</Text>
          ) : (
            <View style={styles.alertBanner}>
              <Text style={styles.alertTitle}>Active Threshold Alerts</Text>
              {thresholdBreaches.occupancy.map((breach) => (
                <Text key={`occ-${breach.roomID}`} style={styles.alertItem}>
                  {breach.roomName}: {breach.occupancyPercent}% occupancy
                </Text>
              ))}
              {thresholdBreaches.temperature.map((breach) => (
                <Text key={`temp-${breach.roomID}`} style={styles.alertItem}>
                  {breach.roomName}: {breach.temperature}°C
                </Text>
              ))}
            </View>
          )}

          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>Occupancy %</Text>
            <TextInput
              style={styles.inputField}
              value={occupancyInput}
              onChangeText={setOccupancyInput}
              keyboardType="numeric"
              placeholder="85"
            />
          </View>
          <View style={styles.inputRow}>
            <Text style={styles.inputLabel}>Max Temperature (°C)</Text>
            <TextInput
              style={styles.inputField}
              value={temperatureInput}
              onChangeText={setTemperatureInput}
              keyboardType="numeric"
              placeholder="26"
            />
          </View>

          {thresholdError ? <Text style={styles.errorText}>{thresholdError}</Text> : null}
          <Pressable
            style={[
              styles.saveButton,
              savingThresholds ? styles.saveButtonDisabled : null,
            ]}
            onPress={saveThresholds}
            disabled={savingThresholds}
          >
            <Text style={styles.saveButtonText}>
              {savingThresholds ? 'Saving...' : 'Save Thresholds'}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  welcomeText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  roleText: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  branchText: {
    fontSize: 12,
    color: '#2069f1',
    marginTop: 2,
  },
  signOutButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#d32f2f',
    borderRadius: 6,
  },
  signOutText: {
    color: '#fff',
    fontWeight: '600',
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#2069f1',
    marginBottom: 8,
  },
  statLabel: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  section: {
    backgroundColor: '#fff',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  activityItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  activityText: {
    fontSize: 14,
    color: '#666',
  },
  activityName: {
    fontWeight: '600',
    color: '#333',
  },
  activityTime: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  visitorItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  visitorName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  visitorPhone: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  visitorRoom: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  visitorTime: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
    fontStyle: 'italic',
    textAlign: 'center',
    padding: 20,
  },
  analyticsBlock: {
    marginBottom: 16,
  },
  analyticsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  analyticsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  analyticsLabel: {
    fontSize: 14,
    color: '#666',
  },
  analyticsValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
  },
  chartContainer: {
    gap: 8,
    marginTop: 6,
  },
  chartRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  chartLabel: {
    width: 70,
    fontSize: 12,
    color: '#666',
  },
  chartBarTrack: {
    flex: 1,
    height: 10,
    backgroundColor: '#eef2f7',
    borderRadius: 6,
    overflow: 'hidden',
  },
  chartBarFill: {
    height: '100%',
    borderRadius: 6,
  },
  chartValue: {
    width: 30,
    textAlign: 'right',
    fontSize: 12,
    color: '#333',
    fontWeight: '600',
  },
  analyticsMeta: {
    fontSize: 12,
    color: '#999',
    marginTop: 6,
  },
  alertBanner: {
    backgroundColor: '#fff3e0',
    borderRadius: 10,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ffe0b2',
  },
  alertTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#e65100',
    marginBottom: 6,
  },
  alertItem: {
    fontSize: 13,
    color: '#e65100',
    marginBottom: 4,
  },
  inputRow: {
    marginBottom: 12,
  },
  inputLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 6,
  },
  inputField: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    backgroundColor: '#fff',
    fontSize: 16,
  },
  saveButton: {
    backgroundColor: '#2069f1',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonDisabled: {
    backgroundColor: '#8aaefb',
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
  errorText: {
    color: '#d32f2f',
    fontSize: 12,
    marginBottom: 8,
  },
});
