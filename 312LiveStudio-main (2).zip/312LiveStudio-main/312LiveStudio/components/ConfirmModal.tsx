import React from "react";
import {
    Modal,
    Pressable,
    StyleSheet,
    Text,
    View
} from "react-native";

type ConfirmModalProps = {
  visible: boolean;
  title?: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  destructive?: boolean; 
  disabled?: boolean;

  onConfirm: () => void | Promise<void>;
  onCancel: () => void;
};

export default function ConfirmModal({
  visible,
  title = "Confirm",
  message,
  confirmText = "Confirm",
  cancelText = "Cancel",
  destructive = false,
  disabled = false,
  onConfirm,
  onCancel,
}: ConfirmModalProps) {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onCancel}
    >
      <View style={styles.backdrop}>
        <View style={styles.card}>

          <Text style={styles.title}>{title}</Text>
          <Text style={styles.message}>{message}</Text>

          <View style={styles.buttonRow}>
            <Pressable
              onPress={onCancel}
              style={({ pressed }) => [
                styles.button,
                styles.cancelButton,
                pressed && styles.pressed,
              ]}
            >
              <Text style={styles.cancelText}>{cancelText}</Text>
            </Pressable>

            <Pressable
              onPress={onConfirm}
              disabled={disabled}
              style={({ pressed }) => [
                styles.button,
                destructive ? styles.dangerButton : styles.confirmButton,
                (pressed && !disabled) && styles.pressed,
                disabled && styles.disabled,
              ]}
            >
              <Text style={styles.confirmText}>{confirmText}</Text>
            </Pressable>
          </View>

        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  card: {
    width: "100%",
    maxWidth: 420,
    borderRadius: 14,
    padding: 16,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOpacity: 0.25,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 8 },
    elevation: 8,
      },
  title: { 
    fontSize: 18, 
    fontWeight: "700",
     marginBottom: 8
 },
  message: { 
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 16
    },

  buttonRow: {
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 10
    },

  button: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    minWidth: 96,
    alignItems: "center",
    justifyContent: "center",
  },

  cancelButton: { backgroundColor: "#eee" },
  confirmButton: { backgroundColor: "#1f6feb" },
  dangerButton: { backgroundColor: "#d11a2a" },

  cancelText: { color: "#111", fontWeight: "600" },
  confirmText: { color: "white", fontWeight: "700" },

  pressed: { transform: [{ scale: 0.98 }], opacity: 0.95 },
  disabled: { opacity: 0.55 },
});
