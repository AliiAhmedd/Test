import { useSocket } from "@/contexts/SocketContext";
import { Modal, Pressable, Text, View } from "react-native";

function AlarmPopup() {
  const { activeAlarm,acknowledgeAlarm} = useSocket();

  return (
    <Modal
      visible={!!activeAlarm}
      transparent
      animationType="fade"
      onRequestClose={acknowledgeAlarm}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.55)",
          justifyContent: "center",
          alignItems: "center",
          padding: 16,
        }}
      >
        <View
          style={{
            width: "100%",
            maxWidth: 420,
            borderRadius: 14,
            padding: 16,
            backgroundColor: "white",
          }}
        >
          <Text style={{ fontSize: 18, fontWeight: "700", marginBottom: 8 }}>
            Alarm Triggered in Room {activeAlarm?.roomName}
          </Text>

          <Text style={{ fontSize: 16, marginBottom: 16 }}>
            Room: <Text style={{ fontWeight: "700" }}>{activeAlarm?.roomID}</Text>
          </Text>

          <Pressable
            onPress={acknowledgeAlarm}
            style={{
              backgroundColor: "#111",
              paddingVertical: 12,
              borderRadius: 10,
              alignItems: "center",
            }}
          >
            <Text style={{ color: "white", fontSize: 16, fontWeight: "600" }}>
              Acknowledge
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
export default AlarmPopup;