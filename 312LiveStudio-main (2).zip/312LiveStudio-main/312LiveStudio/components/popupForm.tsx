import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

export default function popupForm() {
    const [roomName,setRoomName] = useState("");
    const [maxOccupancy,setMaxOccupancy] = useState("");
  return (
    <View>
      <Text>Enter Room Details:</Text>
      <View>

            
      </View>
    </View>
  )
}

const styles = StyleSheet.create({})