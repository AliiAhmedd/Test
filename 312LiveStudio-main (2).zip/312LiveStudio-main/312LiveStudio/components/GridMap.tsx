import { Ionicons } from "@expo/vector-icons";
import { memo, useMemo } from "react";
import { Pressable, StyleSheet, View } from "react-native";

type gridMapProps={
    rows:number;
    cols:number;
    cellSize:number;
    selected:Set<number>;
    saved:Set<number>;
    onCellPress:(index:number) => void;
    cellColors?: Record<number, string>;
}
type gridCell={
    index:number;
    selected:boolean;
    onPress:(index:number)=>void;
    size:number;
    saved:boolean;
    color?: string;
}

const Cell = memo(function Cell({index,selected,saved,size, onPress, color}:gridCell) {
      
        return(
        <Pressable onPress={()=> onPress(index)} 
        style={[styles.cell, { width: size, height: size }, 
        color ? { backgroundColor: color } : null,
        selected && styles.cellSelected, saved && styles.cellSaved]}>
           {selected && !saved && (
            <Ionicons name="triangle"/>)}
            {saved && (
            <Ionicons name="square"/>)}
            </Pressable>

        );
});

export default function GridMap({rows,cols,cellSize,selected,saved,onCellPress,cellColors}:gridMapProps ){
  const total = rows * cols;
  const indices = useMemo(()=> Array.from({length:total},(_,i)=>i),[total]);
  return (
    <View style = {[styles.grid,{width:cols*cellSize}, ]}>
      {indices.map((i)=>(
        <Cell
          key={i}
          index={i}
          selected={selected.has(i)}
          saved={saved.has(i)}
          size={cellSize}
          color={cellColors ? cellColors[i] : undefined}
          onPress={() => onCellPress(i)}/>

      ))}

    </View>
    )

}

const styles = StyleSheet.create({
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    backgroundColor: "#f9fafb",
    borderRadius: 12,
    borderColor: "rgba(0,0,0,0.08)",
  },
  cell: {
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.12)",
    backgroundColor: "#ffffff",
    borderRadius: 4,
  },
  cellSelected: {
    backgroundColor: "#2069f1",
  },
  cellSaved:{
    backgroundColor: "#52ec5f",
  }
});