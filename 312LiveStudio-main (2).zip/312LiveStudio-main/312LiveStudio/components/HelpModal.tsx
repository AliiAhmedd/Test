import { Ionicons } from "@expo/vector-icons";
import React from "react";
import { Modal, Pressable, StyleSheet, Text, View } from "react-native";

type HelpModalProps = {
  visible: boolean;
  onClose: () => void;
  title: string;
  lines: string[]; // each item is its own line
};

function HelpModal({ visible, onClose, title, lines }: HelpModalProps) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={modalStyles.overlay} onPress={onClose}>
        <Pressable style={modalStyles.card} onPress={() => {}}>
          <View style={modalStyles.header}>
            <View style={modalStyles.titleRow}>
              <Ionicons name="information-circle-outline" size={20} />
              <Text style={modalStyles.title}>{title}</Text>
            </View>
            <Pressable onPress={onClose} hitSlop={10} style={modalStyles.closeBtn}>
              <Ionicons name="close" size={20} />
            </Pressable>
          </View>

          <View style={modalStyles.body}>
            {lines.map((line, i) => (
              <View key={`${i}-${line}`} style={modalStyles.row}>
                <Text style={modalStyles.bullet}>{i + 1}.</Text>
                <Text style={modalStyles.text}>{line}</Text>
              </View>
            ))}
          </View>

          <Pressable style={modalStyles.primaryBtn} onPress={onClose}>
            <Text style={modalStyles.primaryBtnText}>Got it</Text>
          </Pressable>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const modalStyles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "center",
    padding: 16,
    backgroundColor: "rgba(0,0,0,0.45)",
  },
  card: {
    borderRadius: 16,
    padding: 16,
    backgroundColor: "#fff",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    flexShrink: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    flexShrink: 1,
  },
  closeBtn: {
    padding: 6,
    borderRadius: 999,
  },
  body: {
    gap: 10,
    marginBottom: 14,
  },
  row: {
    flexDirection: "row",
    gap: 10,
    alignItems: "flex-start",
  },
  bullet: {
    width: 22,
    fontWeight: "700",
  },
  text: {
    flex: 1,
    fontSize: 14,
    lineHeight: 20,
  },
  primaryBtn: {
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
    backgroundColor: "#111",
  },
  primaryBtnText: {
    color: "#fff",
    fontWeight: "700",
  },
});
export default HelpModal;