import { User } from '@/types/user';

export const USERS: User[] = [
  // Admin users
  {
    id: 'admin-1',
    email: 'admin.abdulla@lancs.uk',
    password: 'passwords123',
    role: 'admin',
    name: 'Abdulla (Admin)',
  },
  {
    id: 'admin-2',
    email: 'admin.ali@lancs.uk',
    password: 'passwords123',
    role: 'admin',
    name: 'Ali (Admin)',
  },
  {
    id: 'admin-3',
    email: 'admin.sam@lancs.uk',
    password: 'passwords123',
    role: 'admin',
    name: 'Sam (Admin)',
  },
  {
    id: 'admin-4',
    email: 'admin.eddie@lancs.uk',
    password: 'passwords123',
    role: 'admin',
    name: 'Eddie (Admin)',
  },
  {
    id: 'admin-5',
    email: 'admin.harvey@lancs.uk',
    password: 'passwords123',
    role: 'admin',
    name: 'Harvey (Admin)',
  },
  // Staff users
  {
    id: 'staff-1',
    email: 'staff.abdulla@lancs.uk',
    password: 'passwords123',
    role: 'reception',
    name: 'Abdulla (Reception)',
  },
  {
    id: 'staff-2',
    email: 'staff.ali@lancs.uk',
    password: 'passwords123',
    role: 'monitor',
    name: 'Ali (Monitor)',
  },
  {
    id: 'staff-3',
    email: 'staff.sam@lancs.uk',
    password: 'passwords123',
    role: 'reception',
    name: 'Sam (Reception)',
  },
  {
    id: 'staff-4',
    email: 'staff.eddie@lancs.uk',
    password: 'passwords123',
    role: 'monitor',
    name: 'Eddie (Monitor)',
  },
  {
    id: 'staff-5',
    email: 'staff.harvey@lancs.uk',
    password: 'passwords123',
    role: 'reception',
    name: 'Harvey (Reception)',
  },
];
