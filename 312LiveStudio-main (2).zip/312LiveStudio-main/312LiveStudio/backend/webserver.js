"use strict";
const express = require("express");
const cors = require("cors");
const { initializeDatabase, executeQuery, executeStatement } = require("./db/db");
const WebSocket = require("ws");
const {
  MapDAO,
  WardDAO,
  StaffDAO,
  VisitorDAO,
  WaitingListDAO,
  LocationDAO,
  AnalyticsDAO,
  SettingsDAO,
} = require("./db/dao");

const app = express();
app.use(cors());
app.use(express.json());

initializeDatabase().catch((error) => {
  console.error("Database initialization failed:", error);
});

//const hostname = "127.0.0.1";
// going to test for mobile running on 0.0.0.0
const hostname = "0.0.0.0";
const port = 3000;
const server = app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});

const wss = new WebSocket.Server({ noServer: true });
wss.on("connection", (ws) => {
  console.log("New WebSocket Connection Established");
  ws.on("error", console.error);

  ws.on("message", function message(data) {
    console.log("received: %s", data);
  });

  ws.send(JSON.stringify({ message: "Something" }));
});

function broadcastAlarm(roomID, roomName) {
  console.log("Broadcasting ALARM to all clients on room:", roomID);
  console.log("Total Clients Connected: ", wss.clients.size);
  wss.clients.forEach(function each(client) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: "ALARM", roomID, roomName }));
      console.log("Sent ALARM to clients on room:", roomID);
    }
  });
}

function broadcastStaffInOut(staffID, roomID, action) {
  wss.clients.forEach(function each(client) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(
        JSON.stringify({ type: "STAFF_IN_OUT", staffID, roomID, action }),
      );
    }
  });
}

wss.on("error", console.error);

server.on("upgrade", (req, socket, head) => {
  wss.handleUpgrade(req, socket, head, (ws) => {
    wss.emit("connection", ws, req);
  });
});

// ------------------------
// API Endpoints
// ------------------------

// Debug / Test
app.get("/api/debug/wards", async (req, res) => {
  try {
    const wards = await WardDAO.debugGetAllWards();
    res.json(wards);
  } catch (error) {
    res.status(500).json({ error: "Failed to load wards for debug" });
  }
});

app.post("/api/debug/seed-test-rooms", async (req, res) => {
  try {
    const { branchName, roomsCount } = req.body || {};
    const count = Math.min(Math.max(Number(roomsCount) || 4, 1), 10);

    let mapDetails = null;
    if (branchName) {
      mapDetails = await MapDAO.getLatestMapByBranch(branchName);
    }
    if (!mapDetails) {
      const maps = await MapDAO.getAllMaps();
      mapDetails = maps.length ? maps[0] : null;
    }
    if (!mapDetails) {
      return res.status(400).json({ error: "No map found to attach rooms." });
    }

    const randomInt = (min, max) =>
      Math.floor(Math.random() * (max - min + 1)) + min;
    const createdRooms = [];
    const createdVisitors = [];
    const createdLogs = [];
    const seedPrefix = `TEST_ROOM_${Date.now()}`;

    for (let i = 1; i <= count; i += 1) {
      const maxOccupancy = randomInt(4, 10);
      const currentOccupancy = randomInt(0, maxOccupancy);
      const numberOfNurses = randomInt(1, 3);
      const room = await WardDAO.createWard({
        mapID: mapDetails.mapID,
        roomName: `${seedPrefix}_${i}`,
        position: JSON.stringify([]),
        maxOccupancy,
        currentOccupancy,
        numberOfNurses,
      });
      createdRooms.push(room);

      for (let j = 1; j <= currentOccupancy; j += 1) {
        const visitorName = `TEST_VISITOR_${room.roomID}_${j}`;
        const visitor = await VisitorDAO.createVisitor({
          name: visitorName,
          currentRoomID: room.roomID,
        });
        createdVisitors.push(visitor);

        const daysAgo = randomInt(0, 13);
        const minutesAgo = randomInt(0, 23 * 60);
        const checkInTime = new Date();
        checkInTime.setDate(checkInTime.getDate() - daysAgo);
        checkInTime.setMinutes(checkInTime.getMinutes() - minutesAgo);
        const duration = randomInt(20, 120);
        const checkOutTime = new Date(checkInTime.getTime() + duration * 60000);

        await VisitorDAO.insertVisitorLog({
          externalId: `test-${visitorName}`,
          visitorID: visitor.visitorID,
          name: visitorName,
          phoneNumber: `07${randomInt(100000000, 999999999)}`,
          roomID: room.roomID,
          checkInTime,
          checkOutTime,
          duration,
        });
        createdLogs.push(visitorName);
      }
    }

    res.json({
      success: true,
      mapID: mapDetails.mapID,
      roomsCreated: createdRooms.length,
      visitorsCreated: createdVisitors.length,
      logsCreated: createdLogs.length,
      roomPrefix: seedPrefix,
    });
  } catch (error) {
    console.error("Error seeding test rooms:", error);
    res.status(500).json({ error: "Failed to seed test rooms" });
  }
});

app.post("/api/debug/clear-test-rooms", async (req, res) => {
  try {
    const logsResult = await executeStatement(
      "DELETE FROM visitor_logs WHERE visitorName LIKE 'TEST_VISITOR_%' OR name LIKE 'TEST_VISITOR_%'",
    );
    const visitorsResult = await executeStatement(
      "DELETE FROM visitors WHERE name LIKE 'TEST_VISITOR_%'",
    );
    const roomsResult = await executeStatement(
      "DELETE FROM room WHERE roomName LIKE 'TEST_ROOM_%'",
    );
    res.json({
      success: true,
      logsDeleted: logsResult.changes || 0,
      visitorsDeleted: visitorsResult.changes || 0,
      roomsDeleted: roomsResult.changes || 0,
    });
  } catch (error) {
    console.error("Error clearing test rooms:", error);
    res.status(500).json({ error: "Failed to clear test rooms" });
  }
});

app.get("/api/testServer", (req, res) => {
  try {
    console.log("Test Server Endpoint Hit");
    broadcastAlarm(5);
    console.log("Sent Alarm Broadcast");
    res.end("Server up!");
  } catch (error) {
    res.end("Error found: ", error);
  }
});

// Rooms & Map
app.post("/api/saveMapLayout", async (req, res) => {
  try {
    const { branchName, rows, columns: cols, mapName, rooms } = req.body;
    if (!branchName || typeof branchName !== "string") {
      return res.status(400).json({ error: "Branch name is required" });
    }
    if (!mapName || typeof mapName !== "string") {
      return res.status(400).json({ error: "Map name is required" });
    }
    if (!Number.isInteger(rows) || rows <= 0) {
      return res.status(400).json({ error: "rows must be positive integer" });
    }
    if (!Number.isInteger(cols) || cols <= 0) {
      return res
        .status(400)
        .json({ error: "columns must be positive integer" });
    }
    if (!Array.isArray(rooms)) {
      return res.status(400).json({ error: "rooms must be an array" });
    }

    const map = await MapDAO.createMap({
      mapName: mapName.trim(),
      rows,
      columns: cols,
      branchName: branchName.trim(),
    });
    const mapID = map.mapID;

    for (const element of rooms) {
      const positionJSON = JSON.stringify(element.cells);
      await WardDAO.createWard({
        mapID: mapID || 0,
        roomName: element.name,
        position: positionJSON,
        maxOccupancy: element.maxCapacity,
        currentOccupancy: element.currentOccupancy || 0,
        numberOfNurses: element.nurses || 0,
      });
    }

    console.log("All rooms processed");
    res
      .status(201)
      .json({ message: "Map and rooms saved successfully", mapID });
  } catch (err) {
    console.log("Error on Save Map Layout: ", err);
    return res.status(500).json({ error: "Save Map Error" });
  }
});

app.post("/api/loadMapLayout", async (req, res) => {
  try {
    const { mapID, branchName } = req.body;
    let mapDetails = null;

    if (branchName) mapDetails = await MapDAO.getLatestMapByBranch(branchName);
    else if (mapID) mapDetails = await MapDAO.getMapById(mapID);

    if (!mapDetails) {
      return res.json({ mapName: null, rows: 0, columns: 0, wards: [] });
    }

    const wardRows = await MapDAO.getWardsByMap(mapDetails.mapID);
    const wards = wardRows.map((row) => ({
      id: row.roomID,
      name: row.roomName,
      capacity: {
        max: row.maxOccupancy,
        current: row.currentOccupancy,
      },
      position: JSON.parse(row.position),
      nurses: row.numberOfNurses,
    }));

    res.json({
      mapName: mapDetails.mapName,
      rows: mapDetails.rows,
      columns: mapDetails.columns,
      wards,
    });
  } catch (err) {
    console.log("Error on Load Map Layout: ", err);
    return res.status(500).json({ error: "Load Map Error" });
  }
});

app.post("/api/removeRoom", async (req, res) => {
  try {
    const roomID = req.body.roomId;
    console.log("Removing Room ID: ", roomID);
    await WardDAO.deleteWard(roomID);
    res.json({ message: "Room removed successfully" });
  } catch (error) {
    console.log("Error on Remove Room: ", error);
    res.status(500).json({ error: "Internal Error on removing room" });
  }
});

// Room Temperature
app.get("/api/roomTemperature/:roomID", async (req, res) => {
  try {
    const roomID = Number(req.params.roomID);
    if (Number.isNaN(roomID))
      return res.status(400).json({ error: "Invalid roomID" });

    const latestTemp = await WardDAO.getLatestTemperature(roomID);
    return res.json({ roomID, temperature: latestTemp });
  } catch (error) {
    console.log("Error fetching room temperature", error);
    return res.status(500).json({ error: "Failed to fetch room temperature" });
  }
});

// Temperature history (per branch)
app.get("/api/temperature/history", async (req, res) => {
  try {
    const branchName = req.query.branchName;
    if (!branchName) {
      return res.status(400).json({ error: "branchName is required" });
    }
    const limit = Math.min(Math.max(Number(req.query.limit) || 20, 1), 200);
    const rows = await executeQuery(
      `
      SELECT roomID, roomName, temperature, createdAt, logID
      FROM (
        SELECT
          t.roomID as roomID,
          r.roomName as roomName,
          t.temperature as temperature,
          t.createdAt as createdAt,
          t.logID as logID,
          ROW_NUMBER() OVER (PARTITION BY t.roomID ORDER BY t.logID DESC) as rn
        FROM temperature_logs t
        JOIN room r ON t.roomID = r.roomID
        JOIN maps m ON r.mapID = m.mapID
        WHERE m.branchName = ?
      )
      WHERE rn <= ?
      ORDER BY roomID ASC, logID ASC
      `,
      [branchName, limit],
    );

    const averages = await executeQuery(
      `
      SELECT AVG(temp) as averageTemperature
      FROM (
        SELECT t.roomID, t.temperature as temp
        FROM temperature_logs t
        JOIN room r ON t.roomID = r.roomID
        JOIN maps m ON r.mapID = m.mapID
        WHERE m.branchName = ?
          AND t.logID IN (
            SELECT MAX(logID) FROM temperature_logs GROUP BY roomID
          )
      )
      `,
      [branchName],
    );

    const rooms = {};
    rows.forEach((row) => {
      const key = row.roomID;
      if (!rooms[key]) {
        rooms[key] = {
          roomID: row.roomID,
          roomName: row.roomName,
          readings: [],
        };
      }
      rooms[key].readings.push({
        temperature: row.temperature,
        createdAt: row.createdAt,
        logID: row.logID,
      });
    });

    res.json({
      branchName,
      averageTemperature:
        averages.length && averages[0].averageTemperature !== null
          ? Number(averages[0].averageTemperature)
          : null,
      rooms: Object.values(rooms),
    });
  } catch (error) {
    console.error("Error fetching temperature history:", error);
    res.status(500).json({ error: "Failed to fetch temperature history" });
  }
});

app.post("/api/roomTemperature", async (req, res) => {
  try {
    const { roomID, temperature, humidity } = req.body;
    console.log(
      "Room ID: ",
      roomID,
      " Temperature: ",
      temperature,
      "Humidity",
      humidity,
    );
    await WardDAO.logRoomTemperature(roomID, temperature);
    res.end("Room Temperature Logged");
  } catch (err) {
    console.log("Error on Room Temperature", err);
    res.status(500).json({ error: "Failed to log room temperature" });
  }
});

// Alarms
app.post("/api/patientAlarm", async (req, res) => {
  try {
    const roomID = req.body.roomID;
    console.log("Patient Alarm activated in room: ", roomID);
    const roomInfo = await WardDAO.getWardById(roomID);
    broadcastAlarm(roomID, roomInfo.roomName);
    res.status(200).json({ success: true, roomInfo });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Staff
app.get("/api/staff", async (req, res) => {
  try {
    const staff = await StaffDAO.getAllStaff();
    res.json(staff);
  } catch (error) {
    res.status(500).json({ error: "Failed to load staff" });
  }
});

app.post("/api/staff/assignBranch", async (req, res) => {
  try {
    const { email, branchName, name, staffType } = req.body;
    if (!email || !branchName || !name || !staffType) {
      return res.status(400).json({ error: "Required fields missing" });
    }

    const existing = await StaffDAO.getStaffByEmail(email);
    if (existing) {
      const updated = await StaffDAO.updateStaff(existing.staffID, {
        branchName,
      });
      return res.json(updated);
    }

    const created = await StaffDAO.createStaff({
      email,
      name,
      staffType,
      branchName,
    });
    return res.status(201).json(created);
  } catch (error) {
    res.status(500).json({ error: "Failed to assign branch" });
  }
});

// Visitors
app.get("/api/visitors/active", async (req, res) => {
  try {
    const visitors = await VisitorDAO.getActiveVisitors();
    return res.json(visitors);
  } catch (error) {
    console.error("Error fetching active visitors:", error);
    return res.status(500).json({ error: "Failed to fetch active visitors" });
  }
});
app.post("/api/visitors/clear-logs",async (req,res)=>{
    try {
        console.log("Clearing visitor logs");
        await VisitorDAO.clearVisitorLogs();
        res.json({success:true});
    } catch (error) {
        console.error("Error clearing visitor logs:", error);
        return res.status(500).json({ error: "Failed to clear visitor logs" });
    }
})
app.post("/api/visitors/sync", async (req, res) => {
  try {
    const { visitors } = req.body || {};
    if (!Array.isArray(visitors))
      return res.status(400).json({ error: "visitors array is required" });

    for (const visitor of visitors) {
      const existing = await VisitorDAO.getVisitorByName(visitor.name);
      if (existing) {
        await VisitorDAO.updateVisitor(existing.visitorID, {
          currentRoomID: visitor.roomId,
        });
      } else {
        await VisitorDAO.createVisitor({
          name: visitor.name,
          currentRoomID: visitor.roomId,
        });
      }
    }

    return res.json({ success: true, synced: visitors.length });
  } catch (error) {
    console.error("Error syncing visitors:", error);
    return res.status(500).json({ error: "Failed to sync visitors" });
  }
});

app.get("/api/roomEntered/:staffID", async (req, res) => {
  try {
    const staffID = Number(req.params.staffID);
    if (Number.isNaN(staffID)) {
      return res.status(400).json({ error: "Invalid staffID" });
    }

    // Get staff info
    const staff = await StaffDAO.getStaffById(staffID);
    if (!staff) {
      return res.status(404).json({ error: "Staff not found" });
    }

    // Optionally get room details
    let roomName = null;
    if (staff.currentRoomID) {
      const room = await WardDAO.getWardById(staff.currentRoomID);
      roomName = room ? room.roomName : null;
    }

    return res.json({
      staffID: staff.staffID,
      currentRoomID: staff.currentRoomID,
      currentRoomName: roomName,
    });
  } catch (error) {
    console.error("Error fetching staff room:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/api/roomEntered", (req, res) => {
  try {
    const staffID = req.body.staffID;
    let roomID = Number(req.body.closestRouter);
    console.log(staffID, "Entered: ", roomID);

    switch (roomID) {
      case 1:
        roomID = 44;
        break;
      case 2:
        roomID = 43;
        break;
      case 3:
        roomID = 42;
        break;
      case 4:
        roomID = 40;
        break;
      case 5:
        roomID = 41;
        break;
      case 6:
        roomID = 45;
        break;

      default:
        break;
    }

    broadcastStaffInOut(staffID, roomID, "IN");
  } catch (error) {
    res.send(500).json({ error: "Internal Error on loggin entry" });
  }
});

app.get("/api/visitors/logs", async (req, res) => {
  try {
    const logs = await executeQuery(
      `
      SELECT
        logID,
        externalId,
        visitorID,
        COALESCE(visitorName, name) as visitorName,
        phoneNumber,
        roomID,
        checkInTime,
        checkOutTime,
        duration
      FROM visitor_logs
      ORDER BY checkInTime DESC
      LIMIT 100
      `,
    );
    return res.json(logs);
  } catch (error) {
    console.error("Error fetching visitor logs:", error);
    return res.status(500).json({ error: "Failed to fetch visitor logs" });
  }
});

// Analytics
app.get("/api/analytics/visitors", async (req, res) => {
  try {
    const days = Math.min(
      Math.max(Number(req.query.days) || 14, 1),
      90,
    );
    const [dailyCounts, peakHour] = await Promise.all([
      AnalyticsDAO.getDailyVisitorCounts(days),
      AnalyticsDAO.getPeakVisitorHour(days),
    ]);
    res.json({ days, dailyCounts, peakHour });
  } catch (error) {
    console.error("Error fetching visitor analytics:", error);
    res.status(500).json({ error: "Failed to fetch visitor analytics" });
  }
});

app.get("/api/analytics/visit-durations", async (req, res) => {
  try {
    const days = Math.min(
      Math.max(Number(req.query.days) || 14, 1),
      90,
    );
    const stats = await AnalyticsDAO.getVisitDurationStats(days);
    res.json({ days, ...stats });
  } catch (error) {
    console.error("Error fetching visit duration analytics:", error);
    res.status(500).json({ error: "Failed to fetch visit duration analytics" });
  }
});

app.get("/api/analytics/occupancy-trends", async (req, res) => {
  try {
    const days = Math.min(
      Math.max(Number(req.query.days) || 14, 1),
      90,
    );
    const trends = await AnalyticsDAO.getOccupancyTrends(days);
    res.json({ days, ...trends });
  } catch (error) {
    console.error("Error fetching occupancy trends:", error);
    res.status(500).json({ error: "Failed to fetch occupancy trends" });
  }
});

// Threshold settings
app.get("/api/settings/thresholds", async (req, res) => {
  try {
    const thresholds = await SettingsDAO.getThresholds();
    const [occupancyBreaches, temperatureBreaches] = await Promise.all([
      SettingsDAO.getOccupancyBreaches(thresholds.occupancyPercent),
      SettingsDAO.getTemperatureBreaches(thresholds.maxTemperature),
    ]);
    res.json({ thresholds, occupancyBreaches, temperatureBreaches });
  } catch (error) {
    console.error("Error fetching thresholds:", error);
    res.status(500).json({ error: "Failed to fetch thresholds" });
  }
});

app.post("/api/settings/thresholds", async (req, res) => {
  try {
    const { occupancyPercent, maxTemperature } = req.body || {};
    const occupancy = Number(occupancyPercent);
    const temperature = Number(maxTemperature);
    if (
      Number.isNaN(occupancy) ||
      Number.isNaN(temperature) ||
      occupancy <= 0 ||
      occupancy > 100
    ) {
      return res.status(400).json({
        error: "occupancyPercent (1-100) and maxTemperature are required",
      });
    }
    const thresholds = await SettingsDAO.updateThresholds(
      occupancy,
      temperature,
    );
    const [occupancyBreaches, temperatureBreaches] = await Promise.all([
      SettingsDAO.getOccupancyBreaches(thresholds.occupancyPercent),
      SettingsDAO.getTemperatureBreaches(thresholds.maxTemperature),
    ]);
    res.json({ thresholds, occupancyBreaches, temperatureBreaches });
  } catch (error) {
    console.error("Error updating thresholds:", error);
    res.status(500).json({ error: "Failed to update thresholds" });
  }
});

app.post("/api/visitors/check-in", async (req, res) => {
  try {
    const { id: externalId, name, phoneNumber, roomId } = req.body || {};
    if (!name || !roomId)
      return res.status(400).json({ error: "name and roomId are required" });

    let visitor = await VisitorDAO.getVisitorByName(name);
    if (!visitor)
      visitor = await VisitorDAO.createVisitor({ name, currentRoomID: roomId });
    else
      visitor = await VisitorDAO.updateVisitor(visitor.visitorID, {
        currentRoomID: roomId,
      });

    await WardDAO.updateOccupancy(roomId, true);
    await VisitorDAO.logCheckIn({
      externalId,
      visitorID: visitor.visitorID,
      name,
      phoneNumber,
      roomID: roomId,
    });

    return res.json({ visitorID: visitor.visitorID });
  } catch (error) {
    console.error("Error on visitor check-in:", error);
    return res
      .status(500)
      .json({ error: "Internal error on visitor check-in" });
  }
});

app.post("/api/visitors/check-out", async (req, res) => {
  try {
    const { id: externalId, name } = req.body || {};
    if (!name && !externalId)
      return res.status(400).json({ error: "external id or name is required" });

    let visitor = null;
    if (name) visitor = await VisitorDAO.getVisitorByName(name);

    if (visitor) {
      const previousRoomID = visitor.currentRoomID;
      await VisitorDAO.checkOut(visitor.visitorID);
      await VisitorDAO.logCheckOut({
        externalId,
        visitorID: visitor.visitorID,
      });
      if (previousRoomID) {
        const result = await WardDAO.updateOccupancy(previousRoomID, false);
        if (!result.updated) {
          console.warn(
            `Failed to update occupancy for roomID ${previousRoomID} on visitor check-out: ${result.reason}`,
          );
        }
      }
    } else {
      await VisitorDAO.logCheckOut({ externalId, visitorID: null });
    }

    return res.json({ success: true });
  } catch (error) {
    console.error("Error on visitor check-out:", error);
    return res
      .status(500)
      .json({ error: "Internal error on visitor check-out" });
  }
});
