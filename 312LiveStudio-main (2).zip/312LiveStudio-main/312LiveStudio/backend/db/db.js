const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB = path.join(__dirname, 'hospital.db');
let database = null;

function openDatabase() {
  if (database) {
    return database;
  }

  return new Promise((resolve, reject) => { // returns a promise which is used to handle async db opening
    database = new sqlite3.Database(DB, (err) => {
      if (err) {
        console.error('Error opening DB:', err);
        reject(err); // reject the promise on error
      } else {
        console.log('DB successfully opened');
        resolve(database); // resolve the promise with the db object
      }
    });
  });
}

function getSchema() {
  return `
    CREATE TABLE IF NOT EXISTS maps (
        mapID INTEGER PRIMARY KEY AUTOINCREMENT,
        mapName TEXT NOT NULL,
        rows INTEGER NOT NULL,
        columns INTEGER NOT NULL,
        branchName TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS temperature_logs (
        logID INTEGER PRIMARY KEY AUTOINCREMENT,
        roomID INTEGER NOT NULL,
        temperature REAL NOT NULL,
        createdAt DATETIME,
        FOREIGN KEY (roomID) REFERENCES room(roomID) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS room (
        roomID INTEGER PRIMARY KEY AUTOINCREMENT,
        roomName TEXT NOT NULL,
        maxOccupancy INTEGER NOT NULL CHECK(maxOccupancy > 0),
        currentOccupancy INTEGER DEFAULT 0 CHECK(currentOccupancy >= 0),
        position TEXT NOT NULL,
        numberOfNurses INTEGER DEFAULT 0 CHECK(numberOfNurses >= 0),
        mapID INTEGER NOT NULL,
        FOREIGN KEY (mapID) REFERENCES maps(mapID) ON DELETE CASCADE,
        CHECK (currentOccupancy <= maxOccupancy)
    );
    CREATE TABLE IF NOT EXISTS staff (
        staffID INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        staffType TEXT NOT NULL CHECK(staffType IN ('nurse', 'doctor', 'admin')),
        currentRoomID INTEGER,
        isAvailable INTEGER DEFAULT 1 CHECK(isAvailable IN (0, 1)),
        FOREIGN KEY (currentRoomID) REFERENCES room (roomID) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS location (
        locationCoordinates TEXT PRIMARY KEY,
        roomId INTEGER NOT NULL,
        staffId INTEGER NOT NULL,
        FOREIGN KEY (roomId) REFERENCES room (roomID) ON DELETE CASCADE,
        FOREIGN KEY (staffId) REFERENCES staff (staffID) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS visitors (
        visitorID INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        currentRoomID INTEGER,
        medicalCondition TEXT,
        FOREIGN KEY (currentRoomID) REFERENCES room (roomID) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS waiting_list (
        waitingID INTEGER PRIMARY KEY AUTOINCREMENT,
        visitorID INTEGER NOT NULL,
        requestedStaffID INTEGER NOT NULL,
        urgency INTEGER NOT NULL DEFAULT 3 CHECK(urgency BETWEEN 1 AND 5),
        reason TEXT,
        status TEXT DEFAULT 'waiting' CHECK(status IN ('waiting', 'in-progress', 'completed', 'cancelled')),
        FOREIGN KEY (visitorID) REFERENCES visitors(visitorID) ON DELETE CASCADE,
        FOREIGN KEY (requestedStaffID) REFERENCES staff(staffID) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS appointments (
        appointmentID INTEGER PRIMARY KEY AUTOINCREMENT,
        visitorID INTEGER NOT NULL,
        staffID INTEGER NOT NULL,
        roomID INTEGER,
        appointmentDate DATETIME NOT NULL,
        duration INTEGER DEFAULT 30,
        appointmentType TEXT,
        status TEXT DEFAULT 'scheduled' CHECK(status IN ('scheduled', 'in-progress', 'completed', 'cancelled', 'no-show')),
        FOREIGN KEY (visitorID) REFERENCES visitors(visitorID) ON DELETE CASCADE,
        FOREIGN KEY (staffID) REFERENCES staff(staffID) ON DELETE CASCADE,
        FOREIGN KEY (roomID) REFERENCES room (roomID) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS visitor_logs (
      logID INTEGER PRIMARY KEY AUTOINCREMENT,
      externalId TEXT,
      visitorID INTEGER,
      name TEXT,
      visitorName TEXT,
      phoneNumber TEXT,
      roomID INTEGER,
      checkInTime DATETIME,
      checkOutTime DATETIME,
      duration INTEGER,
      FOREIGN KEY (visitorID) REFERENCES visitors(visitorID) ON DELETE SET NULL,
      FOREIGN KEY (roomID) REFERENCES room(roomID) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS threshold_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      occupancyPercent INTEGER NOT NULL,
      maxTemperature REAL NOT NULL,
      updatedAt DATETIME NOT NULL
    );
  `;
}

async function initializeDatabase() {
  try {
    const db = await openDatabase(); // makes sure db is opened before proceeding
    const schema = getSchema();
    
    const statements = schema 
      .split(';') //splits schemas into individual statements
      .map(stmt => stmt.trim()) // trims whitespace
      .filter(stmt => stmt.length > 0 && !stmt.startsWith('--')); // filters out empty statements and comments

    // execute each statement
    for (const statement of statements) {
      await new Promise((resolve, reject) => {
        db.run(statement, (err) => {
          if (err) {
            console.error('Error with the following statement:', err);
            reject(err);
          } else {
            resolve();
          }
        });
      });
    }

    await ensureVisitorLogsColumns(db);
    await ensureTemperatureLogsColumns(db);

    console.log('Database initialised successfully');
    return true;
  } catch (error) {
    console.error('Error initialising database:', error);
    throw error;
  }
}

async function ensureVisitorLogsColumns(db) {
  const columns = await new Promise((resolve, reject) => {
    db.all("PRAGMA table_info(visitor_logs)", (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows || []);
      }
    });
  });

  const existing = new Set(columns.map((column) => column.name));
  const addColumn = async (name, definition) => {
    if (existing.has(name)) return;
    await new Promise((resolve, reject) => {
      db.run(`ALTER TABLE visitor_logs ADD COLUMN ${definition}`, (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  };

  await addColumn("name", "name TEXT");
  await addColumn("visitorName", "visitorName TEXT");
  await addColumn("phoneNumber", "phoneNumber TEXT");
  await addColumn("checkInTime", "checkInTime DATETIME");
  await addColumn("checkOutTime", "checkOutTime DATETIME");
  await addColumn("duration", "duration INTEGER");
}

async function ensureTemperatureLogsColumns(db) {
  const columns = await new Promise((resolve, reject) => {
    db.all("PRAGMA table_info(temperature_logs)", (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows || []);
      }
    });
  });

  const existing = new Set(columns.map((column) => column.name));
  if (!existing.has("createdAt")) {
    await new Promise((resolve, reject) => {
      db.run("ALTER TABLE temperature_logs ADD COLUMN createdAt DATETIME", (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }
}

async function executeQuery(sql, params = []) { // executes a raw SQL SELECT query
  try {
    const db = await openDatabase();
    
    return new Promise((resolve, reject) => {
      db.all(sql, params, (err, rows) => { // use db.all to get all rows 
        if (err) {
          console.error('Error executing query:', err);
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  } catch (error) {
    console.error('Error executing query:', error);
    throw error;
  }
}

async function executeStatement(sql, params = []) { // executes a raw SQL statement (INSERT, UPDATE, DELETE)
  try {
    const db = await openDatabase();
    
    return new Promise((resolve, reject) => {
      db.run(sql, params, function(err) {
        if (err) {
          console.error('Error executing statement:', err);
          reject(err);
        } else {
          resolve({
            lastInsertRowId: this.lastID,
            changes: this.changes
          });
        }
      });
    });
  } catch (error) {
    console.error('Error executing statement:', error);
    throw error;
  }
}

async function closeDatabase() { // closes the db connection so that resources are freed
  if (database) {
    return new Promise((resolve, reject) => {
      database.close((err) => {
        if (err) {
          reject(err);
        } else {
          database = null;
          console.log('Database closed');
          resolve();
        }
      });
    });
  }
}

async function resetDatabase() { // drops all tables and re-initializes the database to clean the it
  try {
    const db = await openDatabase();
    
    const dropStatements = `
      DROP TABLE IF EXISTS appointments;
      DROP TABLE IF EXISTS waiting_list;
      DROP TABLE IF EXISTS visitors;
      DROP TABLE IF EXISTS location;
      DROP TABLE IF EXISTS staff;
      DROP TABLE IF EXISTS room;
      DROP TABLE IF EXISTS maps;
    `;
    
    const statements = dropStatements
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0);

    for (const statement of statements) {
      await new Promise((resolve, reject) => {
        db.run(statement, (err) => {
          if (err) reject(err);
          else resolve();
        });
      });
    }
    
    console.log('Database reset successfully');
    await initializeDatabase();
  } catch (error) {
    console.error('Error resetting database:', error);
    throw error;
  }
}

// module.exports exports all the database functions so other files can import them
module.exports = {
  openDatabase,
  initializeDatabase,
  executeQuery,
  executeStatement,
  closeDatabase,
  resetDatabase
};