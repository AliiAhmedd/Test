const { executeQuery, executeStatement } = require('../db');

class LocationDAO {
  static async getAllLocations() {
    return await executeQuery(`
      SELECT l.*,
        r.roomName,
        s.name as staffName,
        s.staffType
      FROM location l
      JOIN room r ON l.roomId = r.roomID
      JOIN staff s ON l.staffId = s.staffID
      ORDER BY l.locationCoordinates
    `);
  }

  static async getLocationByCoordinates(coordinates) {
    const results = await executeQuery(`
      SELECT l.*,
        r.roomName,
        s.name as staffName,
        s.staffType
      FROM location l
      JOIN room r ON l.roomId = r.roomID
      JOIN staff s ON l.staffId = s.staffID
      WHERE l.locationCoordinates = ?
    `, [coordinates]);
    return results.length > 0 ? results[0] : null;
  }

  static async getLocationsByRoom(roomId) {
    return await executeQuery(`
      SELECT l.*,
        r.roomName,
        s.name as staffName,
        s.staffType
      FROM location l
      JOIN room r ON l.roomId = r.roomID
      JOIN staff s ON l.staffId = s.staffID
      WHERE l.roomId = ?
    `, [roomId]);
  }

  static async getLocationsByStaff(staffId) {
    return await executeQuery(`
      SELECT l.*,
        r.roomName,
        s.name as staffName,
        s.staffType
      FROM location l
      JOIN room r ON l.roomId = r.roomID
      JOIN staff s ON l.staffId = s.staffID
      WHERE l.staffId = ?
    `, [staffId]);
  }

  static async createLocation(locationData) {
    const { locationCoordinates, roomId, staffId } = locationData;

    const result = await executeStatement(`
      INSERT INTO location (locationCoordinates, roomId, staffId)
      VALUES (?, ?, ?)
    `, [locationCoordinates, roomId, staffId]);

    return await this.getLocationByCoordinates(locationCoordinates);
  }

  static async updateLocation(coordinates, updates) {
    const allowedFields = ['roomId', 'staffId'];
    const fields = Object.keys(updates).filter(key => allowedFields.includes(key));
    
    if (fields.length === 0) {
      throw new Error('No valid fields to update');
    }

    const setClause = fields.map(field => `${field} = ?`).join(', ');
    const values = fields.map(field => updates[field]);
    
    await executeStatement(`
      UPDATE location 
      SET ${setClause}
      WHERE locationCoordinates = ?
    `, [...values, coordinates]);
    
    return await this.getLocationByCoordinates(coordinates);
  }

  static async deleteLocation(coordinates) {
    await executeStatement(`
      DELETE FROM location 
      WHERE locationCoordinates = ?
    `, [coordinates]);
    return true;
  }

  static async getStaffAtLocation(coordinates) {
    const results = await executeQuery(`
      SELECT s.*,
        r.roomName as currentLocation
      FROM location l
      JOIN staff s ON l.staffId = s.staffID
      JOIN room r ON l.roomId = r.roomID
      WHERE l.locationCoordinates = ?
    `, [coordinates]);
    return results.length > 0 ? results[0] : null;
  }
}

module.exports = LocationDAO;
