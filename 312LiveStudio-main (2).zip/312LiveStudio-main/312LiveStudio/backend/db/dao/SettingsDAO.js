const { executeQuery, executeStatement } = require("../db");

const DEFAULT_THRESHOLDS = {
  occupancyPercent: 85,
  maxTemperature: 26,
};

class SettingsDAO {
  static async getThresholds() {
    const rows = await executeQuery(
      "SELECT occupancyPercent, maxTemperature FROM threshold_settings WHERE id = 1",
    );
    if (rows.length) {
      return {
        occupancyPercent: rows[0].occupancyPercent,
        maxTemperature: rows[0].maxTemperature,
      };
    }

    await executeStatement(
      `
      INSERT OR REPLACE INTO threshold_settings
        (id, occupancyPercent, maxTemperature, updatedAt)
      VALUES (1, ?, ?, ?)
    `,
      [
        DEFAULT_THRESHOLDS.occupancyPercent,
        DEFAULT_THRESHOLDS.maxTemperature,
        new Date().toISOString(),
      ],
    );

    return { ...DEFAULT_THRESHOLDS };
  }

  static async updateThresholds(occupancyPercent, maxTemperature) {
    await executeStatement(
      `
      INSERT OR REPLACE INTO threshold_settings
        (id, occupancyPercent, maxTemperature, updatedAt)
      VALUES (1, ?, ?, ?)
    `,
      [occupancyPercent, maxTemperature, new Date().toISOString()],
    );
    return { occupancyPercent, maxTemperature };
  }

  static async getOccupancyBreaches(occupancyPercent) {
    return await executeQuery(
      `
      SELECT roomID, roomName, currentOccupancy, maxOccupancy,
             ROUND(CAST(currentOccupancy AS FLOAT) / maxOccupancy * 100, 1) as occupancyPercent
      FROM room
      WHERE maxOccupancy > 0
        AND (CAST(currentOccupancy AS FLOAT) / maxOccupancy * 100) >= ?
      ORDER BY occupancyPercent DESC
    `,
      [occupancyPercent],
    );
  }

  static async getTemperatureBreaches(maxTemperature) {
    return await executeQuery(
      `
      SELECT r.roomID, r.roomName, t.temperature
      FROM room r
      JOIN temperature_logs t ON t.roomID = r.roomID
      WHERE t.logID IN (
        SELECT MAX(logID) FROM temperature_logs GROUP BY roomID
      )
        AND t.temperature >= ?
      ORDER BY t.temperature DESC
    `,
      [maxTemperature],
    );
  }
}

module.exports = SettingsDAO;
