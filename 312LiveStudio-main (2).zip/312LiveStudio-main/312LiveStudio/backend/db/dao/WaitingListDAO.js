const { executeQuery, executeStatement } = require('../db');

class WaitingListDAO {
  static async getAllEntries(filters = {}) {
    let sql = `
      SELECT w.*,
        v.name as visitorName,
        s.name as staffName,
        s.staffType
      FROM waiting_list w
      JOIN visitors v ON w.visitorID = v.visitorID
      JOIN staff s ON w.requestedStaffID = s.staffID
      WHERE 1=1
    `;
    const params = [];

    if (filters.status) {
      sql += ' AND w.status = ?';
      params.push(filters.status);
    }

    if (filters.requestedStaffID) {
      sql += ' AND w.requestedStaffID = ?';
      params.push(filters.requestedStaffID);
    }

    if (filters.visitorID) {
      sql += ' AND w.visitorID = ?';
      params.push(filters.visitorID);
    }

    sql += ' ORDER BY w.urgency DESC, w.waitingID ASC';
    return await executeQuery(sql, params);
  }

  static async getEntryById(waitingID) {
    const results = await executeQuery(`
      SELECT w.*,
        v.name as visitorName,
        s.name as staffName,
        s.staffType
      FROM waiting_list w
      JOIN visitors v ON w.visitorID = v.visitorID
      JOIN staff s ON w.requestedStaffID = s.staffID
      WHERE w.waitingID = ?
    `, [waitingID]);
    return results.length > 0 ? results[0] : null;
  }

  static async createEntry(entryData) {
    const {
      visitorID,
      requestedStaffID,
      urgency = 3,
      reason = null,
      status = 'waiting'
    } = entryData;

    if (urgency < 1 || urgency > 5) {
      throw new Error('Urgency must be between 1 and 5');
    }

    const result = await executeStatement(`
      INSERT INTO waiting_list (
        visitorID, requestedStaffID, urgency, reason, status
      )
      VALUES (?, ?, ?, ?, ?)
    `, [
      visitorID, requestedStaffID, urgency, reason, status
    ]);

    return await this.getEntryById(result.lastInsertRowId);
  }

  static async updateEntry(waitingID, updates) {
    const allowedFields = ['urgency', 'reason', 'status', 'requestedStaffID'];
    
    const fields = Object.keys(updates).filter(key => allowedFields.includes(key));
    
    if (fields.length === 0) {
      throw new Error('No valid fields to update');
    }

    const setClause = fields.map(field => `${field} = ?`).join(', ');
    const values = fields.map(field => updates[field]);
    
    await executeStatement(`
      UPDATE waiting_list 
      SET ${setClause}
      WHERE waitingID = ?
    `, [...values, waitingID]); // combines values array, which includes all the values of the fields to be updated, with waitingID for the query parameters
    return await this.getEntryById(waitingID);
  }

  static async deleteEntry(waitingID) {
    await executeStatement(`DELETE FROM waiting_list WHERE waitingID = ?`, [waitingID]);
    return true;
  }

  static async getWaitingEntries() {
    return await this.getAllEntries({ status: 'waiting' });
  }

  static async getEntriesByStaff(staffID) {
    return await this.getAllEntries({ requestedStaffID: staffID });
  }

  static async getEntriesByVisitor(visitorID) {
    return await this.getAllEntries({ visitorID });
  }

  static async markInProgress(waitingID) {
    return await this.updateEntry(waitingID, { status: 'in-progress' });
  }

  static async markCompleted(waitingID) {
    return await this.updateEntry(waitingID, { status: 'completed' });
  }

  static async markCancelled(waitingID) {
    return await this.updateEntry(waitingID, { status: 'cancelled' });
  }

  static async getNextInQueue(staffID = null) {
    let sql = `
      SELECT w.*,
        v.name as visitorName,
        s.name as staffName,
        s.staffType
      FROM waiting_list w
      JOIN visitors v ON w.visitorID = v.visitorID
      JOIN staff s ON w.requestedStaffID = s.staffID
      WHERE w.status = 'waiting'
    `;
    const params = [];

    if (staffID) {
      sql += ' AND w.requestedStaffID = ?';
      params.push(staffID);
    }

    sql += ' ORDER BY w.urgency DESC, w.waitingID ASC LIMIT 1';
    
    const results = await executeQuery(sql, params);
    return results.length > 0 ? results[0] : null;
  }

  static async getQueueStatistics(staffID = null) {
    let sql = `
      SELECT 
        status,
        COUNT(*) as count,
        AVG(urgency) as avgUrgency
      FROM waiting_list
    `;
    const params = [];

    if (staffID) {
      sql += ' WHERE requestedStaffID = ?';
      params.push(staffID);
    }

    sql += ' GROUP BY status';
    
    return await executeQuery(sql, params);
  }
}

module.exports = WaitingListDAO;
