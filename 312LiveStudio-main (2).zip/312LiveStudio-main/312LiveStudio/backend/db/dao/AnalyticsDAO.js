const { executeQuery } = require("../db");

class AnalyticsDAO {
  static async getDailyVisitorCounts(days = 14) {
    const since = `-${days} days`;
    return await executeQuery(
      `
      SELECT date(checkInTime) as day, COUNT(*) as count
      FROM visitor_logs
      WHERE checkInTime IS NOT NULL
        AND date(checkInTime) >= date('now', ?)
      GROUP BY day
      ORDER BY day ASC
    `,
      [since],
    );
  }

  static async getPeakVisitorHour(days = 14) {
    const since = `-${days} days`;
    const rows = await executeQuery(
      `
      SELECT strftime('%H', checkInTime) as hour, COUNT(*) as count
      FROM visitor_logs
      WHERE checkInTime IS NOT NULL
        AND date(checkInTime) >= date('now', ?)
      GROUP BY hour
      ORDER BY count DESC, hour ASC
      LIMIT 1
    `,
      [since],
    );
    return rows.length ? rows[0] : null;
  }

  static async getVisitDurationStats(days = 14) {
    const since = `-${days} days`;
    const overallRows = await executeQuery(
      `
      SELECT AVG((julianday(checkOutTime) - julianday(checkInTime)) * 24 * 60) as avgMinutes
      FROM visitor_logs
      WHERE checkInTime IS NOT NULL
        AND checkOutTime IS NOT NULL
        AND date(checkInTime) >= date('now', ?)
    `,
      [since],
    );
    const byRoom = await executeQuery(
      `
      SELECT v.roomID as roomID, r.roomName as roomName,
             AVG((julianday(v.checkOutTime) - julianday(v.checkInTime)) * 24 * 60) as avgMinutes,
             COUNT(*) as visits
      FROM visitor_logs v
      LEFT JOIN room r ON v.roomID = r.roomID
      WHERE v.checkInTime IS NOT NULL
        AND v.checkOutTime IS NOT NULL
        AND date(v.checkInTime) >= date('now', ?)
      GROUP BY v.roomID
      ORDER BY avgMinutes DESC
    `,
      [since],
    );

    return {
      overallAvgMinutes: overallRows.length ? overallRows[0].avgMinutes : null,
      byRoom,
    };
  }

  static async getOccupancyTrends(days = 14) {
    const since = `-${days} days`;
    const dailyRoomCounts = await executeQuery(
      `
      SELECT date(v.checkInTime) as day,
             v.roomID as roomID,
             r.roomName as roomName,
             COUNT(*) as visits
      FROM visitor_logs v
      LEFT JOIN room r ON v.roomID = r.roomID
      WHERE v.checkInTime IS NOT NULL
        AND date(v.checkInTime) >= date('now', ?)
      GROUP BY day, v.roomID
      ORDER BY day DESC, visits DESC
    `,
      [since],
    );

    const roomTotals = await executeQuery(
      `
      SELECT v.roomID as roomID, r.roomName as roomName, COUNT(*) as visits
      FROM visitor_logs v
      LEFT JOIN room r ON v.roomID = r.roomID
      WHERE v.checkInTime IS NOT NULL
        AND date(v.checkInTime) >= date('now', ?)
      GROUP BY v.roomID
      ORDER BY visits DESC
    `,
      [since],
    );

    return { dailyRoomCounts, roomTotals };
  }
}

module.exports = AnalyticsDAO;
