const { executeQuery, executeStatement } = require('../db');

class VisitorDAO {
  static async getAllVisitors(filters = {}) {
    let sql = `
      SELECT v.*, w.roomName as currentRoomName
      FROM visitors v
      LEFT JOIN room w ON v.currentRoomID = w.roomID
      WHERE 1=1
    `;
    const params = [];

    if (filters.currentRoomID) {
      sql += ' AND v.currentRoomID = ?';
      params.push(filters.currentRoomID);
    }

    sql += ' ORDER BY v.name';
    return await executeQuery(sql, params);
  }

  static async getVisitorById(visitorID) {
    const results = await executeQuery(`
      SELECT v.*, w.roomName as currentRoomName
      FROM visitors v
      LEFT JOIN room w ON v.currentRoomID = w.roomID
      WHERE v.visitorID = ?
    `, [visitorID]);
    return results.length > 0 ? results[0] : null;
  }

  static async createVisitor(visitorData) {
    const {
      name,
      currentRoomID = null,
      medicalCondition = null,
    } = visitorData;

    const result = await executeStatement(`
      INSERT INTO visitors (
        name, currentRoomID, medicalCondition
      )
      VALUES (?, ?, ?)
    `, [
      name, currentRoomID, medicalCondition
    ]);

    return await this.getVisitorById(result.lastInsertRowId);
  }

  static async updateVisitor(visitorID, updates) {
    const allowedFields = [
      'name', 'currentRoomID',
      'medicalCondition'
    ];
    
    const fields = Object.keys(updates).filter(key => allowedFields.includes(key));
    
    if (fields.length === 0) {
      throw new Error('No valid fields to update');
    }

    const setClause = fields.map(field => `${field} = ?`).join(', ');
    const values = fields.map(field => updates[field]);
    
    await executeStatement(`
      UPDATE visitors 
      SET ${setClause}
      WHERE visitorID = ?
    `, [...values, visitorID]);
    return await this.getVisitorById(visitorID);
  }

  static async deleteVisitor(visitorID) {
    await executeStatement(`DELETE FROM visitors WHERE visitorID = ?`, [visitorID]);
    return true;
  }

  static async getActiveVisitors() {
    return await executeQuery(`
      SELECT * FROM visitors WHERE currentRoomID IS NOT NULL ORDER BY name
    `);
  }

  static async checkIn(visitorData) {
    const visitor = await this.createVisitor({ ...visitorData });
    return visitor;
  }

  static async checkOut(visitorID) {
    return await this.updateVisitor(visitorID, { currentRoomID: null });
  }

  static async getVisitorHistory(visitorID) {
    const results = await executeQuery(`
      SELECT 
        a.appointmentID,
        a.appointmentDate,
        a.appointmentType,
        a.status,
        s.name as staffName,
        s.staffType,
        w.roomName
      FROM appointments a
      JOIN staff s ON a.staffID = s.staffID
      LEFT JOIN room w ON a.roomID = w.roomID
      WHERE a.visitorID = ?
      ORDER BY a.appointmentDate DESC
    `, [visitorID]);
    
    return results;
  }

  static async getVisitorStatistics() {
    const results = await executeQuery(`
      SELECT 
        COUNT(*) as totalVisitors,
        SUM(CASE WHEN currentRoomID IS NOT NULL THEN 1 ELSE 0 END) as activeVisitors,
        COUNT(*) - SUM(CASE WHEN currentRoomID IS NOT NULL THEN 1 ELSE 0 END) as inactiveVisitors,
        COUNT(DISTINCT currentRoomID) as occupiedRooms
      FROM visitors
    `);
    
    return results.length > 0 ? results[0] : null;
  }

  static async getVisitorByName(name) {
    const results = await executeQuery(`SELECT * FROM visitors WHERE name = ?`, [name]);
    return results.length > 0 ? results[0] : null;
  }

  static async logCheckIn({
    externalId,
    visitorID,
    name,
    phoneNumber,
    roomID,
    checkInTime,
  }) {
    // externalID is basically a temporary ID used to check if the visitor is already checked in
    const sql = `
      INSERT INTO visitor_logs (
        externalId, visitorID, name, visitorName, phoneNumber, roomID, checkInTime
      )
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    const timestamp = checkInTime ? new Date(checkInTime).toISOString() : new Date().toISOString();
    await executeStatement(sql, [
      externalId || null,
      visitorID || null,
      name,
      name,
      phoneNumber || null,
      roomID || null,
      timestamp,
    ]);
  }

  static async clearVisitorLogs() {
    const sql = `DELETE FROM visitor_logs`;
    await executeStatement(sql, []);
  }
  static async logCheckOut({ externalId, visitorID }) {
    const whereClause = externalId ? 'externalId = ?' : 'visitorID = ?';
    const idValue = externalId ? externalId : visitorID;

    const openLog = await executeQuery(
      `SELECT logID, checkInTime FROM visitor_logs WHERE ${whereClause} AND checkOutTime IS NULL ORDER BY logID DESC LIMIT 1`,
      [idValue]
    );

    if (!openLog || !openLog.length) {
      return true;
    }

    const logID = openLog[0].logID;
    const checkInTime = openLog[0].checkInTime ? new Date(openLog[0].checkInTime).getTime() : null;
    const checkOutTime = new Date();
    const duration = checkInTime ? Math.max(0, Math.round((checkOutTime.getTime() - checkInTime) / 1000)) : null;

    const sql = `
      UPDATE visitor_logs
      SET checkOutTime = ?, duration = ?
      WHERE logID = ?
    `;
    await executeStatement(sql, [checkOutTime.toISOString(), duration, logID]);
    return true;
  }

  static async insertVisitorLog({
    externalId,
    visitorID,
    name,
    phoneNumber,
    roomID,
    checkInTime,
    checkOutTime,
    duration,
  }) {
    const sql = `
      INSERT INTO visitor_logs (
        externalId,
        visitorID,
        name,
        visitorName,
        phoneNumber,
        roomID,
        checkInTime,
        checkOutTime,
        duration
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    await executeStatement(sql, [
      externalId || null,
      visitorID || null,
      name,
      name,
      phoneNumber || null,
      roomID || null,
      checkInTime ? new Date(checkInTime).toISOString() : null,
      checkOutTime ? new Date(checkOutTime).toISOString() : null,
      Number.isFinite(duration) ? duration : null,
    ]);
  }
}

module.exports = VisitorDAO;
