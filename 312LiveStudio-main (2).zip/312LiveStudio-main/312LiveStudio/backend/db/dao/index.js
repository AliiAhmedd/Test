// Exports all daos so that othe files can use and import them 
const MapDAO = require('./MapDAO');
const WardDAO = require('./WardDAO');
const StaffDAO = require('./StaffDAO');
const VisitorDAO = require('./VisitorDAO');
const WaitingListDAO = require('./WaitingListDAO');
const LocationDAO = require('./LocationDAO');
const AnalyticsDAO = require('./AnalyticsDAO');
const SettingsDAO = require('./SettingsDAO');

module.exports = {
  MapDAO,
  WardDAO,
  StaffDAO,
  VisitorDAO,
  WaitingListDAO,
  LocationDAO,
  AnalyticsDAO,
  SettingsDAO
};
