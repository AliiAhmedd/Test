const { executeQuery, executeStatement } = require('../db');

class StaffDAO {
  static async getAllStaff(filters = {}) { // this function retrieves all staff members with optional filters such as staffType, isAvailable, and currentRoomID
    let sql = `
      SELECT s.*,
        w.roomName as currentLocation
      FROM staff s
      LEFT JOIN room w ON s.currentRoomID = w.roomID
      WHERE 1=1
    `;
    const params = [];

    if (filters.staffType) {
      sql += ' AND s.staffType = ?'; // this AND goes next to the 1=1 in the WHERE clause
      params.push(filters.staffType);
    }

    if (filters.isAvailable !== undefined) {
      sql += ' AND s.isAvailable = ?'; // this AND goes next to the 1=1 in the WHERE clause
      params.push(filters.isAvailable ? 1 : 0);
    }

    if (filters.currentRoomID) {
      sql += ' AND s.currentRoomID = ?'; // this AND goes next to the 1=1 in the WHERE clause
      params.push(filters.currentRoomID);
    }

    sql += ' ORDER BY s.staffType, s.name'; // this ORDER BY beneath the WHERE clause
    return await executeQuery(sql, params); // waits for the query to execute, then returns the results
  }

  static async getStaffById(staffID) { // gets a singular staff based on their ID, unlike the function above which retrieves all staff based on a filter
    const results = await executeQuery(`
      SELECT s.*,
        w.roomName as currentLocation,
        m.mapID,
        m.mapName
      FROM staff s
      LEFT JOIN room w ON s.currentRoomID = w.roomID
      LEFT JOIN maps m ON w.mapID = m.mapID
      WHERE s.staffID = ?
    `, [staffID]);
    return results.length > 0 ? results[0] : null;
  }

  static async createStaff(staffData) { // creates a new staff member in the db
    const {
      email = null,
      name,
      staffType,
      currentRoomID = null,
      isAvailable = 1,
      branchName = null
    } = staffData;

    if (!['nurse', 'doctor', 'admin'].includes(staffType)) {
      throw new Error('Invalid staff type. Must be nurse, doctor, or admin');
    }

    const result = await executeStatement(`
      INSERT INTO staff (
        email, name, staffType, currentRoomID, isAvailable, branchName
      )
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      email, name, staffType, currentRoomID, isAvailable, branchName
    ]);

    return await this.getStaffById(result.lastInsertRowId);
  }

  static async updateStaff(staffID, updates) {
    const allowedFields = [
      'email', 'name', 'staffType', 'currentRoomID', 'isAvailable', 'branchName'
    ];
    
    const fields = Object.keys(updates).filter(key => allowedFields.includes(key));
    
    if (fields.length === 0) {
      throw new Error('No valid fields to update');
    }

    const setClause = fields.map(field => `${field} = ?`).join(', '); 
    const values = fields.map(field => updates[field]);
    
    await executeStatement(`
      UPDATE staff 
      SET ${setClause}
      WHERE staffID = ?
    `, [...values, staffID]);
    return await this.getStaffById(staffID);
  }

  static async deleteStaff(staffID) {
    await executeStatement(`DELETE FROM staff WHERE staffID = ?`, [staffID]);
    return true;
  }

  static async getStaffByEmail(email) {
    const results = await executeQuery(`
      SELECT * FROM staff
      WHERE email = ?
    `, [email]);
    return results.length > 0 ? results[0] : null;
  }

  static async getAvailableStaff(staffType = null) {
    let sql = 'SELECT * FROM staff WHERE isAvailable = 1';
    const params = [];

    if (staffType) {
      sql += ' AND staffType = ?';
      params.push(staffType);
    }

    sql += ' ORDER BY name';
    return await executeQuery(sql, params);
  }

  static async assignToRoom(staffID, roomID) {
    return await this.updateStaff(staffID, { 
      currentRoomID: roomID,
      isAvailable: 0
    });
  }

  static async releaseFromRoom(staffID) {
    return await this.updateStaff(staffID, { 
      currentRoomID: null,
      isAvailable: 1
    });
  }

  static async getStaffByRoom(roomID) {
    return await executeQuery(`
      SELECT * FROM staff 
      WHERE currentRoomID = ?
      ORDER BY staffType, name
    `, [roomID]);
  }

  static async assignBranchByEmail(email, branchName) {
    const staff = await this.getStaffByEmail(email);
    if (!staff) {
      return null;
    }
    return await this.updateStaff(staff.staffID, { branchName });
  }

  static async getStaffStatistics() {
    return await executeQuery(`
      SELECT 
        staffType,
        COUNT(*) as total, // total staff of this type
        SUM(isAvailable) as available, // available staff of this type and the next line is busy staff of this type
        COUNT(*) - SUM(isAvailable) as busy
      FROM staff
      GROUP BY staffType
    `);
  }

  static async getStaffWorkload(staffID) { // retrieves workload statistics for a specific staff member
    const results = await executeQuery(`
      SELECT 
        s.staffID,
        s.name,
        s.staffType,
        COUNT(DISTINCT v.visitorID) as assignedVisitors,
        COUNT(DISTINCT a.appointmentID) as scheduledAppointments,
        COUNT(DISTINCT w.waitingID) as pendingRequests
      FROM staff s
      LEFT JOIN visitors v ON (s.staffID = v.assignedNurseID OR s.staffID = v.assignedDoctorID) AND v.isActive = 1
      LEFT JOIN appointments a ON s.staffID = a.staffID AND a.status IN ('scheduled', 'in-progress')
      LEFT JOIN waiting_list w ON s.staffID = w.requestedStaffID AND w.status = 'waiting'
      WHERE s.staffID = ?
      GROUP BY s.staffID
    `, [staffID]);
    
    return results.length > 0 ? results[0] : null;
  }
}

module.exports = StaffDAO;
