const { executeQuery, executeStatement } = require('../db');

class WardDAO {
  static async getAllWards(filters = {}) {
    let sql = 'SELECT * FROM room WHERE 1=1';
    const params = [];

    if (filters.mapID) {
      sql += ' AND mapID = ?';
      params.push(filters.mapID);
    }

    sql += ' ORDER BY roomName';
    return await executeQuery(sql, params);
  }

  static async getWardById(roomID) {
    const results = await executeQuery('SELECT * FROM room WHERE roomID = ?', [roomID]);
    return results.length > 0 ? results[0] : null;
  }


 static async createWard(wardData) {
    const {
      roomName,
      maxOccupancy,
      mapID,
      position,
      currentOccupancy = 0,
      numberOfNurses = 0,
      //currentOccupancy = 0,
      //numberOfNurses = 0,
      //nurseNames = null,
      //gridRow = null,
      //gridColumn = null
    } = wardData;

    const sql =`
      INSERT INTO room (
        roomName, maxOccupancy,
        mapID, position,currentOccupancy,numberOfNurses
      )
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    console.log('Creating ward with data:', wardData);
    const result = await executeStatement(sql, [
      roomName, maxOccupancy, mapID, position, currentOccupancy, numberOfNurses
    ]);

    return await this.getWardById(result.lastInsertRowId);
  }
    static async logRoomTemperature(roomID, temperature) {
    const sql = `
      INSERT INTO temperature_logs (roomID, temperature, createdAt)
      VALUES (?, ?, ?)
    `;
    await executeStatement(sql, [roomID, temperature, new Date().toISOString()]);
  }

    static async getLatestTemperature(roomID) {
      const results = await executeQuery(
        `SELECT temperature FROM temperature_logs WHERE roomID = ? ORDER BY logID DESC LIMIT 1`,
        [roomID]
      );
      return results.length > 0 ? results[0].temperature : null;
    }
  static async updateWard(roomID, updates) {
    const allowedFields = [
      'roomName', 'maxOccupancy', 'mapID', 'position','currentOccupancy','numberOfNurses'
    ];
    
    const fields = Object.keys(updates).filter(key => allowedFields.includes(key));
    
    if (fields.length === 0) {
      throw new Error('No valid fields to update');
    }

    const setClause = fields.map(field => `${field} = ?`).join(', ');
    const values = fields.map(field => updates[field]);
    
    await executeStatement(`
      UPDATE room 
      SET ${setClause}
      WHERE roomID = ?
    `, [...values, roomID]);
    return await this.getWardById(roomID);
  }
  static async debugGetAllWards() {
    return await executeQuery(`
      SELECT * FROM room 
      ORDER BY roomID ASC
    `);
  }
  static async deleteWard(roomID) {
    await executeStatement(`DELETE FROM room WHERE roomID = ?`, [roomID]);
    return true;
  }

  static async getWardsByLocation(gridRow, gridColumn) {
    return await executeQuery(`
      SELECT * FROM room 
      WHERE gridRow = ? AND gridColumn = ?
    `, [gridRow, gridColumn]);
  }

  static async getAvailableWards(mapID = null) { // THIS WILL BE USED WHEN ASSIGNING A NEW VISITOR TO A WARD FROM THE WAITING LIST
    let sql = `
      SELECT * FROM room 
      WHERE currentOccupancy < maxOccupancy
    `;
    const params = [];

    if (mapID) {
      sql += ' AND mapID = ?';
      params.push(mapID);
    }

    sql += ' ORDER BY roomName';
    return await executeQuery(sql, params);
  }

  static async getWardOccupancy(roomID) { // gets ward occupancy by joining with visitors table on the current roomID field
    const results = await executeQuery(`
      SELECT 
        w.roomID,
        w.roomName,
        w.maxOccupancy,
        w.currentOccupancy,
        COUNT(v.visitorID) as actualVisitorCount
      FROM room w
      LEFT JOIN visitors v ON w.roomID = v.currentRoomID AND v.isActive = 1
      WHERE w.roomID = ?
      GROUP BY w.roomID
    `, [roomID]);
    
    return results.length > 0 ? results[0] : null;
  }

  static async updateOccupancy(roomID, increment = true) {
    const ward = await this.getWardById(roomID);
    if (!ward) {
      return { updated: false, reason: "WARD_NOT_FOUND" };
      //throw new Error('Ward not found');
    }

    const newOccupancy = increment 
      ? ward.currentOccupancy + 1 
      : Math.max(0, ward.currentOccupancy - 1);

    if (newOccupancy > ward.maxOccupancy) {
      return { updated: false, reason: "MAX_OCCUPANCY_REACHED" };
    }

    //return await this.updateWard(roomID, { currentOccupancy: newOccupancy });
    const updatedWard = await this.updateWard(roomID, { currentOccupancy: newOccupancy });
    return { updated: true, ward: updatedWard };
  }

  static async getWardStatistics() {
    return await executeQuery(`
      SELECT 
        COUNT(*) as totalWards,
        SUM(maxOccupancy) as totalCapacity,
        SUM(currentOccupancy) as totalOccupied,
        AVG(CAST(currentOccupancy AS FLOAT) / maxOccupancy * 100) as avgOccupancyRate
      FROM room
    `);
  }

  static async getFullWards() {
    return await executeQuery(`
      SELECT * FROM room 
      WHERE currentOccupancy >= maxOccupancy
      ORDER BY roomName
    `);
  }

  static async getEmptyWards() {
    return await executeQuery(`
      SELECT * FROM room 
      WHERE currentOccupancy = 0
      ORDER BY roomName
    `);
  }
}

module.exports = WardDAO;
