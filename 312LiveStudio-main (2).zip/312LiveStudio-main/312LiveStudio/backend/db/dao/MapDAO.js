const { executeQuery, executeStatement } = require('../db');

class MapDAO {
  static async getAllMaps() {
    return await executeQuery(`
      SELECT * FROM maps 
      ORDER BY mapID DESC
    `);
  }
  static async DebugGetAllMaps() {
    return await executeQuery(`
      SELECT * FROM maps 
      ORDER BY mapID ASC
    `);
  }
  static async getMapById(mapID) {
    const results = await executeQuery(`
      SELECT * FROM maps 
      WHERE mapID = ?
    `, [mapID]);
    return results.length > 0 ? results[0] : null;
  }

  static async createMap({ mapName, rows, columns, branchName }) {
    const result = await executeStatement(`
      INSERT INTO maps (mapName, rows, columns, branchName)
      VALUES (?, ?, ?, ?)
    `, [mapName, rows, columns, branchName]);
    return await this.getMapById(result.lastInsertRowId); // creating a new map requires fetching it using its ID
  }
  
  static async updateMap(mapID, updates) {
    const allowedFields = ['mapName', 'rows', 'columns'];
    const fields = Object.keys(updates).filter(key => allowedFields.includes(key));
    
    if (fields.length === 0) {
      throw new Error('No valid fields to update');
    }

    const setClause = fields.map(field => `${field} = ?`).join(', '); // setClause contains the fields to be updated
    const values = fields.map(field => updates[field]); // values contains the new values for those fields
    
    const sql = `UPDATE maps SET ${setClause} WHERE mapID = ?`; 
    
    await executeStatement(sql, [...values, mapID]);
    return await this.getMapById(mapID);
  }

  static async deleteMap(mapID) {
    await executeStatement(`DELETE FROM maps WHERE mapID = ?`, [mapID]);
    return true;
  }

  static async getWardsByMap(mapID) {
    return await executeQuery(`
      SELECT * FROM room 
      WHERE mapID = ?
    `, [mapID]);
  }

  static async getLatestMapByBranch(branchName) {
    const results = await executeQuery(`
      SELECT * FROM maps
      WHERE branchName = ?
      ORDER BY mapID DESC
      LIMIT 1
    `, [branchName]);
    return results.length > 0 ? results[0] : null;
  }

  static async getMapWithLayout(mapID) {
    const map = await this.getMapById(mapID);
    if (!map) return null;

    const wards = await this.getWardsByMap(mapID);
    
    const grid = Array(map.rows).fill(null).map(() => Array(map.columns).fill(null)); // creates a 2D grid
    
    wards.forEach(ward => { // places wards on the grid
      if (ward.gridRow !== null && ward.gridColumn !== null) {
        if (ward.gridRow < map.rows && ward.gridColumn < map.columns) {
          grid[ward.gridRow][ward.gridColumn] = ward;
        }
      }
    });

    return {
      ...map,
      grid,
      wards
    };
  }

  static async getMapStatistics(mapID) {
    const results = await executeQuery(`
      SELECT 
        COUNT(w.roomID) as totalRooms,
        SUM(w.maxOccupancy) as totalCapacity,
        SUM(w.currentOccupancy) as currentOccupancy,
        AVG(w.roomTemp) as averageRoomTemp
      FROM room w
      WHERE w.mapID = ?
    `, [mapID]);
    
    return results.length > 0 ? results[0] : null; // returns statistics or null if no data available
  }
}

module.exports = MapDAO;
