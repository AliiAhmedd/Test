export type UserRole = 'admin' | 'reception' | 'monitor';

export interface User {
  id: string;
  email: string;
  password: string;
  role: UserRole;
  name?: string;
}

export interface Visitor {
  id: string;
  name: string;
  phoneNumber: string;
  roomId: string;
  checkInTime: Date;
  checkOutTime?: Date;
}

export interface VisitorLog {
  id: string;
  visitorName: string;
  phoneNumber: string;
  roomId: string;
  checkInTime: Date;
  checkOutTime: Date | null;
  duration?: number; // in minutes
}
