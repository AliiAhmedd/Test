import { useBranch } from "@/contexts/BranchContext";
import { Visitor, VisitorLog } from "@/types/user";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import React, {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useState,
} from "react";

interface VisitorContextType {
  activeVisitors: Visitor[];
  visitorLogs: VisitorLog[];
  checkIn: (name: string, phoneNumber: string, roomId: string) => Promise<void>;
  checkOut: (visitorId: string) => Promise<void>;
  getActiveVisitors: () => Visitor[];
  getVisitorLogs: () => VisitorLog[];
  getVisitorsByRoom: (roomId: string) => Visitor[];
  clearLogs: ()=> Promise<void>;
}

const VisitorContext = createContext<VisitorContextType | undefined>(undefined);

const ACTIVE_VISITORS_KEY_PREFIX = "@active_visitors";
const VISITOR_LOGS_KEY_PREFIX = "@visitor_logs";

export function VisitorProvider({ children }: { children: ReactNode }) {
  const [activeVisitors, setActiveVisitors] = useState<Visitor[]>([]);
  const [visitorLogs, setVisitorLogs] = useState<VisitorLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { activeBranch } = useBranch();

  useEffect(() => {
    loadData();
  }, [activeBranch]);

  const getActiveVisitorsKey = () =>
    `${ACTIVE_VISITORS_KEY_PREFIX}_${activeBranch}`;
  const getVisitorLogsKey = () => `${VISITOR_LOGS_KEY_PREFIX}_${activeBranch}`;
  //const SERVER_URL = 'http://127.0.0.1:3000';
  const SERVER_URL = "http://172.20.10.2:3000";


  const loadData = async () => {
    try {
      // Fetch from backend database
      const [activeResponse, logsResponse] = await Promise.all([
        axios
          .get(`${SERVER_URL}/api/visitors/active`)
          .catch(() => ({ data: [] })),
        axios
          .get(`${SERVER_URL}/api/visitors/logs`)
          .catch(() => ({ data: [] })),
      ]);

      const activeData = activeResponse.data.map((v: any) => ({
        id: v.visitorID?.toString() || v.id,
        name: v.name,
        phoneNumber: v.phoneNumber || "",
        roomId: v.currentRoomID?.toString() || v.roomId,
        checkInTime: new Date(),
      }));

      const logsData = logsResponse.data.map((log: any) => ({
        id: log.logID?.toString() || log.id,
        visitorName: log.visitorName,
        phoneNumber: log.phoneNumber || "",
        roomId: log.roomID?.toString() || log.roomId,
        checkInTime: new Date(log.checkInTime),
        checkOutTime: log.checkOutTime ? new Date(log.checkOutTime) : null,
        duration: log.duration || 0,
      }));

      setActiveVisitors(activeData);
      setVisitorLogs(logsData);
    } catch (error) {
      console.error("Error loading visitor data:", error);
      setActiveVisitors([]);
      setVisitorLogs([]);
    } finally {
      setIsLoading(false);
    }
  };

  const saveActiveVisitors = async (visitors: Visitor[]) => {
    try {
      await AsyncStorage.setItem(
        getActiveVisitorsKey(),
        JSON.stringify(visitors),
      );
    } catch (error) {
      console.error("Error saving active visitors:", error);
    }
  };

  const saveVisitorLogs = async (logs: VisitorLog[]) => {
    try {
      await AsyncStorage.setItem(getVisitorLogsKey(), JSON.stringify(logs));
    } catch (error) {
      console.error("Error saving visitor logs:", error);
    }
  };

  const checkIn = async (name: string, phoneNumber: string, roomId: string) => {
    const externalId = `visitor-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    console.log('Checking in visitor:', { externalId, name, phoneNumber, roomId });
    try {
      console.log("Sending check-in to server");
      await axios.post(`${SERVER_URL}/api/visitors/check-in`, {
        id: externalId,
        name,
        phoneNumber,
        roomId,
      });
      // Refresh data from backend
      await loadData();
    } catch (err) {
      console.error("Backend check-in failed:", err);
      throw err;
    }
  };
const clearLogs = async () => {
  try {
    console.log("Clearing logs from server");
    await axios.post(`${SERVER_URL}/api/visitors/clear-logs`);
    saveActiveVisitors([]);
    saveVisitorLogs([]);
  } catch (error) {
    console.error("Error clearing logs: ",error);
  }
}
  const checkOut = async (visitorId: string) => {
    const visitor = activeVisitors.find((v) => v.id === visitorId);
    if (!visitor) return;

    try {
      await axios.post(`${SERVER_URL}/api/visitors/check-out`, {
        id: visitor.id,
        name: visitor.name,
      });
      // Refresh data from backend
      await loadData();
    } catch (err) {
      console.error("Backend check-out failed:", err);
      throw err;
    }
  };

  const getActiveVisitors = () => {
    return activeVisitors;
  };

  const getVisitorLogs = () => {
    return [...visitorLogs].sort(
      (a, b) => b.checkInTime.getTime() - a.checkInTime.getTime(),
    );
  };

  const getVisitorsByRoom = (roomId: string) => {
    return activeVisitors.filter((v) => v.roomId === roomId);
  };

  return (
    <VisitorContext.Provider
      value={{
        activeVisitors,
        visitorLogs,
        clearLogs,
        checkIn,
        checkOut,
        getActiveVisitors,
        getVisitorLogs,
        getVisitorsByRoom,
      }}
    >
      {children}
    </VisitorContext.Provider>
  );
}

export function useVisitors() {
  const context = useContext(VisitorContext);
  if (context === undefined) {
    throw new Error("useVisitors must be used within a VisitorProvider");
  }
  return context;
}
