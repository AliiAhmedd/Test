import React, { createContext, ReactNode, useContext, useMemo, useState } from 'react';

export type EmergencyCategory = 'core' | 'medical' | 'security';
export type EmergencyScope = 'branch' | 'global';

export interface EmergencyEvent {
  id: string;
  code: string;
  meaning: string;
  description: string;
  category: EmergencyCategory;
  scope: EmergencyScope;
  branchName?: string;
  roomId?: string;
  timestamp: number;
}

interface EmergencyContextType {
  events: EmergencyEvent[];
  addEvent: (event: Omit<EmergencyEvent, 'id' | 'timestamp'>) => void;
  getBranchEvents: (branchName: string) => EmergencyEvent[];
  getGlobalEvents: () => EmergencyEvent[];
}

const EmergencyContext = createContext<EmergencyContextType | undefined>(undefined);

export const CORE_CODES = [
  { code: 'Code Blue', meaning: 'Medical Emergency', description: 'Cardiac or respiratory arrest' },
  { code: 'Code Red', meaning: 'Fire', description: 'Fire or smoke detected' },
  { code: 'Code Green', meaning: 'Evacuation', description: 'Partial or full evacuation' },
  { code: 'Code Black', meaning: 'Bomb Threat', description: 'Bomb threat or suspicious package' },
  { code: 'Code Yellow', meaning: 'Disaster / Mass Casualty', description: 'External or internal disaster' },
  { code: 'Code Orange', meaning: 'Hazardous Materials', description: 'Chemical spill or exposure' },
  { code: 'Code Pink', meaning: 'Infant Abduction', description: 'Missing or abducted infant' },
  { code: 'Code Purple', meaning: 'Child Abduction', description: 'Missing or abducted child' },
  { code: 'Code Gray / Grey', meaning: 'Combative Person', description: 'Aggressive or violent individual' },
  { code: 'Code White', meaning: 'Violence / Threat', description: 'Physical threat against staff' },
];

export const MEDICAL_CODES = [
  { code: 'Code Stroke', meaning: 'Stroke Alert', description: 'Patient showing stroke symptoms' },
  { code: 'Code STEMI', meaning: 'Heart Attack', description: 'Acute myocardial infarction' },
  { code: 'Code Sepsis', meaning: 'Sepsis Alert', description: 'Suspected sepsis case' },
  { code: 'Code Rapid Response', meaning: 'Patient Deterioration', description: 'Patient at risk but not in arrest' },
  { code: 'Code Brown', meaning: 'Severe Weather / Utility Failure', description: 'Weather emergency or sewage issue' },
];

export const SECURITY_CODES = [
  { code: 'Code Silver', meaning: 'Weapon / Active Threat', description: 'Person with a weapon' },
  { code: 'Code Gold', meaning: 'Hostage Situation', description: 'Hostage or terrorism-related event' },
  { code: 'Code Amber', meaning: 'Missing Patient', description: 'Missing adult patient' },
  { code: 'Code Clear / Code All Clear', meaning: 'Situation Resolved', description: 'Emergency is over' },
  { code: 'Code Lockdown', meaning: 'Facility Lockdown', description: 'Controlled access due to threat' },
];

export function EmergencyProvider({ children }: { children: ReactNode }) {
  const [events, setEvents] = useState<EmergencyEvent[]>([]);

  const addEvent = (event: Omit<EmergencyEvent, 'id' | 'timestamp'>) => {
    const newEvent: EmergencyEvent = {
      ...event,
      id: `emergency-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      timestamp: Date.now(),
    };
    setEvents((prev) => [newEvent, ...prev]);
  };

  const getBranchEvents = (branchName: string) =>
    events.filter((event) => event.scope === 'branch' && event.branchName === branchName);

  const getGlobalEvents = () => events.filter((event) => event.scope === 'global');

  const value = useMemo(
    () => ({
      events,
      addEvent,
      getBranchEvents,
      getGlobalEvents,
    }),
    [events]
  );

  return <EmergencyContext.Provider value={value}>{children}</EmergencyContext.Provider>;
}

export function useEmergency() {
  const context = useContext(EmergencyContext);
  if (context === undefined) {
    throw new Error('useEmergency must be used within an EmergencyProvider');
  }
  return context;
}
