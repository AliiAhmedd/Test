import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import React, {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useState,
} from "react";
import { useBranch } from "./BranchContext";

//const SERVER_URL = "http://192.168.42.16:3000";
//const SERVER_URL = "http://127.0.0.1:3000";
const SERVER_URL = "http://172.20.10.2:3000";
export interface Room {
  id: string;
  name: string;
  maxCapacity: number;
  cells: number[];
}

type MapLayout = {
  rows: number;
  columns: number;
  rooms: Room[]; // arr of rooms
};

interface RoomContextType {
  rooms: Room[];
  mapDetails: { rows: number; columns: number };
  addRoom: (
    name: string,
    maxCapacity: number,
    cells: number[],
  ) => Promise<void>;
  removeRoom: (roomId: string) => Promise<void>;
  updateRoomCapacity: (roomId: string, maxCapacity: number) => Promise<void>;
  getRooms: () => Room[];
  loadRooms: (mapID?: number) => Promise<void>;
  saveMap: (layout: MapLayout) => Promise<void>;
  getRoomById: (roomId: number) => Room | undefined;
}

const RoomContext = createContext<RoomContextType | undefined>(undefined);

const ROOMS_KEY_PREFIX = "@rooms";

export function RoomProvider({ children }: { children: ReactNode }) {
  //fetch('http://127.0.0.1:7242/ingest/3f906ee8-3102-4eb1-a279-d22560295310',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'contexts/RoomContext.tsx:29',message:'RoomProvider entry',data:{childrenType:typeof children},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H4'})}).catch(()=>{});

  const [rooms, setRooms] = useState<Room[]>([]);
  const [mapDetails, setMapDetails] = useState<{
    rows: number;
    columns: number;
  }>({ rows: 0, columns: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const { activeBranch } = useBranch();

  //fetch('http://127.0.0.1:7242/ingest/3f906ee8-3102-4eb1-a279-d22560295310',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'contexts/RoomContext.tsx:39',message:'RoomProvider render',data:{activeBranch,roomsCount:rooms.length,mapRows:mapDetails.rows,mapCols:mapDetails.columns},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H4'})}).catch(()=>{});

  useEffect(() => {
    loadRooms();
  }, [activeBranch]);

  const getRoomsKey = () => `${ROOMS_KEY_PREFIX}_${activeBranch}`;

  const loadRooms = async (mapID?: number) => {
    try {
      await axios
        .post(SERVER_URL + "/api/loadMapLayout", {
          mapID: mapID || 0,
          branchName: activeBranch,
        })
        .then((response) => {
          console.log("Loaded map layout in RoomContext");
          const wards = response.data.wards || [];
          const mappedRooms = wards.map((ward: any) => {
            return {
              id: String(ward.id),
              name: ward.name,
              maxCapacity: ward.capacity.max,
              currentOccupancy: ward.currentOccupancy || 0,
              cells: ward.position ?? 0,
            };
          });
          console.log("Mapped Rooms on Load: ", mappedRooms);
          setRooms(mappedRooms || []);
          //setRooms(response.data.wards || []);
          setMapDetails({
            rows: response.data.rows || 0,
            columns: response.data.columns || 0,
          });
        })
        .catch((error) => {
          console.error("Error loading map layout:", error);
        });
      /*       const savedRooms = await AsyncStorage.getItem(getRoomsKey());
      if (savedRooms) {
        setRooms(JSON.parse(savedRooms));
      } else {
        // First time - save default rooms
        await AsyncStorage.setItem(getRoomsKey(), JSON.stringify(DEFAULT_ROOMS));
      } */
    } catch (error) {
      console.error("Error loading rooms:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveRooms = async (updatedRooms: Room[]) => {
    // add all rooms to DB
    try {
      console.log("Saving rooms:", updatedRooms);
      await AsyncStorage.setItem(getRoomsKey(), JSON.stringify(updatedRooms));
      setRooms(updatedRooms);
    } catch (error) {
      console.error("Error saving rooms:", error);
    }
  };

  const saveMap = async (layout: MapLayout) => {
    try {
      await AsyncStorage.setItem(getRoomsKey(), JSON.stringify(layout.rooms));
      setRooms(layout.rooms);
      console.log("Saving map layout to server:", layout);
      setMapDetails({ rows: layout.rows, columns: layout.columns });
      await axios.post(SERVER_URL + "/api/saveMapLayout", {
        rows: layout.rows,
        columns: layout.columns,
        mapName: "Default Map",
        branchName: activeBranch,
        rooms: layout.rooms,
      });
    } catch (error) {
      console.log("Server URL = ",SERVER_URL);
      console.error("Error saving map", error);
    }
  };

  const addRoom = async (
    name: string,
    maxCapacity: number,
    cells: number[],
  ) => {
    const newRoom: Room = {
      id: 41,
      name,
      maxCapacity,
      cells: cells,
    };
    const updated = [...rooms, newRoom];
    await saveRooms(updated);
  };

  const removeRoom = async (roomId: string) => {
    const updated = rooms.filter((r) => r.id !== roomId);
    console.log("Removing room:", roomId, "Updated rooms:", updated);
    //remove from DB
    await axios.post(SERVER_URL + "/api/removeRoom", { roomId });
    console.log("Removed from DB");
    await saveRooms(updated);
  };

  const updateRoomCapacity = async (roomId: string, maxCapacity: number) => {
    const updated = rooms.map((r) =>
      r.id === roomId ? { ...r, maxCapacity } : r,
    );
    await saveRooms(updated);
  };

  const getRooms = () => {
    return rooms;
  };

  const getRoomById = (roomId: number) => {
    return rooms.find((room) => room.id === roomId);
  };

  return (
    <RoomContext.Provider
      value={{
        rooms,
        mapDetails,
        addRoom,
        removeRoom,
        updateRoomCapacity,
        getRooms,
        getRoomById,
        saveMap,
        loadRooms,
      }}
    >
      {children}
    </RoomContext.Provider>
  );
}

export function useRooms() {
  const context = useContext(RoomContext);
  if (context === undefined) {
    throw new Error("useRooms must be used within a RoomProvider");
  }
  return context;
}

export default RoomProvider;
