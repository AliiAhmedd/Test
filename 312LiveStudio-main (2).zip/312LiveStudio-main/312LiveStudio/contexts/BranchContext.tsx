import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, ReactNode, useContext, useEffect, useState } from 'react';

interface BranchContextType {
  branches: string[];
  activeBranch: string;
  isLoading: boolean;
  addBranch: (name: string) => Promise<{ success: boolean; error?: string }>;
  setActiveBranch: (name: string) => Promise<void>;
}

const BranchContext = createContext<BranchContextType | undefined>(undefined);

const BRANCHES_KEY = '@branches';
const ACTIVE_BRANCH_KEY = '@active_branch';
const DEFAULT_BRANCH = 'Main';

export function BranchProvider({ children }: { children: ReactNode }) {
  // #region agent log
  //fetch('http://127.0.0.1:7242/ingest/3f906ee8-3102-4eb1-a279-d22560295310',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'contexts/BranchContext.tsx:21',message:'BranchProvider entry',data:{childrenType:typeof children},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H2'})}).catch(()=>{});
  // #endregion agent log
  const [branches, setBranches] = useState<string[]>([]);
  const [activeBranch, setActiveBranchState] = useState(DEFAULT_BRANCH);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadBranches();
  }, []);

  const loadBranches = async () => {
    try {
      // #region agent log
      //fetch('http://127.0.0.1:7242/ingest/3f906ee8-3102-4eb1-a279-d22560295310',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'contexts/BranchContext.tsx:31',message:'loadBranches start',data:{},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H2'})}).catch(()=>{});
      // #endregion agent log
      console.log("Loading branches from storage");
      const savedBranches = await AsyncStorage.getItem(BRANCHES_KEY);
      const savedActive = await AsyncStorage.getItem(ACTIVE_BRANCH_KEY);

      const parsedBranches: string[] = savedBranches ? JSON.parse(savedBranches) : [DEFAULT_BRANCH];
      const uniqueBranches = Array.from(new Set(parsedBranches.map((b) => b.trim()).filter(Boolean)));

      if (uniqueBranches.length === 0) {
        uniqueBranches.push(DEFAULT_BRANCH);
      }

      const nextActiveBranch =
        savedActive && uniqueBranches.includes(savedActive) ? savedActive : uniqueBranches[0];
      setBranches(uniqueBranches);
      setActiveBranchState(nextActiveBranch);
      // #region agent log
      //fetch('http://127.0.0.1:7242/ingest/3f906ee8-3102-4eb1-a279-d22560295310',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'contexts/BranchContext.tsx:48',message:'loadBranches success',data:{branchesCount:uniqueBranches.length,activeBranch:nextActiveBranch},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H2'})}).catch(()=>{});
      // #endregion agent log
    } catch (error) {
      console.error('Error loading branches:', error);
      setBranches([DEFAULT_BRANCH]);
      setActiveBranchState(DEFAULT_BRANCH);
    } finally {
      setIsLoading(false);
    }
  };

  const persistBranches = async (nextBranches: string[], nextActive?: string) => {
    await AsyncStorage.setItem(BRANCHES_KEY, JSON.stringify(nextBranches));
    if (nextActive) {
      await AsyncStorage.setItem(ACTIVE_BRANCH_KEY, nextActive);
    }
  };

  const addBranch = async (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) {
      return { success: false, error: 'Branch name is required' };
    }
    if (branches.some((b) => b.toLowerCase() === trimmed.toLowerCase())) {
      return { success: false, error: 'Branch already exists' };
    }

    const nextBranches = [...branches, trimmed];
    setBranches(nextBranches);
    await persistBranches(nextBranches);
    return { success: true };
  };

  const setActiveBranch = async (name: string) => {
    if (!branches.includes(name)) {
      return;
    }
    setActiveBranchState(name);
    await AsyncStorage.setItem(ACTIVE_BRANCH_KEY, name);
  };

  // #region agent log
  //fetch('http://127.0.0.1:7242/ingest/3f906ee8-3102-4eb1-a279-d22560295310',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'contexts/BranchContext.tsx:86',message:'BranchProvider render',data:{branchesCount:branches.length,activeBranch},timestamp:Date.now(),sessionId:'debug-session',runId:'pre-fix',hypothesisId:'H2'})}).catch(()=>{});
  // #endregion agent log

  return (
    <BranchContext.Provider
      value={{
        branches,
        activeBranch,
        isLoading,
        addBranch,
        setActiveBranch,
      }}
    >
      {children}
    </BranchContext.Provider>
  );
}

export function useBranch() {
  const context = useContext(BranchContext);
  if (context === undefined) {
    throw new Error('useBranch must be used within a BranchProvider');
  }
  return context;
}

export default BranchProvider;
