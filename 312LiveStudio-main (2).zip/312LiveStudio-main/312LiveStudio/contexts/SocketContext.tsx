import AlarmPopup from "@/components/AlarmPopup";
import ConfirmModal from "@/components/ConfirmModal";
import React, {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

const SocketContext = createContext<SocketContextValue | null>(null);
type Alarm = {
  id: string; // unique id for rendering / queueing
  roomID: string;
  roomName: string;
  ts: number;
};
type LiveAlert = {
  id: string;
  code: string; // PATIENT ALARM
  meaning: string; // Patient alarm triggered
  description: string; // Alarm triggered in Room X
  roomId?: string;
  timestamp: number;
  scope: "branch" | "global";
};
type SocketContextValue = {
  activeAlarm: Alarm | null;
  liveAlerts: LiveAlert[];
  lastAlarmRoomID: string | null;
  acknowledgeAlarm: () => void;
  send: (message: any) => void;
  staffLocations: Record<string, StaffLocation>; // new
};

type StaffLocation = {
  staffID: string | number;
  roomID: number;
  roomName: string;
};

export default function SocketProvider({ children }: { children: ReactNode }) {
  const [liveAlerts, setLiveAlerts] = useState<LiveAlert[]>([]);
  const [activeAlarm, setActiveAlarm] = useState<Alarm | null>(null);
  const [lastAlarmRoomID, setLastAlarmRoomID] = useState<string | null>(null);
  const [showPopup, setShowPopup] = useState(false);
  const [staffLocations, setStaffLocations] = useState<
    Record<string, StaffLocation>
  >({});

  const acknowledgeAlarm = () => {
    setActiveAlarm(null);
  };
  useEffect(() => {
    console.log("MONITOR liveAlerts:", liveAlerts.length, liveAlerts);
  }, [liveAlerts]);

  const socketRef = useRef<any>(null);
  //const SERVER_IP = "192.168.42.16";
  const SERVER_IP = "172.20.10.2";

  //const SERVER_IP = "127.0.0.1";
  useEffect(() => {
    const ws = new WebSocket(`ws://${SERVER_IP}:3000/ws`);
    socketRef.current = ws;

    ws.onopen = () => {
      console.log("Connected to WS server");
    };
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      console.log("Received message:", data);
      switch (data.type) {
        case "ALARM":
          console.log(`Alarm received: ${data.roomID}`);
          const AlarmroomID = String(data.roomID ?? data.payload?.roomID ?? "");

          const alarm: Alarm = {
            id: `${data.roomID}_${Date.now()}`,
            roomID: AlarmroomID,
            roomName: data.roomName,
            ts: Date.now(),
          };
          setLastAlarmRoomID(AlarmroomID);
          setActiveAlarm(alarm);
          const alertItem: LiveAlert = {
            id: alarm.id,
            code: "Patient ALARM",
            meaning: "Patient alarm triggered",
            description: `Alarm triggered in ${alarm.roomName || "room"} (${alarm.roomID})`,
            roomId: alarm.roomID,
            timestamp: alarm.ts,
            scope: "global", // change if you want to differentiate
          };
          setLiveAlerts((prevAlerts) => [alertItem, ...prevAlerts]);
          break;
        case "STAFF_IN_OUT":
          const { staffID, roomID, roomName, action } = data;
          setStaffLocations((prev) => {
            const updated = { ...prev };
            if (action === "IN") {
              updated[staffID] = { staffID, roomID, roomName };
            } else if (action === "OUT") {
              delete updated[staffID];
            }
            return updated;
          });
          break;
        default:
          console.warn("Unknown msg type received ", data);
          break;
      }

      ws.onclose = () => {
        console.log("Socket closed");
        setShowPopup(true);
      };
      ws.onerror = (error) => {
        console.error("Socket error:", error);
      };
      return () => {
        ws.close();
      };
    };
  }, []); // on init open socket

  const send = (message: any) => {
    const ws = socketRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      console.warn("WS not connected yet — cannot send");
      return;
    }
    ws.send(JSON.stringify(message)); // useRef means it stays persistent and doesnt need to rerender at all.
  };

  return (
    <SocketContext.Provider
      value={{
        send,
        activeAlarm,
        lastAlarmRoomID,
        liveAlerts,
        acknowledgeAlarm,
        staffLocations,
      }}
    >
      {children}
      <AlarmPopup />
      <ConfirmModal
        visible={showPopup}
        title="Connection Lost"
        message="The connection to the server has been lost. Please check your network or restart the application."
        onConfirm={() => {
          setShowPopup(false);
        }}
        confirmText="OK"
        onCancel={() => setShowPopup(false)}
      ></ConfirmModal>
    </SocketContext.Provider>
  );
}
export function useSocket(): SocketContextValue {
  const context = useContext(SocketContext);
  if (context === null) {
    throw new Error("useSocket must be used within a SocketProvider");
  }
  return context;
}
